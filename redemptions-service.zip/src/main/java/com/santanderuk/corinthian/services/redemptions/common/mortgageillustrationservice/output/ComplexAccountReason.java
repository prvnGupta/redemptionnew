package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ComplexAccountReason extends ModelBase {

    private static final long serialVersionUID = 4315756404177087653L;

    private String code;
    private String message;
}
