package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DailyInterestMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var dailyAmount = getDailyAmount(anmfRedemptionsResponse);
        mapperOutput.setDailyInterest(dailyAmount);
    }

    private BigDecimal getDailyAmount(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        return anmfRedemptionsResponse.getMBSORRSTOperationResponse()
                .getOutputStruc()
                .getDailyAmount();
    }
}
