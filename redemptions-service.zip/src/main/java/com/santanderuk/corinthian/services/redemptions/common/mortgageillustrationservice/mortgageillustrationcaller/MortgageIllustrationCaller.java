package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MortgageIllustrationCaller {

    private final InputMapper inputMapper;
    private final AnmfCoreClient anmfCoreClient;

    @Autowired
    public MortgageIllustrationCaller(InputMapper inputMapper, AnmfCoreClient anmfCoreClient) {
        this.inputMapper = inputMapper;
        this.anmfCoreClient = anmfCoreClient;
    }

    public ANMFRedemptionsResponse getRedemptionsFigures(int account, String redemptionDate) throws ConnectionException {
        var input = inputMapper.map(account, redemptionDate);
        return anmfCoreClient.fetchRedemption(input);
    }
}
