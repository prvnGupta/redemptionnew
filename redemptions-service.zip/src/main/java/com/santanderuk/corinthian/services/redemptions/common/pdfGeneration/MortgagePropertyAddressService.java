package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MortgagePropertyAddressService {
    private final AnmfCoreClient anmfCoreClient;
    private final RedemptionsConfig config;
    private final AnmfRegionClient anmfRegionClient;

    @Autowired
    public MortgagePropertyAddressService(AnmfCoreClient anmfCoreClient, RedemptionsConfig config, AnmfRegionClient anmfRegionClient) {
        this.anmfCoreClient = anmfCoreClient;
        this.config = config;
        this.anmfRegionClient = anmfRegionClient;
    }

    public String getFormattedPropertyAddress(int mortgageAccount) {
        try {
            ANMFPropertyResponse anmfPropertyResponse = anmfCoreClient.fetchAddress(mortgageAccount, config.getAnmfPropertyServiceUrl(), anmfRegionClient.fetchCurrentRegion());
            return formatPropertyAddress(anmfPropertyResponse);
        } catch (Exception e) {
            log.warn("Exception while extracting mortgage Property address");
            return "";
        }
    }

    private String formatPropertyAddress(ANMFPropertyResponse anmfPropertyResponse) {
        OutputStructure outputStructure = anmfPropertyResponse.getPropertyEnquiryResponse().getOutputStructure();
        String address = outputStructure.getOPropertyAddr1();

        if (isNotBlankString(outputStructure.getOPropertyAddr2())) {
            address = address + ", " + outputStructure.getOPropertyAddr2();
        }

        if (isNotBlankString(outputStructure.getOPropertyAddr3())) {
            address = address + ", " + outputStructure.getOPropertyAddr3();
        }

        if (isNotBlankString(outputStructure.getOPropertyAddr4())) {
            address = address + ", " + outputStructure.getOPropertyAddr4();
        }

        if (isNotBlankString(outputStructure.getOPropertyPostcode())) {
            address = address + ", " + outputStructure.getOPropertyPostcode();
        }

        return address;
    }

    boolean isNotBlankString(String string) {
        return !(null == string || string.isBlank());
    }
}
