package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.Balance;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.Loans;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.Sundry;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.UnclearAmounts;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.stream.Stream;

@Component
public class UnclearAmountsMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var unclearAmounts = new UnclearAmounts();

        addUnclearAmountsPayments(anmfRedemptionsResponse, unclearAmounts);
        addUnclearAmountsOverpayments(anmfRedemptionsResponse, unclearAmounts);
        addUnclearAmountsSundries(anmfRedemptionsResponse, unclearAmounts);
        addTotal(unclearAmounts);

        mapperOutput.setUnclearAmounts(unclearAmounts);
    }

    private void addUnclearAmountsPayments(ANMFRedemptionsResponse anmfRedemptionsResponse, UnclearAmounts unclearAmounts) {

        var sum = getLoanStream(anmfRedemptionsResponse)
                .map(Loans::getUnclearAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        unclearAmounts.setUnclearAmountsPayments(sum);
    }

    private void addUnclearAmountsOverpayments(ANMFRedemptionsResponse anmfRedemptionsResponse, UnclearAmounts unclearAmounts) {

        var unclearAmount = getOverpayment(anmfRedemptionsResponse).getUnclearAmount();
        unclearAmounts.setUnclearAmountsOverPayments(unclearAmount);
    }

    private void addUnclearAmountsSundries(ANMFRedemptionsResponse anmfRedemptionsResponse, UnclearAmounts unclearAmounts) {

        var unclearAmount = getSundry(anmfRedemptionsResponse).getUnclearAmount();
        unclearAmounts.setUnclearAmountsSundries(unclearAmount);
    }

    private void addTotal(UnclearAmounts unclearAmounts) {

        var payments = unclearAmounts.getUnclearAmountsPayments();
        var overpayments = unclearAmounts.getUnclearAmountsOverPayments();
        var sundries = unclearAmounts.getUnclearAmountsSundries();

        var total = payments.add(overpayments).add(sundries);
        unclearAmounts.setTotal(total);
    }

    private Stream<Loans> getLoanStream(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getLoans().stream();
    }

    private Balance getOverpayment(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getOverpayment();
    }

    private Sundry getSundry(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getSundry();
    }
}
