package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EarlyRepaymentCharge extends ModelBase {

    private static final long serialVersionUID = -91133058173657081L;

    @JsonProperty("total")
    private BigDecimal total;

    @JsonProperty("earlyRepaymentChargeDetails")
    private List<EarlyRepaymentChargeDetails> earlyRepaymentChargeDetails;
}
