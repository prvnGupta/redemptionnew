package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

public enum Template {
    FIGURE_SUMMARY;
}
