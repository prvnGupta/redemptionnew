package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CapitalBalanceDetails extends ModelBase {

    private static final long serialVersionUID = -8340654676664606266L;

    private BigDecimal capitalBalance;
    private BigDecimal interestRate;

}
