package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.redemptions.api.figures.RedemptionFiguresServiceInput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

@Component
@Slf4j
public class PDFService {

    public static final String EMPTY_STRING = "";

    private final PdfGenerator pdfGenerator;

    private final PdfDataMapBuilder pdfDataMapBuilder;

    private final CustomerDetailsService customerDetailsService;

    private final MortgagePropertyAddressService mortgagePropertyAddressService;

    public PDFService(PdfGenerator pdfGenerator, PdfDataMapBuilder pdfDataMapBuilder, CustomerDetailsService customerDetailsService, MortgagePropertyAddressService mortgagePropertyAddressService) {
        this.pdfGenerator = pdfGenerator;
        this.pdfDataMapBuilder = pdfDataMapBuilder;
        this.customerDetailsService = customerDetailsService;
        this.mortgagePropertyAddressService = mortgagePropertyAddressService;
    }

    public String createFiguresPdf(RedemptionFiguresServiceInput input, MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput) {

        PdfAccountDetails accountDetails = getBorrowerNamesAndAddress(input);

        var dataMap = createDataMap(input, mortgageIllustrationServiceOutput, accountDetails);

        var pdfAsByteArrayOutputStream = pdfGenerator.createPdf(createPdfGeneratorRequest(dataMap));
        return pdfAsByteArrayOutputStream != null ? convertToBase64EncodedPdf(pdfAsByteArrayOutputStream) : EMPTY_STRING;
    }

    private PdfAccountDetails getBorrowerNamesAndAddress(RedemptionFiguresServiceInput input) {
        PdfAccountDetails accountDetails = new PdfAccountDetails();
        String formattedCustomerNames = customerDetailsService.getFormattedCustomerInformationBDP(input.getAnmfBelongsToCustomerWithBorrowerList());
        String formattedPropertyAddress = mortgagePropertyAddressService.getFormattedPropertyAddress(input.getAccount());
        accountDetails.setAddress(formattedPropertyAddress);
        accountDetails.setNames(formattedCustomerNames);
        return accountDetails;
    }


    private PdfGeneratorRequest createPdfGeneratorRequest(Map<String, Object> dataMap) {
        var pdfGeneratorRequest = new PdfGeneratorRequest();
        pdfGeneratorRequest.setTemplateName(Template.FIGURE_SUMMARY);
        pdfGeneratorRequest.setTemplateElements(dataMap);
        return pdfGeneratorRequest;
    }

    private Map<String, Object> createDataMap(RedemptionFiguresServiceInput input, MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput, PdfAccountDetails pdfAccountDetails) {
        return pdfDataMapBuilder.build(input, mortgageIllustrationServiceOutput, pdfAccountDetails);
    }

    private String convertToBase64EncodedPdf(ByteArrayOutputStream pdfAsByteArrayOutputStream) {
        try {
            byte[] inFileBytes = pdfAsByteArrayOutputStream.toByteArray();
            return new String(Base64.getEncoder().encode(inFileBytes), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.warn("PDFService:convertToBase64EncodedPdf -> Exception. Returning empty String");
            return "";
        }
    }

}
