package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.Loans;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.CapitalBalanceDetails;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.OutstandingBalance;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OutstandingBalanceMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var outstandingBalance = new OutstandingBalance();

        addCapitalBalancesDetails(anmfRedemptionsResponse, outstandingBalance);
        addOverdueAmounts(anmfRedemptionsResponse, outstandingBalance);
        addOtherCostsSundries(anmfRedemptionsResponse, outstandingBalance);
        addTotal(outstandingBalance);

        mapperOutput.setOutstandingBalance(outstandingBalance);
    }

    private void addCapitalBalancesDetails(ANMFRedemptionsResponse anmfRedemptionsResponse, OutstandingBalance outstandingBalance) {

        var capitalBalanceDetailsList = getLoans(anmfRedemptionsResponse).stream()
                .map(this::convertoToCapitalBalanceDetails)
                .collect(Collectors.toList());

        outstandingBalance.setCapitalBalanceDetails(capitalBalanceDetailsList);
    }

    private CapitalBalanceDetails convertoToCapitalBalanceDetails(Loans loan) {
        var capitalBalanceDetails = new CapitalBalanceDetails();

        capitalBalanceDetails.setCapitalBalance(loan.getCapitalBalance());
        capitalBalanceDetails.setInterestRate(loan.getLsRate());

        return capitalBalanceDetails;
    }

    private void addOverdueAmounts(ANMFRedemptionsResponse anmfRedemptionsResponse, OutstandingBalance outstandingBalance) {

        var arrearsSum = getLoans(anmfRedemptionsResponse).stream()
                .map(Loans::getArrearsBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        outstandingBalance.setOverdueAmounts(arrearsSum);
    }

    private void addOtherCostsSundries(ANMFRedemptionsResponse anmfRedemptionsResponse, OutstandingBalance outstandingBalance) {
        var arrearsBalance = anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getSundry().getArrearsBalance();
        outstandingBalance.setOtherCostsSundries(arrearsBalance);
    }

    private void addTotal(OutstandingBalance outstandingBalance) {

        var capitalBalanceSum = capitalBalanceSum(outstandingBalance);
        var arrearsSum = outstandingBalance.getOverdueAmounts();
        var otherCostsSundries = outstandingBalance.getOtherCostsSundries();

        var result = capitalBalanceSum.add(arrearsSum).add(otherCostsSundries);

        outstandingBalance.setTotal(result);
    }

    private BigDecimal capitalBalanceSum(OutstandingBalance outstandingBalance) {
        return outstandingBalance.getCapitalBalanceDetails().stream()
                .map(CapitalBalanceDetails::getCapitalBalance)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private List<Loans> getLoans(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getLoans();
    }
}
