package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class AccountComplexityException extends GeneralException {

    private static final String CODE_COMPLEX_ACCOUNT = "EXC_REDEMPTION_COMPLEX_ACCOUNT";
    private static final String MESSAGE_COMPLEX_ACCOUNT = "The account you are trying to access is a complex one";

    public AccountComplexityException() {
        super(CODE_COMPLEX_ACCOUNT, MESSAGE_COMPLEX_ACCOUNT);
    }

    public AccountComplexityException(Exception e) {
        super(CODE_COMPLEX_ACCOUNT, MESSAGE_COMPLEX_ACCOUNT, e);
    }
}
