package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BreakDownData {

    private String interestRate;
    private String outstandingBalance;
    private String earlyRepaymentCharge = "0";
}
