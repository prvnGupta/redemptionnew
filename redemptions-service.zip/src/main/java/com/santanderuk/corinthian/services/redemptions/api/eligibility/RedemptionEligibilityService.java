package com.santanderuk.corinthian.services.redemptions.api.eligibility;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.api.eligibility.io.RedemptionEligibilityOutput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.MortgageIllustrationService;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class RedemptionEligibilityService {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    MortgageIllustrationService mortgageIllustrationService;

    @Autowired
    public RedemptionEligibilityService(MortgageIllustrationService mortgageIllustrationService) {

        this.mortgageIllustrationService = mortgageIllustrationService;
    }

    public RedemptionEligibilityOutput get(int account) throws IOException, ConnectionException {

        var today = LocalDate.now().format(FORMATTER);

        var illustrationOutput = mortgageIllustrationService.getFiguresForDate(account, today);
        var output = new RedemptionEligibilityOutput();

        if (hasComplexErrors(illustrationOutput)) {
            output.setEligible(false);
            output.setComplexAccountReasons(illustrationOutput.getComplexAccountReasons());
        } else {
            output.setEligible(true);
        }

        return output;
    }

    private boolean hasComplexErrors(MortgageIllustrationServiceOutput output) {
        return null != output.getComplexAccountReasons() && !output.getComplexAccountReasons().isEmpty();
    }
}
