package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class AccountComplexity {

    public void check(ANMFRedemptionsResponse anmfRedemptionsResponse) throws AccountComplexityException {
        if (isComplex(anmfRedemptionsResponse)) {
            throw new AccountComplexityException();
        }
    }

    public boolean isComplex(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        return thereIsErrors(anmfRedemptionsResponse)
                &&
                errorFoundInComplexList(anmfRedemptionsResponse);
    }

    public boolean isComplex(RedeptionIllustrationError error) {

        var count = complexAccountErrorCodes().stream()
                .filter(complexAccountError -> complexAccountError.equalsIgnoreCase(error.getECode()))
                .count();

        return count > 0;
    }

    private boolean errorFoundInComplexList(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        var responseErrorCodes = responseErrorCodes(anmfRedemptionsResponse);
        var complexAccountErrorCodes = complexAccountErrorCodes();

        var count = responseErrorCodes.stream()
                .filter(complexAccountErrorCodes::contains)
                .count();

        return count > 0;
    }

    private boolean thereIsErrors(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return null != anmfRedemptionsResponse.getErrors() && !anmfRedemptionsResponse.getErrors().isEmpty();
    }

    private List<String> responseErrorCodes(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        return anmfRedemptionsResponse.getErrors().stream()
                .map(error -> error.getECode().toUpperCase())
                .collect(Collectors.toList());
    }

    private List<String> complexAccountErrorCodes() {

        return Arrays.stream(ComplexAccountCodes.values())
                .map(error -> error.getCode().toUpperCase())
                .collect(Collectors.toList());
    }


}
