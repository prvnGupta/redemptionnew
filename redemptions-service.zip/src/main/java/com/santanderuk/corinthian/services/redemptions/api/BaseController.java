package com.santanderuk.corinthian.services.redemptions.api;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresOutputWrapper;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexityException;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static org.springframework.http.HttpStatus.OK;

@Slf4j
public class BaseController {

    private final RedemptionsConfig config;
    private final AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;

    public BaseController(RedemptionsConfig config, AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService) {
        this.config = config;
        this.anmfBelongToCustomerWithBorrowerListService = anmfBelongToCustomerWithBorrowerListService;
    }

    public void checkOperativeSecurity(int accountNumber, String jwtToken, AnmfRegion anmfRegion) throws OperativeSecurityException, ConnectionException, ValidationsException {
        if (config.isOperativeSecurity()) {
            var anmfCustomerServiceUrl = config.getAnmfCustomerServiceUrl();
            AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList = anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(accountNumber, jwtToken, anmfCustomerServiceUrl, anmfRegion);
            if (!anmfBelongsToCustomerWithBorrowerList.getAnmfBelongsToCustomer()) {
                log.warn("Security KO. Mortgage does not belong to customer");
                throw new OperativeSecurityException("SECURITY_KO", "Mortgage does not belong to customer");
            }
        }
    }

    public AnmfBelongsToCustomerWithBorrowerList checkOperativeSecurityWithBorrowerList(int accountNumber, String jwtToken, AnmfRegion anmfRegion) throws OperativeSecurityException, ConnectionException, ValidationsException {

        var anmfCustomerServiceUrl = config.getAnmfCustomerServiceUrl();
        AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList = anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(accountNumber, jwtToken, anmfCustomerServiceUrl, anmfRegion);
        if (config.isOperativeSecurity()) {
            if (!anmfBelongsToCustomerWithBorrowerList.getAnmfBelongsToCustomer()) {
                log.warn("Security KO. Mortgage does not belong to customer");
                throw new OperativeSecurityException("SECURITY_KO", "Mortgage does not belong to customer");
            }
        }
        return anmfBelongsToCustomerWithBorrowerList;
    }

    @ExceptionHandler(OperativeSecurityException.class)
    public ResponseEntity<RedemptionFiguresOutputWrapper> handleOperativeSecurityException(final GeneralException generalException) {
        final var responseWrapper = new RedemptionFiguresOutputWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(generalException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(MaintenanceException.class)
    public ResponseEntity<RedemptionFiguresOutputWrapper> handleMaintenanceException(final MaintenanceException maintenanceExpcetion) {
        var wrapper = new RedemptionFiguresOutputWrapper();
        var info = ServiceInfoCreator.exception(maintenanceExpcetion);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, OK);
    }

    @ExceptionHandler(AccountComplexityException.class)
    public ResponseEntity<RedemptionFiguresOutputWrapper> handleComplexAccountException(final AccountComplexityException ex) {
        var wrapper = new RedemptionFiguresOutputWrapper();
        var info = ServiceInfoCreator.exception(ex);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, OK);
    }
}
