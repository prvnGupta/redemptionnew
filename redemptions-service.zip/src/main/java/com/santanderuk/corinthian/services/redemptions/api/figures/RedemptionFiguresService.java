package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexityException;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.MortgageIllustrationService;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.common.pdfGeneration.PDFService;
import com.santanderuk.corinthian.services.redemptions.gass.GassService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@Slf4j
public class RedemptionFiguresService {

    private final MortgageIllustrationService mortgageIllustrationService;
    private final GassService gassService;
    private final PDFService pdfService;
    private RedemptionFiguresFunctionalValidation functionalValidation;

    @Autowired
    public RedemptionFiguresService(MortgageIllustrationService mortgageIllustrationService,
                                    GassService gassService,
                                    RedemptionFiguresFunctionalValidation functionalValidation, PDFService pdfService) {

        this.mortgageIllustrationService = mortgageIllustrationService;
        this.gassService = gassService;
        this.functionalValidation = functionalValidation;
        this.pdfService = pdfService;
    }

    public MortgageIllustrationServiceOutput getRedemptionsFigures(RedemptionFiguresServiceInput input) throws AccountComplexityException, ConnectionException, IOException, RedemptionFiguresFunctionalValidationException {

        functionalValidation.validate(input.getRequest());

        var mortgageIllustrationServiceOutput = new MortgageIllustrationServiceOutput();
        try {
            log.info("RedemptionFiguresService:get About to call mortgageIllustrationService");
            mortgageIllustrationServiceOutput = mortgageIllustrationService.getFiguresForDate(input.getAccount(), input.getRequest().getRedemptionDate());
            checkComplexAccountErrors(mortgageIllustrationServiceOutput);

            String base64Pdf = pdfService.createFiguresPdf(input, mortgageIllustrationServiceOutput);
            mortgageIllustrationServiceOutput.setBase64Pdf(base64Pdf);

            return mortgageIllustrationServiceOutput;
        } finally {
            log.info("RedemptionFiguresService:get About to call GASS");
            gassService.auditViewRedemptionsFigure(input.getAccount(), input.getAnmfBelongsToCustomerWithBorrowerList(), input.getJwtToken(), input.getServletRequest(), mortgageIllustrationServiceOutput);
        }

    }

    private void checkComplexAccountErrors(MortgageIllustrationServiceOutput output) throws AccountComplexityException {
        if (null != output.getComplexAccountReasons() && !output.getComplexAccountReasons().isEmpty()) {
            throw new AccountComplexityException();
        }
    }
}
