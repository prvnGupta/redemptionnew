package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Objects;

@Slf4j
@Component
public class PdfGenerator {

    public static final Template FIGURE_SUMMARY = Template.FIGURE_SUMMARY;
    public static final String TEMPLATES = "templates";

    private final TemplateEngine templateEngine;

    private final ContextBuilder contextBuilder;

    @Autowired
    public PdfGenerator(TemplateEngine templateEngine, ContextBuilder contextBuilder) {
        this.templateEngine = templateEngine;
        this.contextBuilder = contextBuilder;
    }

    public ByteArrayOutputStream createPdf(PdfGeneratorRequest pdfRequest) {

        Context context = contextBuilder.buildContext(pdfRequest.getTemplateElements());

        String processedHtml = templateEngine.process(getTemplateName(pdfRequest), context);
        ByteArrayOutputStream generatedPDF = null;
        try {
            log.debug("about to create PDF");
            generatedPDF = generatePdfFromHtml(processedHtml);
            log.info("PDF created");
        } catch (Exception e) {
            log.warn("Exception while generating PDF");
        } finally {
            checkAndClosePDF(generatedPDF);
        }
        return generatedPDF;
    }

    private String getTemplateName(PdfGeneratorRequest pdfRequest) {
        if (pdfRequest.getTemplateName() == FIGURE_SUMMARY) {
            return "settlement-figure-pdf";
        }
        throw new TemplateNotFoundException();
    }

    private ByteArrayOutputStream generatePdfFromHtml(String processedHtml) throws DocumentException, IOException {
        ByteArrayOutputStream generatedPDF = new ByteArrayOutputStream();
        ITextRenderer renderer = new ITextRenderer(4.1666f, 3);

        File file = new File(Objects.requireNonNull(Thread.currentThread().getContextClassLoader().getResource(FilenameUtils.getName(TEMPLATES))).getFile());
        String baseUrl = file.toURI().toString();
        renderer.setDocumentFromString(processedHtml, baseUrl);
        renderer.getFontResolver().addFont("templates/fonts/Santander-new/micro/SantanderMicroText-new.ttf", BaseFont.IDENTITY_H, true);
        renderer.getFontResolver().addFont("templates/fonts/Santander-new/micro-bold/SantanderMicroTextXBd-new.otf", BaseFont.IDENTITY_H, true);
        renderer.getFontResolver().addFont("templates/fonts/Santander-new/micro-bold/SantanderMicroTextXBd-new.ttf", BaseFont.IDENTITY_H, true);
        renderer.layout();
        renderer.createPDF(generatedPDF, false);
        renderer.finishPDF();
        return generatedPDF;
    }

    private void checkAndClosePDF(ByteArrayOutputStream generatedPDF) {
        if (generatedPDF != null) {
            try {
                generatedPDF.close();
            } catch (IOException e) {
                log.error("IOException when trying to close ByteArrayOutputStream");
            }
        }
    }
}
