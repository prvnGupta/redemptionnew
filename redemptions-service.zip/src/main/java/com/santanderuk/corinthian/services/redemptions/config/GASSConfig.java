package com.santanderuk.corinthian.services.redemptions.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Configuration
@Getter
@Setter
public class GASSConfig {

    @Value("${gass.common-config.audittrngrpid}")
    private String auditTrnGrpId;

    @Value("${gass.common-config.authcdusercompsysid}")
    private String authCdUserCompSysId;

    @Value("${gass.common-config.instgrusercompsysid}")
    private String instGrUserCompSysId;

    @Value("${gass.common-config.orgid}")
    private String orgId;

    @Value("${gass.common-config.orguttp}")
    private String orgUttp;

    @Value("${gass.common-config.orgutid}")
    private String orgUtId;

    @Value("${gass.common-config.authcduser}")
    private String authCdUser;

    @Value("${gass.trntpname.transactionNameViewRedemptionsFigure}")
    private String transactionNameViewRedemptionsFigure;

    @Value("${gass.internet.dvctyp}")
    private String dvcTypInternet;

    @Value("${gass.internet.appsysid}")
    private String appSysIdInternet;
}
