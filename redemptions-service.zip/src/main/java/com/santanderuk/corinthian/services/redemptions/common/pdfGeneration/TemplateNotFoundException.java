package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

public class TemplateNotFoundException extends RuntimeException {
    public TemplateNotFoundException() {
    }
}
