package com.santanderuk.corinthian.services.redemptions.api.figures.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RedemptionFiguresOutputWrapper extends ModelBase {

    private static final long serialVersionUID = -1129351964597514283L;

    private MortgageIllustrationServiceOutput data;
    private ServiceInfo info;
}
