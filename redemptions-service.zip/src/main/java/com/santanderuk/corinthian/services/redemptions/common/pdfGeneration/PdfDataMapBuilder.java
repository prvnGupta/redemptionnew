package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.redemptions.api.figures.RedemptionFiguresServiceInput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.CapitalBalanceDetails;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.EarlyRepaymentChargeDetails;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class PdfDataMapBuilder {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("d MMMM yyyy");

    final RedemptionsConfig config;

    final ErcPdfDetailsService ercPdfDetailsService;

    @Autowired
    public PdfDataMapBuilder(RedemptionsConfig config, ErcPdfDetailsService ercPdfDetailsService) {
        this.config = config;
        this.ercPdfDetailsService = ercPdfDetailsService;
    }

    public Map<String, Object> build(RedemptionFiguresServiceInput input, MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput, PdfAccountDetails pdfAccountDetails) {
        return Map.of(
                "sortCode", config.getDefaultSortCode(),
                "redemptionDate", formatDate(input.getRequest().getRedemptionDate()),
                "currentDate", formatDate(null),
                "mortgageNumber", String.valueOf(input.getAccount()),
                "pdfContextData", getPDFContextData(mortgageIllustrationServiceOutput),
                "names", pdfAccountDetails.getNames() != null ? pdfAccountDetails.getNames() : " ",
                "address", pdfAccountDetails.getAddress() != null ? pdfAccountDetails.getAddress() : " ",
                "ercPdfDetailsService", ercPdfDetailsService.getErcPdfDetails(input.getAccount()));

    }

    private PDFContextData getPDFContextData(MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput) {
        PDFContextData pdfContextData = new PDFContextData();
        List<BreakDownData> breakDownList = new ArrayList<>(mortgageIllustrationServiceOutput.getOutstandingBalance().getCapitalBalanceDetails().size());
        for (CapitalBalanceDetails capitalBalance : mortgageIllustrationServiceOutput.getOutstandingBalance().getCapitalBalanceDetails()) {
            BreakDownData breakDownData = new BreakDownData();
            breakDownData.setInterestRate(capitalBalance.getInterestRate() + "%");
            breakDownData.setOutstandingBalance(pdfAmountText(capitalBalance.getCapitalBalance()));

            for (EarlyRepaymentChargeDetails earlyRepayment : mortgageIllustrationServiceOutput.getEarlyRepaymentCharge().getEarlyRepaymentChargeDetails()) {
                if (capitalBalance.getCapitalBalance().compareTo(earlyRepayment.getBalance()) == 0 && capitalBalance.getInterestRate().compareTo(earlyRepayment.getInterestRate()) == 0) {
                        breakDownData.setEarlyRepaymentCharge(pdfAmountText(earlyRepayment.getEarlyRepaymentCharge()));
                }
            }
            breakDownList.add(breakDownData);
        }
        pdfContextData.setBreakDownDataList(breakDownList);
        pdfContextData.setUnclearedAmounts(pdfAmountText(mortgageIllustrationServiceOutput.getUnclearAmounts().getTotal()));
        pdfContextData.setPayments(pdfAmountText(mortgageIllustrationServiceOutput.getUnclearAmounts().getUnclearAmountsPayments()));
        pdfContextData.setOverpayments(pdfAmountText(mortgageIllustrationServiceOutput.getUnclearAmounts().getUnclearAmountsOverPayments()));
        pdfContextData.setSundries(pdfAmountText(mortgageIllustrationServiceOutput.getUnclearAmounts().getUnclearAmountsSundries()));
        pdfContextData.setInterestSinceLastPayment(pdfAmountText(mortgageIllustrationServiceOutput.getInterestSinceLastPayment()));
        pdfContextData.setMortgageAccountFee(pdfAmountText(mortgageIllustrationServiceOutput.getMortgageAccountFee()));
        pdfContextData.setRepayableBenefits(pdfAmountText(mortgageIllustrationServiceOutput.getBenefitsReclaim()));
        pdfContextData.setOverdueAmounts(pdfAmountText(mortgageIllustrationServiceOutput.getOutstandingBalance().getOverdueAmounts()));
        pdfContextData.setOtherCosts(pdfAmountText(mortgageIllustrationServiceOutput.getOutstandingBalance().getOtherCostsSundries()));
        pdfContextData.setRecentOverpayments(pdfAmountText(mortgageIllustrationServiceOutput.getCreditsToAccountOverpayments()));
        pdfContextData.setTotalToRepay(pdfAmountText(mortgageIllustrationServiceOutput.getTotalToRepay()));

        return pdfContextData;
    }


    private String pdfAmountText(BigDecimal amount) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return amount.compareTo(BigDecimal.ZERO) == 0 ? "0" : "£" + df.format(amount);
    }


    private String formatDate(String redemptionDate) {
        if (redemptionDate != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return LocalDate.parse(redemptionDate, formatter).format(FORMATTER);
        } else {
            LocalDate currentDate = LocalDate.now();
            return currentDate.format(FORMATTER);
        }
    }

}
