package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class MortgageAccountFeeMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var totalDailyInterestAmount = geDeedHandlingFee(anmfRedemptionsResponse);
        mapperOutput.setMortgageAccountFee(totalDailyInterestAmount);
    }

    private BigDecimal geDeedHandlingFee(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        return anmfRedemptionsResponse.getMBSORRSTOperationResponse()
                .getOutputStruc()
                .getDeedHandlingFee();
    }
}
