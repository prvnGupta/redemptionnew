package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import lombok.Getter;

@Getter
public enum ComplexAccountCodes {

    LITIGATION("ERR21504", "Litigation"),
    FIRST_DD_PAYMENT("ERR21502", "First DD payment not received"),
    FURTHER_ADVANCE_PENDING("ERR21507", "Pending Further Advance"),
    BANKRUPTCY("ERR21511", "Bankruptcy"),
    SECURED_PERSONAL_LOAN("ERR21512", "Secured Personal Loan"),
    RIGHT_OF_CONSOLIDATION("ERR21513", "Rights of Consolidation"),
    DECEASED("ERR21508", "Deceased"),
    CLOSED_REDEEMED_PENDING("ERR21500", "Account status is Closed, Redeemed or Pending");


    private final String code;
    private final String description;

    ComplexAccountCodes(String code, String description) {
        this.code = code;
        this.description = description;
    }
}
