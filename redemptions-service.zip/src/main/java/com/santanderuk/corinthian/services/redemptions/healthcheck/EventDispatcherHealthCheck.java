package com.santanderuk.corinthian.services.redemptions.healthcheck;


import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class EventDispatcherHealthCheck {
    private final RestTemplate restTemplate;
    private final RedemptionsConfig redemptionsConfig;

    @Autowired
    public EventDispatcherHealthCheck(RestTemplate restTemplate, RedemptionsConfig redemptionsConfig) {
        this.restTemplate = restTemplate;
        this.redemptionsConfig = redemptionsConfig;
    }

    public boolean checkIfEventDispatcherIsAlive() {
        ResponseEntity<String> response;
        try {
            String authHealthUrl = redemptionsConfig.getEventDispatcherHealthEndpoint();
            response = restTemplate.getForEntity(authHealthUrl, String.class);
            return response.getBody().toLowerCase().trim().replaceAll(" ", "").contains("\"status\":\"up\"");
        } catch (Exception e) {
            log.error("Error while checking Event-dispatcher-service health check", e);
            return false;
        }
    }
}
