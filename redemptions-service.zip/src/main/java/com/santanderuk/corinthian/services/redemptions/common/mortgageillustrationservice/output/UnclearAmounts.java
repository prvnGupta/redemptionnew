package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UnclearAmounts extends ModelBase {

    private static final long serialVersionUID = 6259521003887773281L;

    @JsonProperty("unclearAmountsSundries")
    private BigDecimal unclearAmountsSundries;

    @JsonProperty("total")
    private BigDecimal total;

    @JsonProperty("unclearAmountsOverPayments")
    private BigDecimal unclearAmountsOverPayments;

    @JsonProperty("unclearAmountsPayments")
    private BigDecimal unclearAmountsPayments;
}
