package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class RedemptionFiguresFunctionalValidation {

    public static final RedemptionFiguresFunctionalValidationException.Type REDEMPTION_DATE_NOT_IN_RANGE = RedemptionFiguresFunctionalValidationException.Type.REDEMPTION_DATE_NOT_IN_RANGE;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    final RedemptionsConfig redemptionsConfig;

    public RedemptionFiguresFunctionalValidation(RedemptionsConfig redemptionsConfig) {
        this.redemptionsConfig = redemptionsConfig;
    }

    public void validate(RedemptionFiguresInputWrapper request) throws RedemptionFiguresFunctionalValidationException {

        var redemptionDate = getRedemptionDate(request);

        var isInThePast = isInThePast(redemptionDate);
        var isAfterFutureSettlementDateRange = isAfterFutureSettlementDateRange(redemptionDate);

        if (isInThePast || isAfterFutureSettlementDateRange) {
            throw new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE);
        }
    }

    private LocalDate getRedemptionDate(RedemptionFiguresInputWrapper request) {
        var redemptionDate = request.getRedemptionDate();
        return LocalDate.parse(redemptionDate, FORMATTER);
    }

    private boolean isAfterFutureSettlementDateRange(LocalDate redemptionDate) {
        var todayPlusDateRange = LocalDate.now().plusDays(redemptionsConfig.getRedemptionDateRange());
        return redemptionDate.isAfter(todayPlusDateRange);
    }

    private boolean isInThePast(LocalDate redemptionDate) {
        var today = LocalDate.now();
        return redemptionDate.isBefore(today);
    }
}
