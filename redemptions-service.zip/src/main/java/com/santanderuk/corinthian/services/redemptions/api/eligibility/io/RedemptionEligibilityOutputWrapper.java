package com.santanderuk.corinthian.services.redemptions.api.eligibility.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RedemptionEligibilityOutputWrapper extends ModelBase {

    private static final long serialVersionUID = -1129351964597514283L;

    private RedemptionEligibilityOutput data;
    private ServiceInfo info;
}
