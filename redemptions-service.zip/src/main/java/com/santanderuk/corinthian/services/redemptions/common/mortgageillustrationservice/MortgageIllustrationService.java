package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.RedemptionsFiguresOutputMapper;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller.MortgageIllustrationCaller;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MortgageIllustrationService {

    private final MortgageIllustrationCaller mortgageIllustrationCaller;
    private final RedemptionsFiguresOutputMapper redemptionsFiguresOutputMapper;

    @Autowired
    public MortgageIllustrationService(MortgageIllustrationCaller mortgageIllustrationCaller, RedemptionsFiguresOutputMapper redemptionsFiguresOutputMapper) {
        this.mortgageIllustrationCaller = mortgageIllustrationCaller;
        this.redemptionsFiguresOutputMapper = redemptionsFiguresOutputMapper;
    }

    public MortgageIllustrationServiceOutput getFiguresForDate(int account, String redemptionDate) throws ConnectionException {
        var response = mortgageIllustrationCaller.getRedemptionsFigures(account, redemptionDate);
        return redemptionsFiguresOutputMapper.map(response, redemptionDate);
    }
}
