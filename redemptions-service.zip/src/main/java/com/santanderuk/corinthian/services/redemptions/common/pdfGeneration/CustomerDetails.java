package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDetails extends ModelBase {

    private String customerId;
    private String title;
    private String firstName;
    private String lastName;

}
