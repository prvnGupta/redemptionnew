package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OutstandingBalance extends ModelBase {

    private static final long serialVersionUID = -1472112069094220311L;

    @JsonProperty("total")
    private BigDecimal total;

    @JsonProperty("overdueAmounts")
    private BigDecimal overdueAmounts;

    @JsonProperty("capitalBalanceDetails")
    private List<CapitalBalanceDetails> capitalBalanceDetails;

    @JsonProperty("otherCostsSundries")
    private BigDecimal otherCostsSundries;
}
