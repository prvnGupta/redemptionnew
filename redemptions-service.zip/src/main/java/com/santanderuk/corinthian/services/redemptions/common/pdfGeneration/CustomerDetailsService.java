package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class CustomerDetailsService {

    private final CustomerInformationClient customerInformationClient;

    private final CustomerDetailsMapper customerDetailsMapper;

    private final RedemptionsConfig config;

    public CustomerDetailsService(CustomerInformationClient customerInformationClient, CustomerDetailsMapper customerDetailsMapper, RedemptionsConfig config) {
        this.customerInformationClient = customerInformationClient;
        this.customerDetailsMapper = customerDetailsMapper;
        this.config = config;
    }

    public String getFormattedCustomerInformationBDP(AnmfBelongsToCustomerWithBorrowerList borrowerList) {
        List<CustomerDetails> customerList = new ArrayList<>(borrowerList.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().size());
        try {
            for (var customer : borrowerList.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList()) {
                var customerId = customer.getOBdpType() + zeroLeftPadCustomerNumber(customer.getOCustomerId());
                log.debug("customerIdZeroLeftPadded - {}", customerId);
                CustomerInformationResponse customerInformationResponse = null;

                customerInformationResponse = customerInformationClient.getCustomerInformation(config.getCustomerInformationUrl(),
                        customerId);
                customerList.add(customerDetailsMapper.mapToCustomerDetails(customer, customerInformationResponse));

            }

        } catch ( Exception  e) {
            log.warn("PDFService: -> Exception while calling customerInformationUrl", e);
            return "";
        }
        return getFormattedNames(customerList);
    }

    private String zeroLeftPadCustomerNumber(int customerNumber) {
        return StringUtils.leftPad(String.valueOf(customerNumber), 9, "0");
    }

    private String getFormattedNames(List<CustomerDetails> customerDetails) {
        List<String> nameList = new ArrayList<>();
        try {
            for (CustomerDetails customerDetail : customerDetails) {
                nameList.add(customerDetail.getTitle() + " " + customerDetail.getFirstName() + " " + customerDetail.getLastName() + ", ");
            }
            String name = String.join("", nameList);
            return name.substring(0, name.length() - 2);
        } catch (Exception e) {
            return "";
        }
    }
}
