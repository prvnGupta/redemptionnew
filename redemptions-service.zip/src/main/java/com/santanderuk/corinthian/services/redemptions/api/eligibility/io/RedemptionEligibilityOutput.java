package com.santanderuk.corinthian.services.redemptions.api.eligibility.io;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.ComplexAccountReason;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RedemptionEligibilityOutput extends ModelBase {

    private static final long serialVersionUID = 8758625854114954685L;

    private boolean eligible;
    private AnmfRegion anmfRegion;
    private List<ComplexAccountReason> complexAccountReasons;
}
