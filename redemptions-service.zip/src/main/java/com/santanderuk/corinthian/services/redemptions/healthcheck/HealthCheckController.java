package com.santanderuk.corinthian.services.redemptions.healthcheck;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckController {
    private final EventDispatcherHealthCheck eventDispatcherHealthCheck;

    public HealthCheckController(EventDispatcherHealthCheck eventDispatcherHealthCheck) {
        this.eventDispatcherHealthCheck = eventDispatcherHealthCheck;
    }

    @GetMapping(value = {"/health", "/healthz"})
    public ResponseEntity<String> getHealthCheck() {
        if (eventDispatcherHealthCheck.checkIfEventDispatcherIsAlive()) {
            return new ResponseEntity<>("Up", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("SERVICE DOWN", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
