package com.santanderuk.corinthian.services.redemptions.api.figures.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class RedemptionFiguresInputWrapper extends ModelBase {

    private static final long serialVersionUID = 134066649024882004L;

    private String redemptionDate;
}
