package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EarlyRepaymentChargeDetails extends ModelBase {

    private static final long serialVersionUID = 3902713092878281858L;

    @JsonProperty("balance")
    private BigDecimal balance;

    @JsonProperty("earlyRepaymentCharge")
    private BigDecimal earlyRepaymentCharge;

    @JsonProperty("interestRate")
    private BigDecimal interestRate;
}
