package com.santanderuk.corinthian.services.redemptions.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;

import java.time.Duration;

@Configuration
@Profile("default")
public class CorinthianRedisCacheConfiguration extends CachingConfigurerSupport {

    @Value("${spring.redis.sentinel.master}")
    private String sentinelMaster;

    @Value("${spring.redis.sentinel.nodes}")
    private String sentinelNodes;

    @Value("${spring.redis.password}")
    private String redisPassword;

    @Value("${caching.shortTimeCacheExpiration}")
    private int shortTimeCacheExpiration;

    @Value("${caching.longTimeCacheExpiration}")
    private int longTimeCacheExpiration;


    @Bean
    public RedisConnectionFactory lettuceConnectionFactory() {
        RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration();
        sentinelConfig.master(sentinelMaster);
        String[] sentinels = sentinelNodes.split(",");

        for (String sentinel : sentinels) {
            String[] sentinelInfo = sentinel.split(":");
            sentinelConfig.sentinel(sentinelInfo[0], Integer.valueOf(sentinelInfo[1]));
        }

        sentinelConfig.setPassword(redisPassword);
        return new LettuceConnectionFactory(sentinelConfig);
    }

    @Bean
    @Primary
    public CacheManager cacheManagerShortLife(RedisConnectionFactory redisConnectionFactory) {

        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig().disableCachingNullValues().entryTtl(Duration.ofSeconds(shortTimeCacheExpiration));
        return RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(config).build();
    }

    @Bean
    public CacheManager cacheManagerLongLife(RedisConnectionFactory redisConnectionFactory) {

        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig().disableCachingNullValues().entryTtl(Duration.ofSeconds(longTimeCacheExpiration));
        return RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(config).build();
    }
}
