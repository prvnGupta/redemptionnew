package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;

import java.util.Map;

@Component
public class ContextBuilder {

    public Context buildContext(Map<String, Object> dataMap) {

        Context pageContext = new Context();
        dataMap.keySet().forEach(key ->
                pageContext.setVariable(key, dataMap.get(key))
        );

        return pageContext;
    }
}
