package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.servlet.http.HttpServletRequest;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RedemptionFiguresServiceInput extends ModelBase {

    private int account;
    private AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList;
    private String jwtToken;
    private HttpServletRequest servletRequest;
    private RedemptionFiguresInputWrapper request;

}
