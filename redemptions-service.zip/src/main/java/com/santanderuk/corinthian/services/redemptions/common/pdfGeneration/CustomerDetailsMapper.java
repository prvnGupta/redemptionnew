package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class CustomerDetailsMapper {
    public CustomerDetails mapToCustomerDetails(OCustomer customer, CustomerInformationResponse customerInformationResponse) {
        var customerDetail = new CustomerDetails();
        customerDetail.setTitle(formatName(customerInformationResponse.getCustomerBasicDataEnquire().getTitle()));
        customerDetail.setFirstName(formatName(customerInformationResponse.getCustomerBasicDataEnquire().getFirstName()));
        customerDetail.setLastName(formatName(customerInformationResponse.getCustomerBasicDataEnquire().getLastName()));
        return customerDetail;
    }

    public String formatName(String firstName) {
        var capitalized = "";
        if (firstName != null) {
            var toLowerCase = firstName.toLowerCase(Locale.ROOT);
            if (toLowerCase.contains("-")) {
                var stringBuilder = new StringBuilder();
                var parts = toLowerCase.split("-");
                for (var part : parts) {
                    stringBuilder.append(WordUtils.capitalize(part)).append('-');
                }
                capitalized = StringUtils.removeEnd(stringBuilder.toString(), "-");
            } else {
                capitalized = WordUtils.capitalize(toLowerCase);
            }
        }
        return capitalized;
    }


}
