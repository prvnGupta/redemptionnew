package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexity;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules.Rule;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts.RuleComplexAccount;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
@Slf4j
public class RedemptionsFiguresOutputMapper {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    final List<Rule> rules;
    final List<RuleComplexAccount> rulesComplexAccount;
    private final AccountComplexity accountComplexity;

    @Autowired
    public RedemptionsFiguresOutputMapper(List<Rule> rules, List<RuleComplexAccount> rulesComplexAccount, AccountComplexity accountComplexity) {
        this.rules = rules;
        this.rulesComplexAccount = rulesComplexAccount;
        this.accountComplexity = accountComplexity;
    }

    public MortgageIllustrationServiceOutput map(ANMFRedemptionsResponse anmfRedemptionsResponse, String redemptionDate) {
        var output = new MortgageIllustrationServiceOutput();

        if (accountComplexity.isComplex(anmfRedemptionsResponse)) {
            rulesComplexAccount.forEach(rule -> rule.map(anmfRedemptionsResponse, output));
        } else {
            rules.forEach(rule -> rule.map(anmfRedemptionsResponse, output));
            output.setRedemptionDate(redemptionDate);
        }

        logMappingResult(anmfRedemptionsResponse, output);

        return output;
    }

    private void logMappingResult(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput output) {
        log.info("\n===== FromCoreToAggregationMapper ===================================================================\n" +
                        "anmfRedemptionsResponse: {}\n" +
                        "output: {}\n" +
                        "========================================================================================================",
                anmfRedemptionsResponse,
                output);
    }


}
