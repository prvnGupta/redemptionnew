package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexity;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.ComplexAccountReason;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
public class ComplexAccountErrorMapper implements RuleComplexAccount {

    AccountComplexity accountComplexity;

    @Autowired
    public ComplexAccountErrorMapper(AccountComplexity accountComplexity) {
        this.accountComplexity = accountComplexity;
    }

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var errors = anmfRedemptionsResponse.getErrors().stream()
                .filter(error -> accountComplexity.isComplex(error))
                .map(this::convertToReason)
                .collect(Collectors.toList());

        if (errors.size() > 0) {
            mapperOutput.setComplexAccountReasons(errors);
        }
    }

    private ComplexAccountReason convertToReason(RedeptionIllustrationError error) {
        var complexAccountReason = new ComplexAccountReason();
        complexAccountReason.setCode(error.getECode());
        complexAccountReason.setMessage(error.getEMessage());
        return complexAccountReason;
    }
}
