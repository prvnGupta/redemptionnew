package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.CashbackCharge;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.stream.Stream;

@Component
public class BenefitsReclaimMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var feeAmountsSum = feeAmountsSum(anmfRedemptionsResponse);
        mapperOutput.setBenefitsReclaim(feeAmountsSum);
    }

    private BigDecimal feeAmountsSum(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        return getCashbackCharges(anmfRedemptionsResponse)
                .map(CashbackCharge::getFeeAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Stream<CashbackCharge> getCashbackCharges(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getCashbackCharges().stream();
    }
}
