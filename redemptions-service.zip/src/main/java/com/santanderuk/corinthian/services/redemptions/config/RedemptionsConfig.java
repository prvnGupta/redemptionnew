package com.santanderuk.corinthian.services.redemptions.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class RedemptionsConfig {
    @Value("${anmf-region.url}")
    private String anmfRegionUrl;

    @Value("${mortgage-redemption-illustration.url}")
    private String mortgageRedemptionIllustrationUrl;

    @Value("${mortgage-redemption-illustration.request-by}")
    private String mortgageRedemptionIllustrationRequestBy;

    @Value("${mortgage-redemption-illustration.calling-application}")
    private String mortgageRedemptionIllustrationCallingApplication;

    @Value("${mortgage-redemption-illustration.channel-type}")
    private String mortgageRedemptionIllustrationChannelType;

    @Value("${mortgage-redemption-illustration.user-id}")
    private String mortgageRedemptionIllustrationUserId;

    @Value("${mortgage-redemption-illustration.statement-enq}")
    private String mortgageRedemptionIllustrationStatementEnq;

    @Value("${anmf.services.customerservice}")
    private String anmfCustomerServiceUrl;

    @Value("${anmf.services.propertyservice}")
    private String anmfPropertyServiceUrl;

    @Value("${operativesecurity}")
    private boolean operativeSecurity;

    @Value("${event-dispatcher-health-endpoint}")
    private String eventDispatcherHealthEndpoint;

    @Value("${mortgage-redemption.future-date-range}")
    private int redemptionDateRange;

    @Value("${customers-information.url}")
    private String customerInformationUrl;

    @Value("${sort-code}")
    private String defaultSortCode;

    @Value("${anmf.services.account-details}")
    private String anmfAccountInfoUrl;

}
