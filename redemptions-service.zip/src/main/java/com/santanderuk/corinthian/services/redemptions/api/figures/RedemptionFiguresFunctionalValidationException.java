package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class RedemptionFiguresFunctionalValidationException extends GeneralException {

    public RedemptionFiguresFunctionalValidationException(final RedemptionFiguresFunctionalValidationException.Type type) {
        super(type.getCode(), type.getMessage());
    }

    public RedemptionFiguresFunctionalValidationException(final RedemptionFiguresFunctionalValidationException.Type type, final Exception exception) {
        super(type.getCode(), type.getMessage(), exception);
    }

    public enum Type {

        REDEMPTION_DATE_NOT_IN_RANGE("REDEMPTION_DATE_NOT_IN_RANGE", "Selected redemption date has to be between today and configured date range");

        private final String code;
        private final String message;

        Type(final String code, final String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }
    }
}
