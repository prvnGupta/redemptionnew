package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OErcDetailsGrp;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OErcStepDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static java.time.format.DateTimeFormatter.ofPattern;

@Component
@Slf4j
public class ErcPdfDetailsService {
    private final AnmfCoreClient anmfCoreClient;
    private final RedemptionsConfig config;
    private final AnmfRegionClient anmfRegionClient;

    @Autowired
    public ErcPdfDetailsService(AnmfCoreClient anmfCoreClient, RedemptionsConfig config, AnmfRegionClient anmfRegionClient) {
        this.anmfCoreClient = anmfCoreClient;
        this.config = config;
        this.anmfRegionClient = anmfRegionClient;
    }

    public String getErcPdfDetails(int mortgageAccount) {
        try {
            AnmfAccountServiceResponse anmfAccountServiceResponse = anmfCoreClient.fetchMortgageAccountDetailsV5(mortgageAccount, config.getAnmfAccountInfoUrl(), anmfRegionClient.fetchCurrentRegion());
            return generateErcPdfDetails(anmfAccountServiceResponse);
        } catch (Exception e) {
            log.warn("Exception while extracting mortgage account details");
            return "";
        }
    }

    private String generateErcPdfDetails(AnmfAccountServiceResponse anmfAccountServiceResponse) {
        String ercSentence = "";
        OStruc oStruc = anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc();
        if (oStruc.getOActiveLoanCount() == 1 && oStruc.getOActiveLoanDetails().get(0).getOErcDetailsGrp().getOErcApplFlag().equals("Y")) {
            ercSentence = "This charge will no longer apply from " + formatDate(oStruc.getOActiveLoanDetails().get(0).getOProductEndDate());
        }
        return ercSentence;
    }

    private String formatDate(String ercEndDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return LocalDate.parse(ercEndDate, formatter).format(ofPattern("d MMMM yyyy"));
    }

}
