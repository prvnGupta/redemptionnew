package com.santanderuk.corinthian.services.redemptions.api.eligibility;

import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.redemptions.api.BaseController;
import com.santanderuk.corinthian.services.redemptions.api.eligibility.io.RedemptionEligibilityOutput;
import com.santanderuk.corinthian.services.redemptions.api.eligibility.io.RedemptionEligibilityOutputWrapper;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class RedemptionEligibilityController extends BaseController {

    private final RedemptionEligibilityService redemptionEligibilityService;
    private final AnmfRegionClient anmfRegionClient;

    @Autowired
    public RedemptionEligibilityController(RedemptionEligibilityService redemptionEligibilityService, RedemptionsConfig redemptionsConfig, AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService, AnmfRegionClient anmfRegionClient) {
        super(redemptionsConfig, anmfBelongToCustomerWithBorrowerListService);
        this.redemptionEligibilityService = redemptionEligibilityService;
        this.anmfRegionClient = anmfRegionClient;
    }

    @ApiOperation(
            value = "Endpoint to check if a mortgage is eligible to access Redemptions Journey in Corinthian application",
            nickname = "getEligibility",
            notes = "This endpoint is used to check if a customer/mortgage account is eligible to see the redemptions figures in Corinthian app.\n\n" +
                    "It receives the ANMF account Number as a path parameter. For further info:\n\n\n\n" +
                    "https://confluence.almuk.santanderuk.corp/x/RUFBD\n\n"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = RedemptionEligibilityOutputWrapper.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @GetMapping(
            value = "/{account}/eligibility",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<RedemptionEligibilityOutputWrapper> getEligibility(
            @PathVariable("account") int account,
            @RequestHeader(name = "Authorization") String jwtToken) throws MaintenanceException, OperativeSecurityException, ConnectionException, ValidationsException, IOException {

        AnmfRegion anmfRegion = anmfRegionClient.fetchCurrentRegion();
        checkOperativeSecurity(account, jwtToken, anmfRegion);


        var data = new RedemptionEligibilityOutput();
        if (anmfRegion == AnmfRegion.A) {
            data = redemptionEligibilityService.get(account);
        }
        data.setAnmfRegion(anmfRegion);

        return new ResponseEntity<>(createResponseBody(data), HttpStatus.OK);
    }

    private RedemptionEligibilityOutputWrapper createResponseBody(RedemptionEligibilityOutput data) {
        var info = ServiceInfoCreator.ok();
        return new RedemptionEligibilityOutputWrapper(data, info);
    }
}
