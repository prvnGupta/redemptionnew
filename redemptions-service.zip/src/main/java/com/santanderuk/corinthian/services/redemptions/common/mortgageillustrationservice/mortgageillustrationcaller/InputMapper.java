package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsInput;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class InputMapper {

    final RedemptionsConfig config;

    @Autowired
    public InputMapper(RedemptionsConfig config) {
        this.config = config;
    }

    public RedemptionsInput map(int account, String redemptionDate) {
        var redemptionsInput = createRedemptionsInput();

        addUrl(redemptionsInput);

        addAccount(redemptionsInput, account);
        addRedemptionDate(redemptionsInput, redemptionDate);

        // static values from the config file
        addRequestBy(redemptionsInput);
        addCallingApplication(redemptionsInput);
        addChannelType(redemptionsInput);
        addUserId(redemptionsInput);
        addStatementEq(redemptionsInput);

        return redemptionsInput;
    }

    private RedemptionsInput createRedemptionsInput() {
        var redemptionsInput = new RedemptionsInput();
        var request = new ANMFRedemptionsRequest();

        redemptionsInput.setRequest(request);

        return redemptionsInput;
    }

    private void addUrl(RedemptionsInput redemptionsInput) {
        redemptionsInput.setUrl(config.getMortgageRedemptionIllustrationUrl());
    }

    private void addAccount(RedemptionsInput redemptionsInput, int account) {
        var accountAsString = String.valueOf(account);
        redemptionsInput.getRequest().setAccountNumber(accountAsString);
    }

    private void addRedemptionDate(RedemptionsInput redemptionsInput, String redemptionDate) {
        redemptionsInput.getRequest().setRedemptionDate(redemptionDate);
    }

    private void addRequestBy(RedemptionsInput redemptionsInput) {
        var requestBy = config.getMortgageRedemptionIllustrationRequestBy();
        redemptionsInput.getRequest().setRequestedBy(requestBy);
    }

    private void addCallingApplication(RedemptionsInput redemptionsInput) {
        var callingApplication = config.getMortgageRedemptionIllustrationCallingApplication();
        redemptionsInput.getRequest().setCallingApplication(callingApplication);
    }

    private void addChannelType(RedemptionsInput redemptionsInput) {
        var channelType = config.getMortgageRedemptionIllustrationChannelType();
        redemptionsInput.getRequest().setChannelType(channelType);
    }

    private void addUserId(RedemptionsInput redemptionsInput) {
        var userId = config.getMortgageRedemptionIllustrationUserId();
        redemptionsInput.getRequest().setUserId(userId);
    }

    private void addStatementEq(RedemptionsInput redemptionsInput) {
        var statementEnq = config.getMortgageRedemptionIllustrationStatementEnq();
        redemptionsInput.getRequest().setStatementEnq(statementEnq);
    }
}
