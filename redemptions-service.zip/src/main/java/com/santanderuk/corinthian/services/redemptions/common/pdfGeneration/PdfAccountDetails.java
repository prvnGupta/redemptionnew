package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PdfAccountDetails {

    private String names;

    private String address;

}
