package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;

public interface RuleComplexAccount {

    void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput);
}
