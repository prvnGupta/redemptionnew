package com.santanderuk.corinthian.services.redemptions.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectMapper;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.commons.utilities.LoggingRequestInterceptor;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

@Configuration
public class BeanConfig {

    @Bean
    public AnmfCoreClient anmfCoreClient() {
        return new AnmfCoreClient(objectMapper(), redemptionsRestTemplate(), apiManagerConfig());
    }


    @Bean("redemptionsRestTemplate")
    public RestTemplate redemptionsRestTemplate() {
        var restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        var interceptors = new ArrayList<ClientHttpRequestInterceptor>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }


    @Bean
    public ApiManagerConfig apiManagerConfig() {
        return new ApiManagerConfig();
    }

    @Bean
    ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    AnmfRegionClient anmfRegionClient() {
        return new AnmfRegionClient(redemptionsRestTemplate());
    }

    @Bean
    AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithCustomerInformationListService() {
        return new AnmfBelongToCustomerWithBorrowerListService();
    }

    @Bean
    Validations validations() {
        return new Validations();
    }

    @Bean
    public BksConnectMapper bksConnectMapper() {
        return new BksConnectMapper();
    }

    @Bean
    public BksConnectClient bksConnectClient() {
        return new BksConnectClient(apiManagerConfig(), redemptionsRestTemplate(), bksConnectMapper());
    }

    @Bean
    public CustomerInformationClient customerInformationClient() {
        return new CustomerInformationClient(redemptionsRestTemplate(), apiManagerConfig());
    }
}
