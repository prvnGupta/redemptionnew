package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MortgageIllustrationServiceOutput extends ModelBase {

    private static final long serialVersionUID = -4970360084565116553L;

    private AnmfRegion anmfRegion;

    @JsonProperty("redemptionDate")
    private String redemptionDate;

    @JsonProperty("totalToRepay")
    private BigDecimal totalToRepay;

    @JsonProperty("benefitsReclaim")
    private BigDecimal benefitsReclaim;

    @JsonProperty("earlyRepaymentCharge")
    private EarlyRepaymentCharge earlyRepaymentCharge;

    @JsonProperty("creditsToAccountOverpayments")
    private BigDecimal creditsToAccountOverpayments;

    @JsonProperty("unclearAmounts")
    private UnclearAmounts unclearAmounts;

    @JsonProperty("dailyInterest")
    private BigDecimal dailyInterest;

    @JsonProperty("interestSinceLastPayment")
    private BigDecimal interestSinceLastPayment;

    @JsonProperty("outstandingBalance")
    private OutstandingBalance outstandingBalance;

    @JsonProperty("mortgageAccountFee")
    private BigDecimal mortgageAccountFee;

    @JsonProperty("complexAccountReasons")
    private List<ComplexAccountReason> complexAccountReasons;

    private String base64Pdf;
}
