package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsOutput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class InterestSinceLastPaymentMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var totalDailyInterestAmount = getTotalInterestAmount(anmfRedemptionsResponse);
        mapperOutput.setInterestSinceLastPayment(totalDailyInterestAmount);
    }

    private BigDecimal getTotalInterestAmount(ANMFRedemptionsResponse anmfRedemptionsResponse) {

        RedemptionsOutput outputStruc = anmfRedemptionsResponse.getMBSORRSTOperationResponse()
                .getOutputStruc();
        return outputStruc.getTotalInterestAmount().add(outputStruc.getSundry().getInterestAmount());
    }
}
