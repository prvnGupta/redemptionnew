package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PDFContextData {
    private List<BreakDownData> breakDownDataList;
    private String unclearedAmounts;
    private String payments;
    private String overpayments;
    private String sundries;
    private String repayableBenefits;
    private String interestSinceLastPayment;
    private String mortgageAccountFee;
    private String overdueAmounts;
    private String otherCosts;
    private String recentOverpayments;
    private String totalToRepay;
}
