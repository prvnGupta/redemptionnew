package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.Loans;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.EarlyRepaymentCharge;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.EarlyRepaymentChargeDetails;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class EarlyRepaymentChargeMapper implements Rule {

    @Override
    public void map(ANMFRedemptionsResponse anmfRedemptionsResponse, MortgageIllustrationServiceOutput mapperOutput) {

        var earlyRepaymentCharge = new EarlyRepaymentCharge();

        addTotal(anmfRedemptionsResponse, earlyRepaymentCharge);
        addDetails(anmfRedemptionsResponse, earlyRepaymentCharge);

        mapperOutput.setEarlyRepaymentCharge(earlyRepaymentCharge);
    }

    private void addTotal(ANMFRedemptionsResponse anmfRedemptionsResponse, EarlyRepaymentCharge earlyRepaymentCharge) {

        var feeAmountSum = getLoansStream(anmfRedemptionsResponse)
                .map(Loans::getFeeAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        earlyRepaymentCharge.setTotal(feeAmountSum);
    }

    private void addDetails(ANMFRedemptionsResponse anmfRedemptionsResponse, EarlyRepaymentCharge earlyRepaymentCharge) {

        var list = getLoansStream(anmfRedemptionsResponse)
                .map(this::convertToEarlyRepaymentChargeDetail)
                .collect(Collectors.toList());

        earlyRepaymentCharge.setEarlyRepaymentChargeDetails(list);
    }

    private EarlyRepaymentChargeDetails convertToEarlyRepaymentChargeDetail(Loans loan) {

        var detail = new EarlyRepaymentChargeDetails();
        detail.setBalance(loan.getCapitalBalance());
        detail.setInterestRate(loan.getLsRate());
        detail.setEarlyRepaymentCharge(loan.getFeeAmount());
        return detail;
    }

    private Stream<Loans> getLoansStream(ANMFRedemptionsResponse anmfRedemptionsResponse) {
        return anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc().getLoans().stream();
    }
}
