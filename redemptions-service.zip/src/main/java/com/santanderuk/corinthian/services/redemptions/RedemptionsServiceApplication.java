package com.santanderuk.corinthian.services.redemptions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class RedemptionsServiceApplication {

    public static void main(String[] argv) {
        SpringApplication.run(RedemptionsServiceApplication.class, argv);
    }
}
