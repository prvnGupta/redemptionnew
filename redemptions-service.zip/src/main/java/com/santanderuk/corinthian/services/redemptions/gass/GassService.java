package com.santanderuk.corinthian.services.redemptions.gass;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.EarlyRepaymentChargeDetails;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.config.GASSConfig;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
@Service
@Slf4j
public class GassService {

    private static final String ANMF_SORTCODE = "091586";
    private static final String ANMF_DATE_FORMAT = "dd/MM/yyyy";
    private static final String GASS_DATE_FORMAT = "dd-MM-yyyy";
    private final GASSClient gassClient;
    private final GASSConfig gassConfig;
    private final BksConnectClient bksConnectClient;

    @Value("${bksconnect.endpoints.retrievemcc}")
    private String retrieveMccUrl;

    public GassService(BksConnectClient bksConnectClient, GASSClient gassClient, GASSConfig gassConfig) {
        this.bksConnectClient = bksConnectClient;
        this.gassClient = gassClient;
        this.gassConfig = gassConfig;
    }

    @Async
    public void auditViewRedemptionsFigure(int account, AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList, String jwtToken, HttpServletRequest servletRequest, MortgageIllustrationServiceOutput output) {

        try {
            String customerNumber = buildCustomerNumber(jwtToken);
            String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtToken);
            String ipAddress = extractIpAddress(servletRequest);
            String mccId = getMCCId(ldapUid);
            GASSMessageData gassMessage = generateGassMessage(ipAddress, anmfBelongsToCustomerWithBorrowerList, customerNumber, mccId, ldapUid, output, account);
            gassClient.send(gassMessage, true);
        } catch (Exception e) {
            log.error("Error while auditing View Redemption Figures to GAAS");
        }

    }

    private GASSMessageData generateGassMessage(String ipAddress, AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList, String customerId, String mccId, String ldapUid, MortgageIllustrationServiceOutput output, int account) {
        GASSMessageData gassMessageData = setCommonGassData(ipAddress, customerId, mccId, ldapUid, account);
        String formatData = setFormatData(customerId, anmfBelongsToCustomerWithBorrowerList, mccId, output, account);
        setViewRedemptionsFigureData(formatData, gassMessageData);
        return gassMessageData;
    }

    private void setViewRedemptionsFigureData(String formatData, GASSMessageData gassMessageData) {
        gassMessageData.setAuditTrnTpName(gassConfig.getTransactionNameViewRedemptionsFigure());

        String sbFrmtdData = "<formattedData>" +
                formatData +
                "</formattedData>";
        gassMessageData.setFormattedData(sbFrmtdData);
    }

    private String setFormatData(String customerId, AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList, String mccId, MortgageIllustrationServiceOutput output, int account) {
        StringBuilder sbFrmtdData = new StringBuilder(2500);
        sbFrmtdData.append("<CustomerNumber>");
        sbFrmtdData.append(customerId);
        sbFrmtdData.append("</CustomerNumber>");
        sbFrmtdData.append("<BorrowersList>");
        sbFrmtdData.append(generateBorrowerList(anmfBelongsToCustomerWithBorrowerList));
        sbFrmtdData.append("</BorrowersList>");
        sbFrmtdData.append("<MCCID>");
        sbFrmtdData.append(mccId);
        sbFrmtdData.append("</MCCID>");
        sbFrmtdData.append("<MortgageAccountNumber>");
        sbFrmtdData.append(account);
        sbFrmtdData.append("</MortgageAccountNumber>");

        sbFrmtdData.append("<DateRequested>");
        String gassFormattedDate = getGassFormattedDate(output);
        sbFrmtdData.append(gassFormattedDate);
        sbFrmtdData.append("</DateRequested>");

        if (!isComplex(output)) {
            addRedemtionFiguresToFormattedData(output, sbFrmtdData);
        }

        return sbFrmtdData.toString();
    }

    private String getGassFormattedDate(MortgageIllustrationServiceOutput output) {
        try {


            String gassFormattedDate;
            SimpleDateFormat sdf = new SimpleDateFormat(ANMF_DATE_FORMAT);
            Date d = sdf.parse(output.getRedemptionDate());
            sdf.applyPattern(GASS_DATE_FORMAT);
            gassFormattedDate = sdf.format(d);
            return gassFormattedDate;

        } catch (Exception e) {
            log.warn("Error formatting the date for GASS", e);
            return "";
        }
    }

    private boolean isComplex(MortgageIllustrationServiceOutput output) {
        try {
            return output.getComplexAccountReasons().size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void addRedemtionFiguresToFormattedData(MortgageIllustrationServiceOutput output, StringBuilder sbFrmtdData) {
        sbFrmtdData.append("<TotalRedemptionFigure>");
        sbFrmtdData.append(output.getTotalToRepay());
        sbFrmtdData.append("</TotalRedemptionFigure>");

        sbFrmtdData.append("<loanList>");
        sbFrmtdData.append(generateLoanList(output));
        sbFrmtdData.append("</loanList>");

        sbFrmtdData.append("<MortgageAccountFee>");
        sbFrmtdData.append(output.getMortgageAccountFee());
        sbFrmtdData.append("</MortgageAccountFee>");

        sbFrmtdData.append("<MortgageInterest>");
        sbFrmtdData.append(output.getInterestSinceLastPayment());
        sbFrmtdData.append("</MortgageInterest>");

        sbFrmtdData.append("<OtherCost>");
        sbFrmtdData.append(output.getOutstandingBalance().getOtherCostsSundries());
        sbFrmtdData.append("</OtherCost>");

        sbFrmtdData.append("<DailyInterest>");
        sbFrmtdData.append(output.getDailyInterest());
        sbFrmtdData.append("</DailyInterest>");
    }

    private StringBuilder generateLoanList(MortgageIllustrationServiceOutput output) {
        StringBuilder loanList = new StringBuilder(2500);
        output.getEarlyRepaymentCharge().getEarlyRepaymentChargeDetails().forEach(loan -> generateLoan(loan, loanList));
        return loanList;
    }

    private void generateLoan(EarlyRepaymentChargeDetails loan, StringBuilder loanList) {

        loanList.append("<loan>");
        loanList.append("<capitalBalance>");
        loanList.append(loan.getBalance());
        loanList.append("</capitalBalance>");
        loanList.append("<erc>");
        loanList.append(loan.getEarlyRepaymentCharge());
        loanList.append("</erc>");
        loanList.append("</loan>");

    }

    private StringBuilder generateBorrowerList(AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList) {
        StringBuilder borrowerList = new StringBuilder(2500);
        anmfBelongsToCustomerWithBorrowerList.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().forEach(borrower -> addBorrower(borrower, borrowerList));
        return borrowerList;
    }

    private void addBorrower(OCustomer borrower, StringBuilder borrowerList) {
        borrowerList.append("<borrower>");
        borrowerList.append("<name>");
        borrowerList.append(formatName(borrower));
        borrowerList.append("</name>");
        borrowerList.append("<customerType>");
        borrowerList.append(borrower.getOBdpType());
        borrowerList.append("</customerType>");
        borrowerList.append("<customerCode>");
        borrowerList.append(borrower.getOCustomerId());
        borrowerList.append("</customerCode>");
        borrowerList.append("</borrower>");

    }


    public GASSMessageData setCommonGassData(String ipAddress, String customerId, String mccId, String ldapUid, int anmfAccountNumber) {

        GASSMessageData gassMessageData = new GASSMessageData();

        gassMessageData.setDeviceId(ipAddress);

        gassMessageData.setAppSysId(Integer.parseInt(gassConfig.getAppSysIdInternet()));
        gassMessageData.setDeviceTyp(Integer.parseInt(gassConfig.getDvcTypInternet()));

        gassMessageData.setCustomerId(customerId);
        gassMessageData.setUserId(customerId);
        gassMessageData.setLdapUid(ldapUid);
        gassMessageData.setMccId(mccId);

        gassMessageData.setAnmfAccount(ANMF_SORTCODE + " " + anmfAccountNumber);

        return gassMessageData;
    }


    public String getMCCId(String ldapUid) {
        String mccId;
        try {
            mccId = fetchMccID(ldapUid);
        } catch (Exception ex) {
            mccId = "";
        }

        return mccId;
    }

    private String fetchMccID(String ldapUid) {
        try {
            RetrieveMccResponse retrieveMccResponse = bksConnectClient.getMccFromLdapUid(retrieveMccUrl, ldapUid);
            return buildMccId(retrieveMccResponse);
        } catch (GeneralException e) {
            log.error("Failed to get MCC response due to :", e);
        }
        return "";
    }

    private String buildMccId(RetrieveMccResponse retrieveMccResponse) {
        PartenonContract partenonContract = retrieveMccResponse.getDataResponse().getMccContract().getPartenonContract();
        String partenonContractGass = "";
        if (partenonContract != null) {
            if (partenonContract.getCentre().getCompany() != null) {
                partenonContractGass += partenonContract.getCentre().getCompany() + " ";
            }
            if (partenonContract.getCentre().getCentreCode() != null) {
                partenonContractGass += partenonContract.getCentre().getCentreCode() + " ";
            }
            if (partenonContract.getProductTypeCode() != null) {
                partenonContractGass += partenonContract.getProductTypeCode() + " ";
            }
            if (partenonContract.getContractNumber() != null) {
                partenonContractGass += partenonContract.getContractNumber();
            }
        }
        return partenonContractGass;
    }

    private String buildCustomerNumber(String jwtToken) {
        BdpCustomer bdpCustomerFromJWT = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        String customerType = bdpCustomerFromJWT.getCustomerType();
        int customerNumber = bdpCustomerFromJWT.getCustomerNumber();
        return String.format("%s%d", customerType, customerNumber);
    }

    private String extractIpAddress(HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("X-FORWARDED-FOR");
        return StringUtils.isBlank(ipAddress) ? "127.0.0.1" : ipAddress;
    }


    private String formatName(final OCustomer currentCustomer) {

        String name = formatAttribute(currentCustomer.getOCustomerTitle()) +
                formatAttribute(currentCustomer.getOForename1()) +
                formatAttribute(currentCustomer.getOForename2()) +
                formatAttribute(currentCustomer.getOForename3()) +
                formatAttribute(currentCustomer.getOSurname());
        return name.trim();
    }

    private String formatAttribute(final String attribute) {
        if (attributeIsEmpty(attribute)) {
            return "";
        } else {
            return attribute + " ";
        }
    }

    private boolean attributeIsEmpty(final String attribute) {
        return attribute == null || attribute.trim().equalsIgnoreCase("");
    }

}
