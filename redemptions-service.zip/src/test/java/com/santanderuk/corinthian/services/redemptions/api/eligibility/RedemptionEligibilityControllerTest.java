package com.santanderuk.corinthian.services.redemptions.api.eligibility;

import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.api.eligibility.io.RedemptionEligibilityOutput;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient.MAINTENANCE_REGION_X;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(SpringExtension.class)
class RedemptionEligibilityControllerTest {

    @Mock
    public AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;
    RedemptionEligibilityController controller;
    @Mock
    RedemptionEligibilityService service;
    @Mock
    RedemptionsConfig config;
    @Mock
    AnmfRegionClient mockAnmfRegionClient;

    @BeforeEach
    void setUp() {
        controller = new RedemptionEligibilityController(service, config, anmfBelongToCustomerWithBorrowerListService, mockAnmfRegionClient);
    }

    @Test
    void happyPathWithRegionA() throws ConnectionException, MaintenanceException, ValidationsException, OperativeSecurityException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(true);


        var redemptionEligibilityOutput = new RedemptionEligibilityOutput();
        when(service.get(anyInt())).thenReturn(redemptionEligibilityOutput);

        int account = 123;
        var responseEntity = controller.getEligibility(account, "jwt");

        assertNotNull(responseEntity);

        // verify we are sending the account passed to the controller to the service
        var integerArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        verify(service).get(integerArgumentCaptor.capture());
        assertEquals(account, integerArgumentCaptor.getValue());

        // Verify the object in the wrapper is the one returned by the service
        assertEquals(redemptionEligibilityOutput, responseEntity.getBody().getData());

        // Http status
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        // Verify the info block
        assertNotNull(responseEntity.getBody().getInfo());
        assertEquals("ok", responseEntity.getBody().getInfo().getStatus());
        assertEquals("", responseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", responseEntity.getBody().getInfo().getMessage());
        assertNotEquals("", responseEntity.getBody().getInfo().getTimestamp());
    }

    @Test
    void happyPathWithRegionW() throws ConnectionException, MaintenanceException, ValidationsException, OperativeSecurityException, IOException {

        mockAnmfRegion(AnmfRegion.W);

        int account = 123;
        var responseEntity = controller.getEligibility(account, "jwt");

        assertNotNull(responseEntity);

        assertEquals(AnmfRegion.W, responseEntity.getBody().getData().getAnmfRegion());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody().getInfo());
        assertEquals("ok", responseEntity.getBody().getInfo().getStatus());
        assertEquals("", responseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", responseEntity.getBody().getInfo().getMessage());
        assertNotEquals("", responseEntity.getBody().getInfo().getTimestamp());
    }

    @Test
    void serviceThrowsConnectionException() throws ConnectionException, MaintenanceException, ValidationsException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(true);


        var connectionException = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE);
        when(service.get(anyInt())).thenThrow(connectionException);


        var exceptionThrown = assertThrows(
                ConnectionException.class,
                () -> controller.getEligibility(123, "")
        );

        assertEquals("ANMF_UNAVAILABLE", exceptionThrown.getCode());
        assertEquals("ANMF did not respond correctly", exceptionThrown.getMessage());
    }

    @Test
    void operativeSecurityIsDisabledSoPassAnyway() throws ConnectionException, MaintenanceException, OperativeSecurityException, ValidationsException, IOException {

        mockAnmfRegion(AnmfRegion.A);
        mockOperativeSecurity(false);


        var redemptionEligibilityOutput = new RedemptionEligibilityOutput();
        when(service.get(anyInt())).thenReturn(redemptionEligibilityOutput);

        int account = 123;
        var responseEntity = controller.getEligibility(account, "jwt");

        assertNotNull(responseEntity);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    void heartbeatFailsSoWeWillHaveAConnectionException() throws ConnectionException, MaintenanceException {

        mockOperativeSecurity(true);
        mockAnmfRegionWithConnectionException();

        var exceptionThrown = assertThrows(
                ConnectionException.class,
                () -> controller.getEligibility(123, "jwt")
        );

        assertEquals("HEARTBEAT_CONNECTION_ERROR", exceptionThrown.getCode());
        assertEquals("An error occurred when trying to connect with heartbeat", exceptionThrown.getMessage());
    }

    @Test
    void heartbeatInMaintenance() throws ConnectionException, MaintenanceException {

        mockOperativeSecurity(true);
        mockAnmfRegionMaintenance();

        var exceptionThrown = assertThrows(
                MaintenanceException.class,
                () -> controller.getEligibility(123, "jwt")
        );

        assertEquals("MAINTENANCE_REGION_X", exceptionThrown.getCode());
        assertEquals("Maintenance region X", exceptionThrown.getMessage());
    }

    @Test
    void doesntBelongToCustomer() throws ConnectionException, MaintenanceException, ValidationsException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(false);


        var exceptionThrown = assertThrows(
                OperativeSecurityException.class,
                () -> controller.getEligibility(123, "jwt")
        );

        assertEquals("SECURITY_KO", exceptionThrown.getCode());
        assertEquals("Mortgage does not belong to customer", exceptionThrown.getMessage());
    }

    private void mockOperativeSecurity(boolean value) {
        when(config.isOperativeSecurity()).thenReturn(value);
    }

    private void mockAnmfRegion(AnmfRegion region) throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenReturn(region);
    }

    private void mockAnmfRegionMaintenance() throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenThrow(new MaintenanceException(MAINTENANCE_REGION_X));
    }

    private void mockAnmfRegionWithConnectionException() throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenThrow(new ConnectionException(ConnectionException.Type.HEARTBEAT_CONNECTION_ERROR));
    }

    private void mockBelongsToCustomer(boolean value) throws ValidationsException, ConnectionException, IOException {
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(anyInt(), any(), any(), any())).thenReturn(TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(value));
    }
}
