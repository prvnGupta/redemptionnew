package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class FromAggregationToCoreMapperTestData {

    public static ANMFRedemptionsResponse createAnmfRedemptionsResponse() {
        ANMFRedemptionsResponse anmfRedemptionsResponse = createAnmfRedemptionEmpty();

        var output = anmfRedemptionsResponse.getMBSORRSTOperationResponse().getOutputStruc();

        output.setRedemptionAmount(BigDecimal.valueOf(123.12));

        var loans = createLoans();
        output.setLoans(loans);

        var overpayment = new Balance();
        overpayment.setUnclearAmount(BigDecimal.valueOf(56));
        overpayment.setCapitalBalance(BigDecimal.valueOf(72));
        output.setOverpayment(overpayment);

        var sundry = new Sundry();
        sundry.setUnclearAmount(BigDecimal.valueOf(57));
        sundry.setArrearsBalance(BigDecimal.valueOf(60));
        sundry.setInterestAmount(BigDecimal.valueOf(10));
        output.setSundry(sundry);

        output.setTotalInterestAmount(BigDecimal.valueOf(133.27));
        output.setDeedHandlingFee(BigDecimal.valueOf(213.45));


        List<CashbackCharge> cashbackCharges = new ArrayList<>();

        CashbackCharge cashbackCharge1 = new CashbackCharge();
        cashbackCharge1.setFeeAmount(BigDecimal.valueOf(4));
        cashbackCharges.add(cashbackCharge1);

        CashbackCharge cashbackCharge2 = new CashbackCharge();
        cashbackCharge2.setFeeAmount(BigDecimal.valueOf(5));
        cashbackCharges.add(cashbackCharge2);

        output.setCashbackCharges(cashbackCharges);

        output.setDailyAmount(BigDecimal.valueOf(7.01));

        return anmfRedemptionsResponse;
    }

    private static List<Loans> createLoans() {
        var loans = new ArrayList<Loans>();

        var loan1 = new Loans();
        loan1.setCapitalBalance(BigDecimal.valueOf(100));
        loan1.setArrearsBalance(BigDecimal.valueOf(1));
        loan1.setFeeAmount(BigDecimal.valueOf(10));
        loan1.setUnclearAmount(BigDecimal.valueOf(25));
        loan1.setInterestAmount(new BigDecimal("209.11"));
        loan1.setLsRate(new BigDecimal("1.25"));
        loans.add(loan1);

        var loan2 = new Loans();
        loan2.setCapitalBalance(BigDecimal.valueOf(200));
        loan2.setArrearsBalance(BigDecimal.valueOf(2));
        loan2.setFeeAmount(BigDecimal.valueOf(20));
        loan2.setUnclearAmount(BigDecimal.valueOf(26));
        loan2.setInterestAmount(new BigDecimal("111.11"));
        loan2.setLsRate(new BigDecimal("2.36"));


        loans.add(loan2);


        return loans;
    }

    public static ANMFRedemptionsResponse createAnmfRedemptionEmpty() {
        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        var operation = new MBSORRSTOperationResponse();
        var outputStruct = new RedemptionsOutput();
        operation.setOutputStruc(outputStruct);
        anmfRedemptionsResponse.setMBSORRSTOperationResponse(operation);
        return anmfRedemptionsResponse;
    }

    public static ANMFRedemptionsResponse createAnmfRedemptionsResponseWithError() {
        var anmfRepemptionEmpty = createAnmfRedemptionEmpty();
        var errors = new ArrayList<RedeptionIllustrationError>();
        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");
        errors.add(error);

        var error2 = new RedeptionIllustrationError();
        error2.setECode("ERR21502");
        error2.setEMessage("First DD payment not received");
        errors.add(error2);

        anmfRepemptionEmpty.setErrors(errors);
        return anmfRepemptionEmpty;
    }
}
