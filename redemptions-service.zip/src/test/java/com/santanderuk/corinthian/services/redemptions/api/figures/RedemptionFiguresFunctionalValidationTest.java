package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RedemptionFiguresFunctionalValidationTest {

    public static final RedemptionFiguresFunctionalValidationException.Type REDEMPTION_DATE_NOT_IN_RANGE = RedemptionFiguresFunctionalValidationException.Type.REDEMPTION_DATE_NOT_IN_RANGE;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    RedemptionFiguresFunctionalValidation validation;

    @Mock
    private RedemptionsConfig redemptionsConfig;

    @BeforeEach
    void setUp() {
        validation = new RedemptionFiguresFunctionalValidation(redemptionsConfig);
    }

    @Test
    void todayIsOk() throws RedemptionFiguresFunctionalValidationException {
        var today = LocalDate.now().format(FORMATTER);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(today);

        validation.validate(request);
    }

    @Test
    void tomorrowIsOk() throws RedemptionFiguresFunctionalValidationException {
        var tomorrow = LocalDate.now().plusDays(1).format(FORMATTER);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(tomorrow);

        when(redemptionsConfig.getRedemptionDateRange()).thenReturn(30);
        validation.validate(request);
    }

    @Test
    void after30daysIsOk() throws RedemptionFiguresFunctionalValidationException {
        var tomorrow = LocalDate.now().plusDays(30).format(FORMATTER);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(tomorrow);

        when(redemptionsConfig.getRedemptionDateRange()).thenReturn(30);
        validation.validate(request);
    }

    @Test
    void yesterdayIsKO() {
        var tomorrow = LocalDate.now().minusDays(1).format(FORMATTER);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(tomorrow);

        var exception = assertThrows(
                RedemptionFiguresFunctionalValidationException.class,
                () -> validation.validate(request)
        );

        assertEquals(REDEMPTION_DATE_NOT_IN_RANGE.getCode(), exception.getCode());
        assertEquals(REDEMPTION_DATE_NOT_IN_RANGE.getMessage(), exception.getMessage());
    }

    @Test
    void after31InFutureIsKO() {
        var tomorrow = LocalDate.now().plusDays(31).format(FORMATTER);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(tomorrow);

        var exception = assertThrows(
                RedemptionFiguresFunctionalValidationException.class,
                () -> validation.validate(request)
        );

        assertEquals(REDEMPTION_DATE_NOT_IN_RANGE.getCode(), exception.getCode());
        assertEquals(REDEMPTION_DATE_NOT_IN_RANGE.getMessage(), exception.getMessage());
    }
}
