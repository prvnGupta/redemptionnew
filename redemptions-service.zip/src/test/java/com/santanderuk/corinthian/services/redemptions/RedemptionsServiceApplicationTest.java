package com.santanderuk.corinthian.services.redemptions;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class RedemptionsServiceApplicationTest {
    @Test
    public void contextLoads() {
    }
}
