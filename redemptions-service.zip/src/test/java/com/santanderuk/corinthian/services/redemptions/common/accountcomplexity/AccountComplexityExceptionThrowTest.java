package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
class AccountComplexityExceptionThrowTest {

    private AccountComplexity accountComplexity;

    @BeforeEach
    void setUp() {
        accountComplexity = new AccountComplexity();
    }

    @Test
    void exceptionNoErrorsArrayIsNull() {
        ANMFRedemptionsResponse anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        anmfRedemptionsResponse.setErrors(null);

        assertDoesNotThrow(() -> accountComplexity.check(anmfRedemptionsResponse));
    }

    @Test
    void exceptionNoErrorsObjectArrayIsEmpty() {
        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        var emptyList = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionsResponse.setErrors(emptyList);

        assertDoesNotThrow(() -> accountComplexity.check(anmfRedemptionsResponse));

    }

    @Test
    void exceptionThereIsAnErrorButIsNotFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("CODE");
        error.setEMessage("MESSAGE");
        anmfRedemptionsResponse.getErrors().add(error);

        assertDoesNotThrow(() -> accountComplexity.check(anmfRedemptionsResponse));

    }

    @Test
    void exceptionThereIsAnErrorFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");
        anmfRedemptionsResponse.getErrors().add(error);

        var exception = assertThrows(
                AccountComplexityException.class,
                () -> accountComplexity.check(anmfRedemptionsResponse)
        );
        assertEquals("EXC_REDEMPTION_COMPLEX_ACCOUNT", exception.getCode());
        assertEquals("The account you are trying to access is a complex one", exception.getMessage());

    }

    @Test
    void exceptionThereIsTwoErrorsFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");
        anmfRedemptionsResponse.getErrors().add(error);

        var error2 = new RedeptionIllustrationError();
        error2.setECode("ERR21513");
        error2.setEMessage("Rights of Consolidation");
        anmfRedemptionsResponse.getErrors().add(error2);

        var exception = assertThrows(
                AccountComplexityException.class,
                () -> accountComplexity.check(anmfRedemptionsResponse)
        );
        assertEquals("EXC_REDEMPTION_COMPLEX_ACCOUNT", exception.getCode());
        assertEquals("The account you are trying to access is a complex one", exception.getMessage());

    }

    private ANMFRedemptionsResponse createResponseWithEmptyList() {
        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        var emptyList = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionsResponse.setErrors(emptyList);
        return anmfRedemptionsResponse;
    }

}
