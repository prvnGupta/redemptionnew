package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
public class ErcPdfDetailsServiceTest {

    ErcPdfDetailsService service;

    @Mock
    AnmfCoreClient anmfCoreClient;

    @Mock
    RedemptionsConfig config;

    @Mock
    AnmfRegionClient anmfRegionClient;

    @BeforeEach
    void setUp() {
        service = new ErcPdfDetailsService(anmfCoreClient, config, anmfRegionClient);
    }

    @Test
    void testSingleLoanWithFlatErc() throws IOException, ConnectionException, MaintenanceException{
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfAccountInfoUrl()).thenReturn("accountInfoUrl");
        Mockito.when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateAccountInfoResponseForSingleLoanFlatErc());

        String ercSentence = service.getErcPdfDetails(123456789);

        assertEquals("This charge will no longer apply from 2 April 2023", ercSentence);
    }

    @Test
    void testSingleLoanWithNoErc() throws IOException, ConnectionException, MaintenanceException{
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfAccountInfoUrl()).thenReturn("accountInfoUrl");
        Mockito.when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateAccountInfoResponseForSingleLoanWithNoErc());

        String ercSentence = service.getErcPdfDetails(123456789);

        assertEquals("", ercSentence);
    }

    @Test
    void testSingleLoanWithStepErc() throws IOException, ConnectionException, MaintenanceException{
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfAccountInfoUrl()).thenReturn("accountInfoUrl");
        Mockito.when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateAccountInfoResponseForSingleLoanWithStepErc());

        String ercSentence = service.getErcPdfDetails(123456789);

        assertEquals("This charge will no longer apply from 20 April 2024", ercSentence);

    }

    @Test
    void testAnmfCoreClientException() throws ConnectionException, MaintenanceException {
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("accountInfoUrl");
        Mockito.when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any(AnmfRegion.class))).thenThrow(ConnectionException.class);

        String ercSentence = service.getErcPdfDetails(123456789);

        assertEquals("", ercSentence);
    }

    @Test
    void testForMultiLoan() throws IOException, ConnectionException, MaintenanceException{
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfAccountInfoUrl()).thenReturn("accountInfoUrl");
        Mockito.when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateAccountInfoResponseForMultiLoan());

        String ercSentence = service.getErcPdfDetails(123456789);

        assertEquals("", ercSentence);

    }


}
