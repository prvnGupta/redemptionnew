package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexity;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules.*;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts.ComplexAccountErrorMapper;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts.RuleComplexAccount;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RedemptionsFiguresOutputMapperTest {

    private RedemptionsFiguresOutputMapper mapper;

    @Mock
    private AccountComplexity accountComplexity;

    @BeforeEach
    void setUp() {
        List<Rule> rules = new ArrayList<>(Arrays.asList(
                new TotalToRepayMapper(),
                new OutstandingBalanceMapper(),
                new EarlyRepaymentChargeMapper(),
                new UnclearAmountsMapper(),
                new InterestSinceLastPaymentMapper(),
                new MortgageAccountFeeMapper(),
                new BenefitsReclaimMapper(),
                new CreditsToAccountOverpaymentsMapper(),
                new DailyInterestMapper()
        ));

        List<RuleComplexAccount> rulesComplexAccount = new ArrayList<>(List.of(
                new ComplexAccountErrorMapper(accountComplexity)
        ));

        mapper = new RedemptionsFiguresOutputMapper(rules, rulesComplexAccount, accountComplexity);
    }

    @Test
    void happyPathAggregatingAllMappersMethodForFutureDate() {

        when(accountComplexity.isComplex(any(ANMFRedemptionsResponse.class))).thenReturn(false);


        ANMFRedemptionsResponse anmfRedemptionsResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponse();
        var mapperOutput = mapper.map(anmfRedemptionsResponse, "01/02/9999");

        assertNotNull(mapperOutput);

        assertEquals("01/02/9999", mapperOutput.getRedemptionDate());

        assertEquals(BigDecimal.valueOf(123.12), mapperOutput.getTotalToRepay());

        assertEquals(BigDecimal.valueOf(363), mapperOutput.getOutstandingBalance().getTotal());
        assertNotNull(mapperOutput.getOutstandingBalance().getCapitalBalanceDetails());
        assertEquals(BigDecimal.valueOf(100), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(0).getCapitalBalance());
        assertEquals(BigDecimal.valueOf(200), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(1).getCapitalBalance());
        assertEquals(BigDecimal.valueOf(1.25), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(0).getInterestRate());
        assertEquals(BigDecimal.valueOf(2.36), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(1).getInterestRate());
        assertEquals(BigDecimal.valueOf(3), mapperOutput.getOutstandingBalance().getOverdueAmounts());
        assertEquals(BigDecimal.valueOf(60), mapperOutput.getOutstandingBalance().getOtherCostsSundries());

        var earlyRepaymentChargeDetails = mapperOutput.getEarlyRepaymentCharge().getEarlyRepaymentChargeDetails();
        assertNotNull(earlyRepaymentChargeDetails);
        assertEquals(BigDecimal.valueOf(100), earlyRepaymentChargeDetails.get(0).getBalance());
        assertEquals(BigDecimal.valueOf(10), earlyRepaymentChargeDetails.get(0).getEarlyRepaymentCharge());

        assertEquals(BigDecimal.valueOf(200), earlyRepaymentChargeDetails.get(1).getBalance());
        assertEquals(BigDecimal.valueOf(20), earlyRepaymentChargeDetails.get(1).getEarlyRepaymentCharge());

        assertEquals(BigDecimal.valueOf(51), mapperOutput.getUnclearAmounts().getUnclearAmountsPayments());
        assertEquals(BigDecimal.valueOf(56), mapperOutput.getUnclearAmounts().getUnclearAmountsOverPayments());
        assertEquals(BigDecimal.valueOf(57), mapperOutput.getUnclearAmounts().getUnclearAmountsSundries());
        assertEquals(BigDecimal.valueOf(164), mapperOutput.getUnclearAmounts().getTotal());

        assertEquals(BigDecimal.valueOf(143.27), mapperOutput.getInterestSinceLastPayment());

        assertEquals(BigDecimal.valueOf(213.45), mapperOutput.getMortgageAccountFee());

        assertEquals(BigDecimal.valueOf(9), mapperOutput.getBenefitsReclaim());

        assertEquals(BigDecimal.valueOf(72), mapperOutput.getCreditsToAccountOverpayments());

        assertEquals(BigDecimal.valueOf(7.01), mapperOutput.getDailyInterest());


        // There is not errors
        assertNull(mapperOutput.getComplexAccountReasons());
    }

    @Test
    void errorsWereFound() {

        when(accountComplexity.isComplex(any(ANMFRedemptionsResponse.class))).thenReturn(true);
        when(accountComplexity.isComplex(any(RedeptionIllustrationError.class))).thenReturn(true);

        ANMFRedemptionsResponse anmfRedemptionsResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponseWithError();
        var mapperOutput = mapper.map(anmfRedemptionsResponse, "01/01/9999");

        assertNotNull(mapperOutput);

        // Because there is errors, all the elements except the errors list should be null
        assertNull(mapperOutput.getTotalToRepay());

        assertNull(mapperOutput.getOutstandingBalance());

        assertNull(mapperOutput.getEarlyRepaymentCharge());

        assertNull(mapperOutput.getUnclearAmounts());

        assertNull(mapperOutput.getInterestSinceLastPayment());

        assertNull(mapperOutput.getMortgageAccountFee());

        assertNull(mapperOutput.getBenefitsReclaim());

        assertNull(mapperOutput.getCreditsToAccountOverpayments());

        assertNull(mapperOutput.getDailyInterest());

        assertNotNull(mapperOutput.getComplexAccountReasons());

        var element1 = mapperOutput.getComplexAccountReasons().get(0);
        assertEquals("ERR21504", element1.getCode());
        assertEquals("Litigation", element1.getMessage());

        var element2 = mapperOutput.getComplexAccountReasons().get(1);
        assertEquals("ERR21502", element2.getCode());
        assertEquals("First DD payment not received", element2.getMessage());
    }
}
