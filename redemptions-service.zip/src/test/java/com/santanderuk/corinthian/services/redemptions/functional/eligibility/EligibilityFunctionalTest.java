package com.santanderuk.corinthian.services.redemptions.functional.eligibility;

import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.functional.FunctionalTest;
import io.restassured.http.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class EligibilityFunctionalTest extends FunctionalTest {

    String figuresUrl;
    Header header;

    @BeforeEach
    public void setUp() {
        super.setUp();
        figuresUrl = String.format("http://localhost:%s/redemptions-service/%s/eligibility", serverPort, 12345678);
        header = new Header("authorization", jwtWithCustomer554);
    }

    @Test
    void happyPathSingle() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .get(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.eligible", equalTo(true),
                        "data.complexAccountReason", equalTo(null)

                );
    }

    @Test
    void happyPathMulti() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/multi-loan.json");


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .get(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),


                        "data.eligible", equalTo(true),
                        "data.complexAccountReason", equalTo(null)

                );
    }

    @Test
    void regionX() {

        stubHeartbeatRegionX();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .get(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("MAINTENANCE_REGION_X"),
                        "info.message", equalTo("Maintenance region X")
                );
    }

    @Test
    void operativeSecurity() {
        String figuresUrl = String.format("http://localhost:%s/redemptions-service/%s/figures", serverPort, 12345678);
        Header header = new Header("authorization", jwtWithNoCustomer);

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(new RedemptionFiguresInputWrapper())
                .post(figuresUrl)
                .then()
                .statusCode(401)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer")
                );
    }

    @Test
    void complexAccountBankruptcy() {

        assertSingleComplexError(
                "mortgage-illustration/complex/bankruptcy-error.json",
                "ERR21511",
                "ACCOUNT IS BANKRUPT");
    }

    @Test
    void complexBereavement() {

        assertSingleComplexError(
                "mortgage-illustration/complex/bereavement-error.json",
                "ERR21508",
                "DECEASED FLAG ON THE ACCOUNT");
    }

    @Test
    void complexClosedRedeemedPending() {

        assertSingleComplexError(
                "mortgage-illustration/complex/closed-redeemed-pending-error.json",
                "ERR21500",
                "ACCOUNT IS IN A CLOSED / REDEEMED / PENDING STATUS");
    }

    @Test
    void complexFirstDD() {

        assertSingleComplexError(
                "mortgage-illustration/complex/firstDD-error.json",
                "ERR21502",
                "ACCOUNT HAS RECENTLY COMPLETED/First payment has not been made on the account");
    }

    @Test
    void complexFurtherAdvancePendingError() {

        assertSingleComplexError(
                "mortgage-illustration/complex/further-advance-pending-error.json",
                "ERR21507",
                "ACCOUNT IS PENDING A FURTHER ADVANCE");

    }

    @Test
    void complexLitigationError() {

        assertSingleComplexError(
                "mortgage-illustration/complex/litigation-error.json",
                "ERR21504",
                "ACCOUNT IN LITIGATION OR PROPERTY IN POSSESSION");

    }

    @Test
    void complexRightOfConsolidation() {

        assertSingleComplexError(
                "mortgage-illustration/complex/right-of-consolidation-error.json",
                "ERR21513",
                "RIGHTS OF CONSOLIDATION HELD ON ACCOUNT");
    }

    @Test
    void complexSecurePersonal() {

        assertSingleComplexError(
                "mortgage-illustration/complex/secure-personal-loan-error.json",
                "ERR21512",
                "SECURED PERSONAL LOAN(S)/RESTRAINT ORDER PRESENT ON ACCOUNT");

    }

    void assertSingleComplexError(String fixture, String errorCode, String errorMessage) {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustrationWith400(fixture);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .get(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.eligible", equalTo(false),
                        "data.complexAccountReasons[0].code", equalTo(errorCode),
                        "data.complexAccountReasons[0].message", equalTo(errorMessage),

                        // No more data
                        "data.complexAccountReasons[1]", equalTo(null)
                );
    }


    @Test
    void complexMultipleErrors() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustrationWith400("mortgage-illustration/complex/bereavement-litigation-firstDD-Bankruptcy-SPL-ROI-error.json");


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .get(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.eligible", equalTo(false),
                        "data.complexAccountReasons[0].code", equalTo("ERR21502"),
                        "data.complexAccountReasons[0].message", equalTo("ACCOUNT HAS RECENTLY COMPLETED/First payment has not been made on the account"),

                        "data.complexAccountReasons[1].code", equalTo("ERR21504"),
                        "data.complexAccountReasons[1].message", equalTo("ACCOUNT IN LITIGATION OR PROPERTY IN POSSESSION"),

                        "data.complexAccountReasons[2].code", equalTo("ERR21507"),
                        "data.complexAccountReasons[2].message", equalTo("ACCOUNT IS PENDING A FURTHER ADVANCE"),

                        "data.complexAccountReasons[3].code", equalTo("ERR21508"),
                        "data.complexAccountReasons[3].message", equalTo("DECEASED FLAG ON THE ACCOUNT"),

                        "data.complexAccountReasons[4].code", equalTo("ERR21511"),
                        "data.complexAccountReasons[4].message", equalTo("ACCOUNT IS BANKRUPT"),

                        "data.complexAccountReasons[5].code", equalTo("ERR21512"),
                        "data.complexAccountReasons[5].message", equalTo("SECURED PERSONAL LOAN(S)/RESTRAINT ORDER PRESENT ON ACCOUNT"),

                        "data.complexAccountReasons[6].code", equalTo("ERR21513"),
                        "data.complexAccountReasons[6].message", equalTo("RIGHTS OF CONSOLIDATION HELD ON ACCOUNT"),

                        "data.complexAccountReasons[7]", equalTo(null)
                );
    }
}
