package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class MortgagePropertyAddressServiceTest {

    MortgagePropertyAddressService service;

    @Mock
    AnmfCoreClient anmfCoreClient;

    @Mock
    RedemptionsConfig config;

    @Mock
    AnmfRegionClient anmfRegionClient;

    @BeforeEach
    void setUp() {
        service = new MortgagePropertyAddressService(anmfCoreClient, config, anmfRegionClient);
    }

    @Test
    void testWeCallCollateralAssetAdministrationApi() throws IOException, ConnectionException, MaintenanceException {
        Mockito.when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateDefaultAnmfAddressResponse());
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");

        service.getFormattedPropertyAddress(123456789);

        Mockito.verify(anmfCoreClient, times(1)).fetchAddress(123456789, "collateralUrl", AnmfRegion.A);
        Mockito.verify(config, times(1)).getAnmfPropertyServiceUrl();
        Mockito.verify(anmfRegionClient, times(1)).fetchCurrentRegion();
    }

    @Test
    void testHappyPath() throws IOException, ConnectionException, MaintenanceException {
        Mockito.when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateDefaultAnmfAddressResponse());
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");

        String formattedPropertyAddress = service.getFormattedPropertyAddress(123456789);

        assertEquals("line 1, line 2, line 3, line 4, RH16 2GB", formattedPropertyAddress);

    }

    @Test
    void testAnmfCoreClientException() throws ConnectionException, MaintenanceException {
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");
        Mockito.when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any(AnmfRegion.class))).thenThrow(ConnectionException.class);

        String formattedPropertyAddress = service.getFormattedPropertyAddress(123456789);

        assertEquals("", formattedPropertyAddress);
    }

    @Test
    void testAnmfCoreClientErrorResponse() throws ConnectionException, MaintenanceException, IOException {
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");
        Mockito.when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(TestDataCreator.generateErrorAnmfAddressResponse());

        String formattedPropertyAddress = service.getFormattedPropertyAddress(123456789);

        assertEquals("", formattedPropertyAddress);
    }

    @Test
    void testAnmfRegionException() throws ConnectionException, MaintenanceException {
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenThrow(MaintenanceException.class);

        String formattedPropertyAddress = service.getFormattedPropertyAddress(123456789);

        Mockito.verify(anmfCoreClient, times(0)).fetchAddress(anyInt(), anyString(), any());
        assertEquals("", formattedPropertyAddress);
    }

    @Test
    void testNullBlankEmptyLines() throws IOException, ConnectionException, MaintenanceException {
        ANMFPropertyResponse anmfPropertyResponse = TestDataCreator.generateDefaultAnmfAddressResponse();
        anmfPropertyResponse.getPropertyEnquiryResponse().getOutputStructure().setOPropertyAddr2("");
        anmfPropertyResponse.getPropertyEnquiryResponse().getOutputStructure().setOPropertyAddr3(" ");
        anmfPropertyResponse.getPropertyEnquiryResponse().getOutputStructure().setOPropertyAddr4(null);

        Mockito.when(anmfCoreClient.fetchAddress(anyInt(), anyString(), any(AnmfRegion.class))).thenReturn(anmfPropertyResponse);
        Mockito.when(anmfRegionClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        Mockito.when(config.getAnmfPropertyServiceUrl()).thenReturn("collateralUrl");

        String formattedPropertyAddress = service.getFormattedPropertyAddress(123456789);

        assertEquals("line 1, RH16 2GB", formattedPropertyAddress);

    }
}
