package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


class RedemptionFiguresFunctionalValidationExceptionTest {

    public static final RedemptionFiguresFunctionalValidationException.Type REDEMPTION_DATE_NOT_IN_RANGE = RedemptionFiguresFunctionalValidationException.Type.REDEMPTION_DATE_NOT_IN_RANGE;

    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(RedemptionFiguresFunctionalValidationException.class));
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        var exc = new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE);

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        var exc = new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE, new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_REDEMPTION_DATE_NOT_IN_RANGE() {

        var expectedCode = "REDEMPTION_DATE_NOT_IN_RANGE";
        var expectedMessage = "Selected redemption date has to be between today and configured date range";
        var expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        var exc = new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        var withException = new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }
}
