package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
class AccountComplexityTest {

    private AccountComplexity accountComplexity;

    @BeforeEach
    void setUp() {
        accountComplexity = new AccountComplexity();
    }

    @Test
    void noErrorsArrayIsNull() {
        ANMFRedemptionsResponse anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        anmfRedemptionsResponse.setErrors(null);

        var isComplex = accountComplexity.isComplex(anmfRedemptionsResponse);

        assertFalse(isComplex);
    }

    @Test
    void noErrorsObjectArrayIsEmpty() {
        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        var emptyList = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionsResponse.setErrors(emptyList);

        var isComplex = accountComplexity.isComplex(anmfRedemptionsResponse);

        assertFalse(isComplex);
    }

    @Test
    void thereIsAnErrorButIsNotFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("CODE");
        error.setEMessage("MESSAGE");
        anmfRedemptionsResponse.getErrors().add(error);

        var isComplex = accountComplexity.isComplex(anmfRedemptionsResponse);

        assertFalse(isComplex);
    }

    @Test
    void thereIsAnErrorFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");
        anmfRedemptionsResponse.getErrors().add(error);

        var isComplex = accountComplexity.isComplex(anmfRedemptionsResponse);

        assertTrue(isComplex);
    }

    @Test
    void thereIsTowErrorsFromTheComplexList() {
        var anmfRedemptionsResponse = createResponseWithEmptyList();

        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");
        anmfRedemptionsResponse.getErrors().add(error);

        var error2 = new RedeptionIllustrationError();
        error2.setECode("ERR21513");
        error2.setEMessage("Rights of Consolidation");
        anmfRedemptionsResponse.getErrors().add(error2);

        var isComplex = accountComplexity.isComplex(anmfRedemptionsResponse);

        assertTrue(isComplex);
    }

    @Test
    void thereIsAnErrorButIsNotFromTheComplexListCheckSingleError() {
        var error = new RedeptionIllustrationError();
        error.setECode("CODE");
        error.setEMessage("MESSAGE");

        var isComplex = accountComplexity.isComplex(error);

        assertFalse(isComplex);
    }

    @Test
    void thereIsAnErrorFromTheComplexListCheckSingleError() {
        var error = new RedeptionIllustrationError();
        error.setECode("ERR21504");
        error.setEMessage("Litigation");

        var isComplex = accountComplexity.isComplex(error);

        assertTrue(isComplex);
    }

    private ANMFRedemptionsResponse createResponseWithEmptyList() {
        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        var emptyList = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionsResponse.setErrors(emptyList);
        return anmfRedemptionsResponse;
    }

}
