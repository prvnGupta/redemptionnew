package com.santanderuk.corinthian.services.redemptions.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.santanderuk.corinthian.services.redemptions.RedemptionsServiceApplication;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.path.json.config.JsonPathConfig;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static io.restassured.config.JsonConfig.jsonConfig;

@ContextConfiguration(initializers = FunctionalTest.RandomPortInitializer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = RedemptionsServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public abstract class FunctionalTest {
    protected final String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    protected final String jwtWithNoCustomer = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";
    @LocalServerPort
    protected String serverPort;
    @Value("${port}")
    protected int wiremockPort;
    private WireMockServer wireMockServer;

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    @BeforeEach
    public void setUp() {
        RestAssured.config =
                RestAssuredConfig.newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));

        wireMockServer = new WireMockServer(wiremockPort);
        wireMockServer.start();
    }

    @AfterEach
    public void tearDown() {
        wireMockServer.stop();
    }

    protected void stubHeartbeatRegionA() {

        wireMockServer.stubFor(get(urlPathEqualTo("/mortgages-core/anmf/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-region/a.json"))));
    }

    protected void stubHeartbeatRegionW() {

        wireMockServer.stubFor(get(urlPathEqualTo("/mortgages-core/anmf/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-regionw.json"))));
    }

    protected void stubHeartbeatRegionX() {

        wireMockServer.stubFor(get(urlPathEqualTo("/mortgages-core/anmf/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-region/x.json"))));
    }

    protected void stubGetCustomerInfoARegion() {

        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/mortgage-customer-details/accounts/.*/customers"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-customer-service/mortgage-customer-details-default-response.json"))));
    }

    protected void stubGetPropertyInfoARegion() {

        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/collateral-asset-administration/accounts/.*/property"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-address/anmf-address-info-response.json"))));
    }

    protected void stubMortgageIllustration(String fixture) {

        wireMockServer.stubFor(post(urlMatching("/sanuk/internal/mortgage-redemption-illustration/v2/statements"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(fixture))));
    }

    protected void stubCoreBksConnect() {

        wireMockServer.stubFor(post(urlMatching("/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("retrievemcc/bksconnect-retrievemcc-ok.json"))));
    }

    protected void stubGetAccountInfoARegion() {

        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/mortgage-account-details/accounts/.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-account-details/single-loan-flat-erc.json"))));
    }

    protected void stubEventDispatcherHealthOK() {

        wireMockServer.stubFor(get(urlMatching("/health"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("event-dispatcher-health-ok.json"))));
    }

    protected void stubEventDispatcherHealthKo() {

        wireMockServer.stubFor(get(urlMatching("/health"))
                .willReturn(aResponse()
                        .withStatus(500)));
    }

    protected void stubMortgageIllustrationWith400(String fixture) {

        wireMockServer.stubFor(post(urlMatching("/sanuk/internal/mortgage-redemption-illustration/v2/statements"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(400)
                        .withBody(readFileContents(fixture))));
    }

    protected void stubBdpCustomersInformation() {

        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/customers/F000000554")).withHeader(
                        "X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("customer-information/customers-information-response-F554.json"))));

        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/customers/F000000555")).withHeader(
                        "X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("customer-information/customers-information-response-F555.json"))));

    }

    protected void stubBdpCustomersInformation404() {
        wireMockServer.stubFor(get(urlMatching("/sanuk/internal/customers/F000000554")).withHeader(
                        "X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(404)
                        .withBody("[\n" +
                                "    {\n" +
                                "        \"description\": \"The input data don't exist in the database\",\n" +
                                "        \"code\": \"There is no data\",\n" +
                                "        \"message\": \"The input data don't exist in the database\",\n" +
                                "        \"level\": \"error\"\n" +
                                "    }\n" +
                                "]")));
    }

    public static class RandomPortInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int randomPort = SocketUtils.findAvailableTcpPort();
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "port=" + randomPort);

            String anmfHeartBeatUrl = String.format("http://localhost:%d/mortgages-core/anmf/get-region", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "anmf-region.url=" + anmfHeartBeatUrl);

            String anmfGetCustomerInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-customer-details/accounts/{account}/customers", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "anmf.services.customerservice=" + anmfGetCustomerInfoUrl);

            String mortgageIllustration = String.format("http://localhost:%d/sanuk/internal/mortgage-redemption-illustration/v2/statements", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "mortgage-redemption-illustration.url=" + mortgageIllustration);

            String bksConnectUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "bksconnect.endpoints.retrievemcc=" + bksConnectUrl);

            String eventDispatcherHealthUrl = String.format("http://localhost:%d/health", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "event-dispatcher-health-endpoint=" + eventDispatcherHealthUrl);

            String bdpCustomerInformationUrl = String.format("http://localhost:%d/sanuk/internal/customers/{customerId}", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("customers-information.url=%s", bdpCustomerInformationUrl));

            String anmfPropertyUrl = String.format("http://localhost:%d/sanuk/internal/collateral-asset-administration/accounts/{account}/property", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.propertyservice=%s", anmfPropertyUrl));

            String anmfAccountInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-account-details/accounts/{account}", randomPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.account-details=%s", anmfAccountInfoUrl));

        }
    }
}
