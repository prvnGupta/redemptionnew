package com.santanderuk.corinthian.services.redemptions.functional.figures;

import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.functional.FunctionalTest;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import static io.restassured.RestAssured.given;
import static org.assertj.core.internal.bytebuddy.matcher.ElementMatchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ActiveProfiles("test")
public class FiguresFunctionalTest extends FunctionalTest {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    String figuresUrl;
    Header header;

    @BeforeEach
    public void setUp() {
        super.setUp();
        figuresUrl = String.format("http://localhost:%s/redemptions-service/%s/figures", serverPort, 12345678);
        header = new Header("authorization", jwtWithCustomer554);
    }

    @Test
    void happyPathSingle() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");
        stubCoreBksConnect();
        stubBdpCustomersInformation();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();

        var formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        var today = LocalDate.now().format(formatter);

        ValidatableResponse response = given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.redemptionDate", equalTo(today),

                        "data.totalToRepay", equalTo(new BigDecimal("108319.83")),

                        "data.outstandingBalance.total", equalTo(new BigDecimal("102833.56")),
                        "data.outstandingBalance.capitalBalanceDetails[0].capitalBalance", equalTo(new BigDecimal("102820.53")),
                        "data.outstandingBalance.capitalBalanceDetails[0].interestRate", equalTo(new BigDecimal("2.49")),
                        "data.outstandingBalance.overdueAmounts", equalTo(new BigDecimal("1.01")),
                        "data.outstandingBalance.otherCostsSundries", equalTo(new BigDecimal("12.02")),

                        "data.earlyRepaymentCharge.total", equalTo(new BigDecimal("5141.03")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].balance", equalTo(new BigDecimal("102820.53")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].earlyRepaymentCharge", equalTo(new BigDecimal("5141.03")),

                        // There is only one element
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].balance", equalTo(null),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].earlyRepaymentCharge", equalTo(null),

                        "data.unclearAmounts.unclearAmountsPayments", equalTo(new BigDecimal("4.01")),
                        "data.unclearAmounts.unclearAmountsOverPayments", equalTo(new BigDecimal("5.02")),
                        "data.unclearAmounts.unclearAmountsSundries", equalTo(new BigDecimal("6.03")),
                        "data.unclearAmounts.total", equalTo(new BigDecimal("15.06")),

                        "data.interestSinceLastPayment", equalTo(new BigDecimal("133.78")),

                        "data.mortgageAccountFee", equalTo(new BigDecimal("225.00")),

                        "data.benefitsReclaim", equalTo(new BigDecimal("250.05")),

                        "data.creditsToAccountOverpayments", equalTo(new BigDecimal("17.02")),

                        "data.dailyInterest", equalTo(new BigDecimal("7.01")),

                        "data.base64Pdf", not(equalTo(""))

                );

        JsonPath jsonPath = response.extract().body().jsonPath();
        String base64Pdf = jsonPath.get("data.base64Pdf");
        testPdfContent(base64Pdf);
    }

    @Test
    void happyPathMulti() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/multi-loan.json");
        stubCoreBksConnect();
        stubBdpCustomersInformation();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();


        var formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        var today = LocalDate.now().format(formatter);

        ValidatableResponse response = given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.redemptionDate", equalTo(today),

                        "data.totalToRepay", equalTo(new BigDecimal("108319.83")),

                        "data.outstandingBalance.total", equalTo(new BigDecimal("378.68")),
                        "data.outstandingBalance.capitalBalanceDetails[0].capitalBalance", equalTo(new BigDecimal("222.22")),
                        "data.outstandingBalance.capitalBalanceDetails[1].capitalBalance", equalTo(new BigDecimal("111.11")),
                        "data.outstandingBalance.capitalBalanceDetails[0].interestRate", equalTo(new BigDecimal("2.49")),
                        "data.outstandingBalance.capitalBalanceDetails[1].interestRate", equalTo(new BigDecimal("2.50")),
                        "data.outstandingBalance.overdueAmounts", equalTo(new BigDecimal("33.33")),
                        "data.outstandingBalance.otherCostsSundries", equalTo(new BigDecimal("12.02")),

                        "data.earlyRepaymentCharge.total", equalTo(new BigDecimal("7.77")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].balance", equalTo(new BigDecimal("222.22")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].earlyRepaymentCharge", equalTo(new BigDecimal("3.33")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].balance", equalTo(new BigDecimal("111.11")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].earlyRepaymentCharge", equalTo(new BigDecimal("4.44")),

                        // There is not 3rd
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[2].balance", equalTo(null),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[2].earlyRepaymentCharge", equalTo(null),

                        "data.unclearAmounts.unclearAmountsPayments", equalTo(new BigDecimal("9.03")),
                        "data.unclearAmounts.unclearAmountsOverPayments", equalTo(new BigDecimal("5.02")),
                        "data.unclearAmounts.unclearAmountsSundries", equalTo(new BigDecimal("6.03")),
                        "data.unclearAmounts.total", equalTo(new BigDecimal("20.08")),

                        "data.interestSinceLastPayment", equalTo(new BigDecimal("133.28")),

                        "data.mortgageAccountFee", equalTo(new BigDecimal("225.00")),

                        "data.benefitsReclaim", equalTo(new BigDecimal("502.17")),
                        "data.creditsToAccountOverpayments", equalTo(new BigDecimal("17.02")),

                        "data.dailyInterest", equalTo(new BigDecimal("7.01")),

                        "data.base64Pdf", not(equalTo(""))

                );

        JsonPath jsonPath = response.extract().body().jsonPath();
        String base64Pdf = jsonPath.get("data.base64Pdf");
        testPdfContentMultiLoan(base64Pdf);
    }

    @Test
    void happyPathMultiSameBalances() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/multi-loan-same-balance.json");
        stubCoreBksConnect();
        stubBdpCustomersInformation();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();


        var formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        var today = LocalDate.now().format(formatter);

        ValidatableResponse response = given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),

                        "data.redemptionDate", equalTo(today),

                        "data.totalToRepay", equalTo(new BigDecimal("220167.3")),

                        "data.outstandingBalance.total", Matchers.is(216000),
                        "data.outstandingBalance.capitalBalanceDetails[0].capitalBalance", Matchers.is(72000),
                        "data.outstandingBalance.capitalBalanceDetails[1].capitalBalance", Matchers.is(72000),
                        "data.outstandingBalance.capitalBalanceDetails[2].capitalBalance", Matchers.is(0),
                        "data.outstandingBalance.capitalBalanceDetails[3].capitalBalance", Matchers.is(72000),
                        "data.outstandingBalance.capitalBalanceDetails[0].interestRate", equalTo(new BigDecimal("4.65")),
                        "data.outstandingBalance.capitalBalanceDetails[1].interestRate", equalTo(new BigDecimal("5.39")),
                        "data.outstandingBalance.capitalBalanceDetails[2].interestRate", equalTo(new BigDecimal("6.25")),
                        "data.outstandingBalance.capitalBalanceDetails[3].interestRate", equalTo(new BigDecimal("2.69")),
                        "data.outstandingBalance.overdueAmounts", Matchers.is(0),
                        "data.outstandingBalance.otherCostsSundries", Matchers.is(0),

                        "data.earlyRepaymentCharge.total", Matchers.is(3600),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].balance", Matchers.is(72000),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].interestRate", equalTo(new BigDecimal("4.65")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[0].earlyRepaymentCharge", Matchers.is(0),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].balance", Matchers.is(72000),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].interestRate", equalTo(new BigDecimal("5.39")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[1].earlyRepaymentCharge", Matchers.is(1440),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[2].balance", Matchers.is(0),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[2].interestRate", equalTo(new BigDecimal("6.25")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[2].earlyRepaymentCharge", Matchers.is(0),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[3].balance", Matchers.is(72000),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[3].interestRate", equalTo(new BigDecimal("2.69")),
                        "data.earlyRepaymentCharge.earlyRepaymentChargeDetails[3].earlyRepaymentCharge", Matchers.is(2160),

                        "data.unclearAmounts.unclearAmountsPayments", Matchers.is(0),
                        "data.unclearAmounts.unclearAmountsOverPayments", Matchers.is(0),
                        "data.unclearAmounts.unclearAmountsSundries", Matchers.is(0),
                        "data.unclearAmounts.total", Matchers.is(0),

                        "data.interestSinceLastPayment", equalTo(new BigDecimal("342.3")),

                        "data.mortgageAccountFee", Matchers.is(225),

                        "data.benefitsReclaim", Matchers.is(0),
                        "data.creditsToAccountOverpayments", Matchers.is(0),

                        "data.dailyInterest", equalTo(new BigDecimal("25.11")),

                        "data.base64Pdf", not(equalTo(""))

                );

        JsonPath jsonPath = response.extract().body().jsonPath();
        String base64Pdf = jsonPath.get("data.base64Pdf");
        testPdfContentMultiLoanWithSameBalance(base64Pdf);
    }

    @Test
    void regionX() {

        stubHeartbeatRegionX();
        stubGetCustomerInfoARegion();


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("MAINTENANCE_REGION_X"),
                        "info.message", equalTo("Maintenance region X")
                );
    }

    @Test
    void operativeSecurity() {
        String figuresUrl = String.format("http://localhost:%s/redemptions-service/%s/figures", serverPort, 12345678);
        Header header = new Header("authorization", jwtWithNoCustomer);

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(401)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer")
                );
    }

    @Test
    void complexAccountBankruptcy() {

        assertErrorComplexAccount("mortgage-illustration/complex/bankruptcy-error.json");
    }

    @Test
    void complexBereavement() {

        assertErrorComplexAccount("mortgage-illustration/complex/bereavement-error.json");
    }

    @Test
    void complexFirstDD() {

        assertErrorComplexAccount("mortgage-illustration/complex/firstDD-error.json");
    }

    @Test
    void complexFurtherAdvancePendingError() {

        assertErrorComplexAccount("mortgage-illustration/complex/further-advance-pending-error.json");
    }

    @Test
    void complexLitigationError() {

        assertErrorComplexAccount("mortgage-illustration/complex/litigation-error.json");
    }

    @Test
    void complexRightOfConsolidation() {

        assertErrorComplexAccount("mortgage-illustration/complex/right-of-consolidation-error.json");
    }

    @Test
    void complexSecurePersonal() {

        assertErrorComplexAccount("mortgage-illustration/complex/secure-personal-loan-error.json");
    }


    @Test
    void complexMultipleErrors() {

        assertErrorComplexAccount("mortgage-illustration/complex/bereavement-litigation-firstDD-Bankruptcy-SPL-ROI-error.json");
    }

    @Test
    void figuresRedemptionDateIsYesterdaySoResultShouldBeKO() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();

        var yesterday = LocalDate.now().minusDays(1).format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(yesterday);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(request)
                .post(figuresUrl)
                .then()
                .statusCode(400)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("REDEMPTION_DATE_NOT_IN_RANGE"),
                        "info.message", equalTo("Selected redemption date has to be between today and configured date range")
                );
    }

    @Test
    void figuresRedemptionDateIsTomorrowSoResultShouldBeOK() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");

        stubBdpCustomersInformation();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();

        stubCoreBksConnect();

        var tomorrow = LocalDate.now().plusDays(1).format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(tomorrow);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(request)
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void figuresRedemptionDateIsIn30DaysSoResultShouldBeOK() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");

        stubBdpCustomersInformation();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();

        stubCoreBksConnect();

        var in30days = LocalDate.now().plusDays(30).format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(in30days);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(request)
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    @DisplayName("shouldReturnFigureFor404BDPCustomer- CORINTHIAN-8665")
    void shouldReturnFigureFor404BDPCustomer() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");

        stubBdpCustomersInformation404();
        stubGetPropertyInfoARegion();
        stubGetAccountInfoARegion();

        stubCoreBksConnect();

        var in30days = LocalDate.now().plusDays(30).format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(in30days);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(request)
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void figuresRedemptionDateIsIn31DaysSoResultShouldBeKO() {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustration("mortgage-illustration/single-loan.json");

        stubCoreBksConnect();

        var in31days = LocalDate.now().plusDays(31).format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(in31days);


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(request)
                .post(figuresUrl)
                .then()
                .statusCode(400)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("REDEMPTION_DATE_NOT_IN_RANGE"),
                        "info.message", equalTo("Selected redemption date has to be between today and configured date range")
                );
    }

    void assertErrorComplexAccount(String fixture) {

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubMortgageIllustrationWith400(fixture);
        stubCoreBksConnect();


        given()
                .header(header)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .when()
                .body(createFiguresRequestWithToday())
                .post(figuresUrl)
                .then()
                .statusCode(200)
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_REDEMPTION_COMPLEX_ACCOUNT"),
                        "info.message", equalTo("The account you are trying to access is a complex one")
                );
    }

    private RedemptionFiguresInputWrapper createFiguresRequestWithToday() {
        var today = LocalDate.now().format(FORMATTER);
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate(today);
        return request;
    }

    private void testPdfContent(String base64Pdf) {
        File file = new File("test.pdf");

        try {
            FileOutputStream fos = new FileOutputStream(file);
            byte[] decoder = Base64.getDecoder().decode(base64Pdf);
            fos.write(decoder);

            PDDocument doc = PDDocument.load(new File("test.pdf"));
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(doc);
            doc.close();
            testCommonPdfParts(text);
            assertTrue(text.contains("Outstanding balance £102,820.53"));
            assertTrue(text.contains("Early repayment charge £5,141.03"));
            assertTrue(text.contains("This charge will no longer apply from 2 April 2023"));
            assertTrue(text.contains("Uncleared amounts"));
            assertTrue(text.contains("Payments £4.01"));
            assertTrue(text.contains("Overpayments £5.02"));
            assertTrue(text.contains("Other costs £6.03"));
            assertTrue(text.contains("Repayable benefits £250.05"));
            assertTrue(text.contains("Interest since last payment £133.78"));
            assertTrue(text.contains("Mortgage account fee £225.00"));
            assertTrue(text.contains("Overdue amounts £1.01"));
            assertTrue(text.contains("Other costs £12.02"));
            assertTrue(text.contains("Credits to your account"));
            assertTrue(text.contains("Recent overpayments £17.02"));
            assertTrue(text.contains("Total £108,319.83"));

            file.delete();


        } catch (Exception e) {
            e.printStackTrace();
            assertEquals("Failed To Read", "PDF Content");
        }


    }

    private void testPdfContentMultiLoan(String base64Pdf) {
        File file = new File("test.pdf");

        try {
            FileOutputStream fos = new FileOutputStream(file);
            byte[] decoder = Base64.getDecoder().decode(base64Pdf);
            fos.write(decoder);

            PDDocument doc = PDDocument.load(new File("test.pdf"));
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(doc);
            doc.close();
            testCommonPdfParts(text);

            assertTrue(text.contains("Summary breakdown:"));
            assertTrue(text.contains("Balance at [ ]2.49% £222.22")); //pdf will show Balance at [2.49%]
            assertTrue(text.contains("Early repayment charge £3.33"));
            assertTrue(text.contains("Balance at [ ]2.50% £111.11")); //pdf will show Balance at [2.50%]
            assertTrue(text.contains("Early repayment charge £4.44"));
            assertTrue(text.contains("Uncleared amounts"));
            assertTrue(text.contains("Payments £9.03"));
            assertTrue(text.contains("Overpayments £5.02"));
            assertTrue(text.contains("Other costs £6.03"));
            assertTrue(text.contains("Repayable benefits £502.17"));
            assertTrue(text.contains("Overdue amounts £33.33"));
            assertTrue(text.contains("Other costs £12.02"));
            assertTrue(text.contains("Interest since last payment £133.28"));
            assertTrue(text.contains("Mortgage account fee £225.00"));
            assertTrue(text.contains("Total £108,319.83"));

            file.delete();


        } catch (Exception e) {
            e.printStackTrace();
            assertEquals("Failed To Read", "PDF Content");
        }


    }

    private void testPdfContentMultiLoanWithSameBalance(String base64Pdf) {
        File file = new File("test.pdf");

        try {
            FileOutputStream fos = new FileOutputStream(file);
            byte[] decoder = Base64.getDecoder().decode(base64Pdf);
            fos.write(decoder);

            PDDocument doc = PDDocument.load(new File("test.pdf"));
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(doc);
            doc.close();
            testCommonPdfParts(text);

            assertTrue(text.contains("Summary breakdown:"));
            assertTrue(text.contains("Balance at [ ]4.65% £72,000.00"));
            assertTrue(text.contains("Balance at [ ]5.39% £72,000.00"));
            assertTrue(text.contains("Balance at [ ]2.69% £72,000.00"));

            assertTrue(text.contains("Early repayment charge £1,440.00"));
            assertTrue(text.contains("Early repayment charge £2,160.00"));

            assertTrue(text.contains("Interest since last payment £342.30"));
            assertTrue(text.contains("Mortgage account fee £225.00"));
            assertTrue(text.contains("Total £220,167.30"));

            file.delete();


        } catch (Exception e) {
            e.printStackTrace();
            assertEquals("Failed To Read", "PDF Content");
        }


    }

    private void testCommonPdfParts(String text) {
        assertTrue(text.contains("This document is for your personal use only"));
        assertTrue(text.contains("Your settlement figure"));
        assertTrue(text.contains("This overview shows total amount needed to repay your mortgage in full. These figures are based on settling on"));
        assertTrue(text.contains("The overview shows a breakdown of all parts of your mortgage and any expected charges as well as the total amount needed to repay it in"));
        assertTrue(text.contains("full (the settlement figure)."));
        assertTrue(text.contains("Sort code 09-15-86"));
        assertTrue(text.contains("Account number 12345678"));
        assertTrue(text.contains("Name(s) Mr Kakaroto-Goku-San Harris, Mr Second Borrower"));
        assertTrue(text.contains("Address line 1, line 2, line 3, line 4, RH16 2GB"));
        assertTrue(text.contains("Next steps:"));
        assertTrue(text.contains("Paying off your mortgage"));
        assertTrue(text.contains("If you're ready to pay off your mortgage in full, please contact us at least 7 days before the date you want to settle your mortgage so that we can"));
        assertTrue(text.contains("start things off for you."));
        assertTrue(text.contains("Moving home"));
        assertTrue(text.contains("Get a decision in principle, find a new property and your solicitor will handle the settlement of this mortgage."));
        assertTrue(text.contains("Switching to a new deal"));
        assertTrue(text.contains("If you’re moving your mortgage to another lender, your solicitor will take care of things. Did you know, if you decided to keep your mortgage with"));
        assertTrue(text.contains("us, you’ll have: no legal or valuation fees, no credit searches or income checks, no application forms or new Direct Debit to set up and the same"));
        assertTrue(text.contains("offers online as over the phone"));
    }

}
