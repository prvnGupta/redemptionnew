package com.santanderuk.corinthian.services.redemptions.functional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;


@ActiveProfiles("test")
public class VersionFunctionalTest extends FunctionalTest {

    String healthUrl;

    @BeforeEach
    void setup() {
        healthUrl = String.format("http://localhost:%s/redemptions-service/version", serverPort);
    }

    @Test
    public void customVersionReturnsUp() {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200);

    }

}
