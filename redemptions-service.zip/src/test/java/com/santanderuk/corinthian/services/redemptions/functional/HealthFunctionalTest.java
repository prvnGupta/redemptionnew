package com.santanderuk.corinthian.services.redemptions.functional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;

@ActiveProfiles("test")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthUrlz;

    @BeforeEach
    void setup() {
        healthUrl = String.format("http://localhost:%s/redemptions-service/health", serverPort);
        healthUrlz = String.format("http://localhost:%s/redemptions-service/healthz", serverPort);
    }

    @Test
    public void customHealthCheckReturnsUp() {
        stubEventDispatcherHealthOK();
        given().
                when().
                get(healthUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));

    }

    @Test
    public void customHealthZCheckReturnsUp() {
        stubEventDispatcherHealthOK();
        given().
                when().
                get(healthUrlz).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));

    }

    @Test
    public void customHealthCheckReturnsDownIfEventDispatcherDown() {
        stubEventDispatcherHealthKo();
        given().
                when().
                get(healthUrl).
                then().
                statusCode(500);
    }

    @Test
    public void customHealthZCheckReturnsDownIfEventDispatcherDown() {
        stubEventDispatcherHealthKo();
        given().
                when().
                get(healthUrlz).
                then().
                statusCode(500);
    }

}
