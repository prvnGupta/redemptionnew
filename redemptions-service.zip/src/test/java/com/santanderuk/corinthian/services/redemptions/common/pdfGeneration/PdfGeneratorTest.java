package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.time.format.DateTimeFormatter.ofPattern;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class PdfGeneratorTest {

    TemplateEngine templateEngine;
    @Mock
    private ContextBuilder mockContextBuilder;
    private PdfGenerator pdfGenerator;

    @Mock
    RedemptionsConfig config;

    public static final DateTimeFormatter DDMMMMYYYYDATEFORMAT = ofPattern("dd MMMM yyyy");

    @BeforeEach
    void setUp() {
        templateEngine = new SpringTemplateEngine();
        pdfGenerator = new PdfGenerator(templateEngine, mockContextBuilder);
    }

    @Test
    void testThePdfIsGeneratedForSingleLoan() throws IOException {

        Map<String, Object> dataMap = new HashMap<>();
        PdfGeneratorRequest pdfGeneratorRequest = new PdfGeneratorRequest();
        pdfGeneratorRequest.setTemplateName(Template.FIGURE_SUMMARY);
        pdfGeneratorRequest.setTemplateElements(dataMap);

        ClassLoaderTemplateResolver classLoaderTemplateResolver = new ClassLoaderTemplateResolver();
        classLoaderTemplateResolver.setPrefix("templates/");
        classLoaderTemplateResolver.setSuffix(".html");
        classLoaderTemplateResolver.setCharacterEncoding("UTF-8");
        templateEngine.setTemplateResolver(classLoaderTemplateResolver);

        Context pageContext = getContextData();
        Mockito.when(mockContextBuilder.buildContext(any())).thenReturn(pageContext);
        templateEngine.process("settlement-figure-pdf", pageContext);

        ByteArrayOutputStream pdfAsByteArrayOutputStream = pdfGenerator.createPdf(pdfGeneratorRequest);
        byte[] inFileBytes = pdfAsByteArrayOutputStream.toByteArray();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(inFileBytes);
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(inFileBytes.length > 0);
        assertTrue(text.contains("123456789"));
        assertTrue(text.contains("£21087.81"));

        File testPdf = new File(filename);
        assertTrue(testPdf.delete());

    }

    @Test
    void testThePdfIsGeneratedForMultiLoan() throws IOException {

        Map<String, Object> dataMap = new HashMap<>();
        PdfGeneratorRequest pdfGeneratorRequest = new PdfGeneratorRequest();
        pdfGeneratorRequest.setTemplateName(Template.FIGURE_SUMMARY);
        pdfGeneratorRequest.setTemplateElements(dataMap);

        ClassLoaderTemplateResolver classLoaderTemplateResolver = new ClassLoaderTemplateResolver();
        classLoaderTemplateResolver.setPrefix("templates/");
        classLoaderTemplateResolver.setSuffix(".html");
        classLoaderTemplateResolver.setCharacterEncoding("UTF-8");
        templateEngine.setTemplateResolver(classLoaderTemplateResolver);

        Context pageContext = getContextDataForMultiLoan();
        Mockito.when(mockContextBuilder.buildContext(any())).thenReturn(pageContext);
        templateEngine.process("settlement-figure-pdf", pageContext);

        ByteArrayOutputStream pdfAsByteArrayOutputStream = pdfGenerator.createPdf(pdfGeneratorRequest);
        byte[] inFileBytes = pdfAsByteArrayOutputStream.toByteArray();

        String filename = "test.pdf";
        OutputStream out = new FileOutputStream(filename);
        out.write(inFileBytes);
        out.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(inFileBytes.length > 0);
        assertTrue(text.contains("123456789"));
        assertTrue(text.contains("£21087.81"));

        File testPdf = new File(filename);
        assertTrue(testPdf.delete());

    }

    private Context getContextData() {
        Context context = new Context();
        context.setVariable("sortCode", "09-15-86");
        context.setVariable("redemptionDate", formatDate("25/03/2023"));
        context.setVariable("currentDate", formatDate(null));
        context.setVariable("mortgageNumber", "123456789");
        context.setVariable("pdfContextData", getPDFPropertyDataForSingleLoan(new MortgageIllustrationServiceOutput()));
        context.setVariable("names", "Mr John Smith, Mrs Jane Deo");
        context.setVariable("address", "112 Kings Drive");
        context.setVariable("ercPdfDetailsService","This charge will no longer apply from 20 April 2023");


        return context;
    }

    private Context getContextDataForMultiLoan() {
        Context context = new Context();
        context.setVariable("sortCode", "09-15-86");
        context.setVariable("redemptionDate", formatDate("25/03/2023"));
        context.setVariable("currentDate", formatDate(null));
        context.setVariable("mortgageNumber", "123456789");
        context.setVariable("pdfContextData", getPDFPropertyDataForMultiLoan(new MortgageIllustrationServiceOutput()));
        context.setVariable("names", "Mr John Smith, Mrs Jane Deo");
        context.setVariable("address", "112 Kings Drive");

        return context;
    }

    private PDFContextData getPDFPropertyDataForSingleLoan(MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput) {
        List<BreakDownData> breakDownDataList = new ArrayList<>();
        BreakDownData data = new BreakDownData();
        data.setInterestRate("2.19");
        data.setOutstandingBalance("£21087.81");
        data.setEarlyRepaymentCharge("£1054.39");
        breakDownDataList.add(data);

        PDFContextData pdfContextData = new PDFContextData();
        pdfContextData.setBreakDownDataList(breakDownDataList);
        pdfContextData.setUnclearedAmounts("£1000");
        pdfContextData.setPayments("£298.36");
        pdfContextData.setOverpayments("£520.36");
        pdfContextData.setSundries("£181.28");
        pdfContextData.setRepayableBenefits("£240.00");
        pdfContextData.setOverdueAmounts("£120.00");
        pdfContextData.setOtherCosts("£90.00");
        pdfContextData.setInterestSinceLastPayment("£756.12");
        pdfContextData.setMortgageAccountFee("£123.12");
        pdfContextData.setRecentOverpayments("£226.00");
        pdfContextData.setTotalToRepay("£219,250.95");
        return pdfContextData;
    }

    private PDFContextData getPDFPropertyDataForMultiLoan(MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput) {
        List<BreakDownData> breakDownDataList = new ArrayList<>();
        BreakDownData data1 = new BreakDownData();
        data1.setInterestRate("2.99");
        data1.setOutstandingBalance("£9370.41");
        data1.setEarlyRepaymentCharge("£281.11");
        breakDownDataList.add(data1);

        BreakDownData data2 = new BreakDownData();
        data2.setInterestRate("2.19");
        data2.setOutstandingBalance("£21087.81");
        data2.setEarlyRepaymentCharge("£1054.39");
        breakDownDataList.add(data2);

        PDFContextData pdfContextData = new PDFContextData();
        pdfContextData.setBreakDownDataList(breakDownDataList);
        pdfContextData.setUnclearedAmounts("£78,978.12");
        pdfContextData.setPayments("£298.36");
        pdfContextData.setOverpayments("£520.36");
        pdfContextData.setSundries("£181.28");
        pdfContextData.setRepayableBenefits("£240.00");
        pdfContextData.setOverdueAmounts("£120.00");
        pdfContextData.setOtherCosts("£90.00");
        pdfContextData.setInterestSinceLastPayment("£756.12");
        pdfContextData.setMortgageAccountFee("£123.12");
        pdfContextData.setMortgageAccountFee("£123.12");
        pdfContextData.setRecentOverpayments("£226.00");
        pdfContextData.setTotalToRepay("£219,250.95");
        return pdfContextData;
    }

    private String formatDate(String redemptionDate) {
        if (redemptionDate != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return LocalDate.parse(redemptionDate, formatter).format(DDMMMMYYYYDATEFORMAT);
        } else {
            LocalDate currentDate = LocalDate.now();
            return currentDate.format(DDMMMMYYYYDATEFORMAT);
        }
    }

}
