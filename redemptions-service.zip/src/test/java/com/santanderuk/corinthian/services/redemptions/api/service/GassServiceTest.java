package com.santanderuk.corinthian.services.redemptions.api.service;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.config.GASSConfig;
import com.santanderuk.corinthian.services.redemptions.gass.GASSClient;
import com.santanderuk.corinthian.services.redemptions.gass.GASSMessageData;
import com.santanderuk.corinthian.services.redemptions.gass.GassService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class GassServiceTest {

    private static final String JWT_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    private static final int ACCOUNT = 123456;
    private GassService gassService;
    @Mock
    private GASSConfig gassConfig;
    @Mock
    private GASSClient gassClient;
    @Mock
    private BksConnectClient bksConnectClient;
    @Mock
    private HttpServletRequest httpServletRequest;

    @BeforeEach
    void setUp() {
        gassService = new GassService(bksConnectClient, gassClient, gassConfig);
        doNothing().when(gassClient).send(any(GASSMessageData.class), anyBoolean());
        when(gassConfig.getAppSysIdInternet()).thenReturn("242");
        when(gassConfig.getDvcTypInternet()).thenReturn("1");
        when(gassConfig.getTransactionNameViewRedemptionsFigure()).thenReturn("View Redemptions Figure");

    }

    @Test
    public void testWeCallGassComponentsInRedemptionsViewIllustrations() throws IOException, GeneralException {

        gassService.auditViewRedemptionsFigure(ACCOUNT, TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true), JWT_TOKEN, httpServletRequest, TestDataCreator.generateDefaultMortgageIllustrationServiceOutput());
        when(gassConfig.getTransactionNameViewRedemptionsFigure()).thenReturn("View Redemptions Figure");

        //when(gassService.setCommonGassData("127.0.0.1", "pgwe51ZD", "MCCID", "pgwe51ZD")).thenReturn(setData());
        ArgumentCaptor<GASSMessageData> argumentCaptorGassMessageData = ArgumentCaptor.forClass(GASSMessageData.class);
        Mockito.verify(gassClient, Mockito.times(1)).send(argumentCaptorGassMessageData.capture(), anyBoolean());
        GASSMessageData gassMessageDataHome = argumentCaptorGassMessageData.getAllValues().get(0);
        //gassMessageDataHome.setMccId("123");
        gassMessageDataHome.setAudittrngrpid(765);
        gassService.auditViewRedemptionsFigure(anyInt(), TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true), JWT_TOKEN, httpServletRequest, TestDataCreator.generateDefaultMortgageIllustrationServiceOutput());

        String todayDate = DateTimeFormatter.ofPattern("dd-MM-yyyy").format(LocalDate.now());
        assertEquals(242, gassMessageDataHome.getAppSysId());
        assertEquals("View Redemptions Figure", gassMessageDataHome.getAuditTrnTpName());
        assertEquals("pgwe51ZD", gassMessageDataHome.getLdapUid());
        assertEquals("", gassMessageDataHome.getMccId());
        assertEquals(1, gassMessageDataHome.getDeviceTyp());
        assertEquals(765, gassMessageDataHome.getAudittrngrpid());
        assertTrue(gassMessageDataHome.getFormattedData().contains("<formattedData>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<BorrowersList><borrower><name>MR Forename1 Forename2 Forename3 Surname</name><customerType>F</customerType><customerCode>554</customerCode></borrower><borrower><name>MR Goku Vegeta</name><customerType>F</customerType><customerCode>555</customerCode></borrower></BorrowersList>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<MCCID></MCCID>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<MortgageAccountNumber>123456</MortgageAccountNumber>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<TotalRedemptionFigure>108319.80</TotalRedemptionFigure>"));

        assertTrue(gassMessageDataHome.getFormattedData().contains("<loanList><loan><capitalBalance>222.22</capitalBalance><erc>3.33</erc></loan><loan><capitalBalance>111.11</capitalBalance><erc>4.44</erc></loan></loanList>"));

        assertTrue(gassMessageDataHome.getFormattedData().contains("<MortgageAccountFee>225.00</MortgageAccountFee>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<MortgageInterest>133.28</MortgageInterest>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<OtherCost>12.02</OtherCost>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains("<DailyInterest>7.00</DailyInterest>"));
        assertTrue(gassMessageDataHome.getFormattedData().contains(String.format("<DateRequested>%s</DateRequested>", "23-02-2023")));
        assertTrue(gassMessageDataHome.getFormattedData().contains("</formattedData>"));

    }
}
