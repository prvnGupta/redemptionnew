package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.RedemptionsFiguresOutputMapper;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller.MortgageIllustrationCaller;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MortgageIllustrationServiceTest {

    private MortgageIllustrationService service;

    @Mock
    private MortgageIllustrationCaller mortgageIllustrationCaller;

    @Mock
    private RedemptionsFiguresOutputMapper redemptionsFiguresOutputMapper;


    @BeforeEach
    void beforeEach() {
        service = new MortgageIllustrationService(mortgageIllustrationCaller, redemptionsFiguresOutputMapper);
    }

    @Test
    void happyPath() throws ConnectionException, IOException {

        var anmfRedResponseMocked = new ANMFRedemptionsResponse();
        when(mortgageIllustrationCaller.getRedemptionsFigures(anyInt(), anyString())).thenReturn(anmfRedResponseMocked);

        var outputFromMapper = new MortgageIllustrationServiceOutput();
        when(redemptionsFiguresOutputMapper.map(any(), any())).thenReturn(outputFromMapper);

        var outputFromMapperError = new MortgageIllustrationServiceOutput();
        when(redemptionsFiguresOutputMapper.map(any(), any())).thenReturn(outputFromMapperError);

        var account = 123;
        final var redemptionFiguresOutput = service.getFiguresForDate(account, "01/01/9999");

        assertNotNull(redemptionFiguresOutput);

        // Verify that we sent the parametrised account to the anmfCalled
        var integerArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        var stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(mortgageIllustrationCaller).getRedemptionsFigures(integerArgumentCaptor.capture(), stringArgumentCaptor.capture());
        assertEquals(account, integerArgumentCaptor.getValue());

        // Verify that the object from the anfmCalled is being passed to the CoreToAggregtationMapper
        var fromCoreToAggr = ArgumentCaptor.forClass(ANMFRedemptionsResponse.class);
        var fromCoreToAggrRedemtionDate = ArgumentCaptor.forClass(String.class);
        verify(redemptionsFiguresOutputMapper).map(fromCoreToAggr.capture(), fromCoreToAggrRedemtionDate.capture());
        assertEquals(anmfRedResponseMocked, fromCoreToAggr.getValue());
        assertEquals("01/01/9999", fromCoreToAggrRedemtionDate.getValue());


    }
}
