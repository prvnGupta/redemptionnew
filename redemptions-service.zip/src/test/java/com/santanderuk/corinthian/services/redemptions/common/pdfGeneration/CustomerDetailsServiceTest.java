package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CustomerDetailsServiceTest {

    CustomerDetailsService customerDetailsService;

    @Mock
    CustomerInformationClient customerInformationClient;

    @Mock
    CustomerDetailsMapper customerDetailsMapper;

    @Mock
    RedemptionsConfig config;

    @BeforeEach
    void setUp() {
        customerDetailsService = new CustomerDetailsService(customerInformationClient, customerDetailsMapper, config);
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {
        when(customerInformationClient.getCustomerInformation(anyString(), anyString())).thenReturn(new CustomerInformationResponse());
        when(config.getCustomerInformationUrl()).thenReturn("/dummyUrl");
        List<CustomerDetails> mockCustomerDetailsList = generateCustomerList();
        when(customerDetailsMapper.mapToCustomerDetails(any(), any())).thenReturn(mockCustomerDetailsList.get(0), mockCustomerDetailsList.get(1));

        String formattedCustomerInformationBDP = customerDetailsService.getFormattedCustomerInformationBDP(TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true));

        assertEquals("Mr John Smith, Mrs Jane Deo", formattedCustomerInformationBDP);

    }

    @Test
    void testClientException() throws ConnectionException, IOException {
        when(customerInformationClient.getCustomerInformation(anyString(), anyString())).thenThrow(ConnectionException.class);
        when(config.getCustomerInformationUrl()).thenReturn("/dummyUrl");
        String formattedCustomerInformationBDP = customerDetailsService.getFormattedCustomerInformationBDP(TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true));
        assertEquals("", formattedCustomerInformationBDP);
    }

    private List<CustomerDetails> generateCustomerList() {

        var customerDetails1 = new CustomerDetails();
        List<CustomerDetails> customerDetailsList = new ArrayList<>();

        customerDetails1.setTitle("Mr");
        customerDetails1.setFirstName("John");
        customerDetails1.setLastName("Smith");
        customerDetailsList.add(customerDetails1);

        var customerDetails2 = new CustomerDetails();
        customerDetails2.setTitle("Mrs");
        customerDetails2.setFirstName("Jane");
        customerDetails2.setLastName("Deo");
        customerDetailsList.add(customerDetails2);

        return customerDetailsList;
    }


}
