package com.santanderuk.corinthian.services.redemptions.gass;


import com.santander.common.instrumentation.logger.functional.OperationPublisher;
import com.santander.common.instrumentation.logger.functional.dto.OperationInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.xml.sax.SAXException;

import javax.management.modelmbean.XMLParseException;
import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
public class GASSClientTest {

    @Mock
    private GASSOperationInfoMapper gassOperationInfoMapper;

    @Mock
    private OperationPublisher operationPublisher;

    private GASSClient gassClient;

    @BeforeEach
    public void setUp() throws Exception {

        gassClient = new GASSClient(operationPublisher, gassOperationInfoMapper);
    }

    @Test
    public void Test_GASSMessage() throws XMLParseException, SAXException, IOException {

        when(gassOperationInfoMapper.assemble(any(GASSMessageData.class), anyBoolean())).thenReturn(new OperationInfo());
        when(operationPublisher.submitFunctionalEvent(any(OperationInfo.class), ArgumentMatchers.eq(false))).thenReturn("REST:OK");

        gassClient.send(new GASSMessageData(), true);
    }

    @Test
    public void Test_GASSMessageKODoesNotThrowExc() throws XMLParseException, SAXException, IOException {

        when(gassOperationInfoMapper.assemble(any(GASSMessageData.class), anyBoolean())).thenReturn(new OperationInfo());
        when(operationPublisher.submitFunctionalEvent(any(OperationInfo.class), ArgumentMatchers.eq(false))).thenReturn("REST:ERROR");

        gassClient.send(new GASSMessageData(), true);
    }

    @Test
    public void Test_GASSMessageExceptionDoesNotThrowExc() throws XMLParseException, SAXException, IOException {

        when(gassOperationInfoMapper.assemble(any(GASSMessageData.class), anyBoolean())).thenReturn(new OperationInfo());
        when(operationPublisher.submitFunctionalEvent(any(OperationInfo.class), ArgumentMatchers.eq(false))).thenThrow(IOException.class);

        gassClient.send(new GASSMessageData(), true);
    }
}

