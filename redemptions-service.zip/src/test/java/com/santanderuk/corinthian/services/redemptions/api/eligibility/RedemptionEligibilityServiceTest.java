package com.santanderuk.corinthian.services.redemptions.api.eligibility;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.MortgageIllustrationService;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.ComplexAccountReason;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RedemptionEligibilityServiceTest {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    RedemptionEligibilityService redemptionEligibilityService;

    @Mock
    MortgageIllustrationService mortgageIllustrationService;


    @BeforeEach
    void setUp() {
        redemptionEligibilityService = new RedemptionEligibilityService(mortgageIllustrationService);
    }

    @Test
    void happyPath() throws IOException, ConnectionException {

        var mortgageIllustrationResponse = new MortgageIllustrationServiceOutput();
        when(mortgageIllustrationService.getFiguresForDate(anyInt(), any())).thenReturn(mortgageIllustrationResponse);


        var account = 12345;
        var today = LocalDate.now().format(FORMATTER);
        var output = redemptionEligibilityService.get(account);

        assertNotNull(output);

        assertTrue(output.isEligible());
        assertNull(output.getComplexAccountReasons());

        var integerArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        var stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(mortgageIllustrationService).getFiguresForDate(integerArgumentCaptor.capture(), stringArgumentCaptor.capture());
        assertEquals(account, integerArgumentCaptor.getValue());
        assertEquals(today, stringArgumentCaptor.getValue());

    }

    @Test
    void complexAccounts() throws IOException, ConnectionException {

        var mortgageIllustrationResponse = getMortgageIllustrationResponseWithErrors();
        when(mortgageIllustrationService.getFiguresForDate(anyInt(), any())).thenReturn(mortgageIllustrationResponse);


        var account = 12345;
        var output = redemptionEligibilityService.get(account);

        assertNotNull(output);

        assertFalse(output.isEligible());
        assertNotNull(output.getComplexAccountReasons());
        assertEquals(output.getComplexAccountReasons(), mortgageIllustrationResponse.getComplexAccountReasons());

        var integerArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        var stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
        verify(mortgageIllustrationService).getFiguresForDate(integerArgumentCaptor.capture(), stringArgumentCaptor.capture());
        assertEquals(account, integerArgumentCaptor.getValue());

    }

    @Test
    void mortgageIllustrationConnectionException() throws IOException, ConnectionException {

        when(mortgageIllustrationService.getFiguresForDate(anyInt(), any())).thenThrow(new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE));


        var account = 12345;

        var connectionException = assertThrows(
                ConnectionException.class,
                () -> redemptionEligibilityService.get(account)
        );
        assertEquals("ANMF_UNAVAILABLE", connectionException.getCode());
        assertEquals("ANMF did not respond correctly", connectionException.getMessage());
    }

    private MortgageIllustrationServiceOutput getMortgageIllustrationResponseWithErrors() {
        var output = new MortgageIllustrationServiceOutput();
        var errors = new ArrayList<ComplexAccountReason>();
        var reason = new ComplexAccountReason();
        reason.setCode("ERR21504");
        reason.setMessage("Litigation");
        errors.add(reason);
        output.setComplexAccountReasons(errors);
        return output;
    }
}
