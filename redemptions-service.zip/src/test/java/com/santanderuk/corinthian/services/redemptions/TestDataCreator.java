package com.santanderuk.corinthian.services.redemptions;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.redemptions.api.figures.RedemptionFiguresServiceInput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;

import java.io.IOException;


public class TestDataCreator {

    public static AnmfBelongsToCustomerWithBorrowerList generateDefaultAnmfBelongToCustomerResponse(boolean value) throws IOException {
        AnmfBelongsToCustomerWithBorrowerList anmfBelongsToCustomerWithBorrowerList = new AnmfBelongsToCustomerWithBorrowerList();
        anmfBelongsToCustomerWithBorrowerList.setAnmfBelongsToCustomer(value);
        anmfBelongsToCustomerWithBorrowerList.setCustomerDetailsResponse(generateDefaultCustomerServiceResponse());
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setCustomerType("F");
        bdpCustomer.setCustomerNumber(554);
        anmfBelongsToCustomerWithBorrowerList.setBdpCustomer(bdpCustomer);

        return anmfBelongsToCustomerWithBorrowerList;

    }


    public static RedemptionFiguresServiceInput getRedemptionFiguresServiceInput() throws IOException {
        return new RedemptionFiguresServiceInput(123, TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true), "jwtToken", null, null);
    }

    public static CustomerDetailsResponse generateDefaultCustomerServiceResponse() throws IOException {
        return FixtureReader.get("anmf-customer-service/mortgage-customer-details-default-response.json", CustomerDetailsResponse.class);
    }

    public static ANMFRedemptionsResponse generateDefaultMortgageIllustrationCorResponse() throws IOException {
        return FixtureReader.get("mortgage-illustration/single-loan.json", ANMFRedemptionsResponse.class);
    }

    public static MortgageIllustrationServiceOutput generateDefaultMortgageIllustrationServiceOutput() throws IOException {
        return FixtureReader.get("mortgage-illustration/mortgage-illustration-java-service-output.json", MortgageIllustrationServiceOutput.class);
    }

    public static ANMFPropertyResponse generateDefaultAnmfAddressResponse() throws IOException {
        return FixtureReader.get("anmf-address/anmf-address-info-response.json", ANMFPropertyResponse.class);
    }

    public static ANMFPropertyResponse generateErrorAnmfAddressResponse() throws IOException {
        return FixtureReader.get("anmf-address/anmf-address-info-send-error-message.json", ANMFPropertyResponse.class);
    }

    public String generateRedemptionsIllustrationBereavementResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/bereavement-error.json");
    }

    public String generateRedemptionsIllustrationMultipleComplexReasonsResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/bereavement-litigation-firstDD-Bankruptcy-SPL-ROI-error.json");
    }

    public String generateRedemptionsIllustrationFirstDDResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/firstDD-error.json");
    }

    public String generateRedemptionsIllustrationSPLResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/secure-personal-loan-error.json");
    }

    public String generateRightOfConsolidationResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/right-of-consolidation-error.json");
    }

    public String generateLitigationResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/litigation-error.json");
    }

    public String generateBankruptcyResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/bankruptcy-error.json");
    }

    public String generateFurtherAdvancePendingResponse() {
        return FixtureReader.readFileContents("mortgage-illustration/complex/further-advance-pending-error.json");
    }

    public static AnmfAccountServiceResponse generateAccountInfoResponseForSingleLoanFlatErc() throws IOException {
        return FixtureReader.get("anmf-account-details/single-loan-flat-erc.json", AnmfAccountServiceResponse.class);
    }

    public static AnmfAccountServiceResponse generateAccountInfoResponseForSingleLoanWithNoErc() throws IOException {
        return FixtureReader.get("anmf-account-details/single-loan-no-erc.json", AnmfAccountServiceResponse.class);
    }

    public static AnmfAccountServiceResponse generateAccountInfoResponseForSingleLoanWithStepErc() throws IOException {
        return FixtureReader.get("anmf-account-details/single-loan-step-erc.json", AnmfAccountServiceResponse.class);
    }

    public static AnmfAccountServiceResponse generateAccountInfoResponseForMultiLoan() throws IOException {
        return FixtureReader.get("anmf-account-details/multi-loan.json", AnmfAccountServiceResponse.class);
    }

    public static MortgageIllustrationServiceOutput generateMortgageIllustrationServiceOutputForMultiLoanSameBalance() throws IOException {
        return FixtureReader.get("mortgage-illustration/mortgage-illustration-output-multi-loan.json", MortgageIllustrationServiceOutput.class);
    }

}
