package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.clients.anmfregion.AnmfRegionClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexityException;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient.MAINTENANCE_REGION_X;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RedemptionFiguresControllerTest {

    @Mock
    public AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;
    RedemptionFiguresController controller;
    @Mock
    RedemptionFiguresService service;

    @Mock
    RedemptionsConfig config;

    @Mock
    AnmfRegionClient mockAnmfRegionClient;

    @Mock
    HttpServletRequest servletRequest;

    @BeforeEach
    void setUp() {
        controller = new RedemptionFiguresController(service, config, anmfBelongToCustomerWithBorrowerListService, mockAnmfRegionClient);
    }

    @Test
    void happyPathWithRegionA() throws GeneralException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(true);


        var redemptionServiceOutput = new MortgageIllustrationServiceOutput();
        when(service.getRedemptionsFigures(any())).thenReturn(redemptionServiceOutput);

        var account = 123;

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/9999");

        var responseEntity = controller.getFigures(account, "jwt", servletRequest, request);

        assertNotNull(responseEntity);

        // verify we are sending the account passed to the controller to the service
        var inputCaptor = ArgumentCaptor.forClass(RedemptionFiguresServiceInput.class);
        verify(service).getRedemptionsFigures(inputCaptor.capture());
        assertEquals(account, inputCaptor.getValue().getAccount());
        assertEquals("jwt", inputCaptor.getValue().getJwtToken());
        assertEquals(servletRequest, inputCaptor.getValue().getServletRequest());
        assertEquals(request, inputCaptor.getValue().getRequest());

        // Verify the object in the wrapper is the one returned by the service
        assertEquals(redemptionServiceOutput, responseEntity.getBody().getData());

        // Http status
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        // Verify the info block
        assertNotNull(responseEntity.getBody().getInfo());
        assertEquals("ok", responseEntity.getBody().getInfo().getStatus());
        assertEquals("", responseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", responseEntity.getBody().getInfo().getMessage());
        assertNotEquals("", responseEntity.getBody().getInfo().getTimestamp());
    }

    @Test
    void happyPathWithRegionW() throws GeneralException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.W);
        mockBelongsToCustomer(true);

        int account = 123;

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var responseEntity = controller.getFigures(account, "jwt", servletRequest, request);

        assertNotNull(responseEntity);

        assertEquals(AnmfRegion.W, responseEntity.getBody().getData().getAnmfRegion());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertNotNull(responseEntity.getBody().getInfo());
        assertEquals("ok", responseEntity.getBody().getInfo().getStatus());
        assertEquals("", responseEntity.getBody().getInfo().getCode());
        assertEquals("Data found", responseEntity.getBody().getInfo().getMessage());
        assertNotEquals("", responseEntity.getBody().getInfo().getTimestamp());
    }


    @Test
    void serviceThrowsConnectionException() throws GeneralException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(true);


        var connectionException = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE);
        when(service.getRedemptionsFigures(any())).thenThrow(connectionException);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var exceptionThrown = assertThrows(
                ConnectionException.class,
                () -> controller.getFigures(123, "", servletRequest, request)
        );

        assertEquals("ANMF_UNAVAILABLE", exceptionThrown.getCode());
        assertEquals("ANMF did not respond correctly", exceptionThrown.getMessage());
    }

    @Test
    void serviceThrowsAccountComplexityException() throws GeneralException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(true);


        var accountComplexityException = new AccountComplexityException();
        when(service.getRedemptionsFigures(any())).thenThrow(accountComplexityException);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var exceptionThrown = assertThrows(
                AccountComplexityException.class,
                () -> controller.getFigures(123, "", servletRequest, request)
        );

        assertEquals("EXC_REDEMPTION_COMPLEX_ACCOUNT", exceptionThrown.getCode());
        assertEquals("The account you are trying to access is a complex one", exceptionThrown.getMessage());
    }

    @Test
    void operativeSecurityIsDisabledSoPassAnyway() throws GeneralException, IOException {
        mockAnmfRegion(AnmfRegion.A);
        mockOperativeSecurity(false);
        mockBelongsToCustomer(false);


        var redemptionServiceOutput = new MortgageIllustrationServiceOutput();
        when(service.getRedemptionsFigures(any())).thenReturn(redemptionServiceOutput);

        int account = 123;

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var responseEntity = controller.getFigures(account, "jwt", servletRequest, request);

        assertNotNull(responseEntity);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    void heartbeatFailsSoWeWillHaveAConnectionException() throws ConnectionException, MaintenanceException {

        mockOperativeSecurity(true);
        mockAnmfRegionWithConnectionException();

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var exceptionThrown = assertThrows(
                ConnectionException.class,
                () -> controller.getFigures(123, "jwt", servletRequest, request)
        );

        assertEquals("HEARTBEAT_CONNECTION_ERROR", exceptionThrown.getCode());
        assertEquals("An error occurred when trying to connect with heartbeat", exceptionThrown.getMessage());
    }

    @Test
    void heartbeatInMaintenance() throws ConnectionException, MaintenanceException {

        mockOperativeSecurity(true);
        mockAnmfRegionMaintenance();

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var exceptionThrown = assertThrows(
                MaintenanceException.class,
                () -> controller.getFigures(123, "jwt", servletRequest, request)
        );

        assertEquals("MAINTENANCE_REGION_X", exceptionThrown.getCode());
        assertEquals("Maintenance region X", exceptionThrown.getMessage());
    }

    @Test
    void doesntBelongToCustomer() throws ConnectionException, MaintenanceException, ValidationsException, IOException {

        mockOperativeSecurity(true);
        mockAnmfRegion(AnmfRegion.A);
        mockBelongsToCustomer(false);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/2021");

        var exceptionThrown = assertThrows(
                OperativeSecurityException.class,
                () -> controller.getFigures(123, "jwt", servletRequest, request)
        );

        assertEquals("SECURITY_KO", exceptionThrown.getCode());
        assertEquals("Mortgage does not belong to customer", exceptionThrown.getMessage());
    }

    private void mockOperativeSecurity(boolean value) {
        when(config.isOperativeSecurity()).thenReturn(value);
    }

    private void mockAnmfRegion(AnmfRegion region) throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenReturn(region);
    }

    private void mockAnmfRegionMaintenance() throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenThrow(new MaintenanceException(MAINTENANCE_REGION_X));
    }

    private void mockAnmfRegionWithConnectionException() throws MaintenanceException, ConnectionException {
        when(mockAnmfRegionClient.fetchCurrentRegion()).thenThrow(new ConnectionException(ConnectionException.Type.HEARTBEAT_CONNECTION_ERROR));
    }

    private void mockBelongsToCustomer(boolean value) throws ValidationsException, ConnectionException, IOException {
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(anyInt(), any(), any(), any())).thenReturn(TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(value));
    }
}
