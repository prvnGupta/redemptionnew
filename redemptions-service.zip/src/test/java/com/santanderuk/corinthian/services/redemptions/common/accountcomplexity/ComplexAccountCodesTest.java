package com.santanderuk.corinthian.services.redemptions.common.accountcomplexity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ComplexAccountCodesTest {

    @Test
    void numberOfElements() {
        assertEquals(8, ComplexAccountCodes.values().length);
    }

    @Test
    void elements() {
        assertEquals("ERR21504", ComplexAccountCodes.LITIGATION.getCode());
        assertEquals("Litigation", ComplexAccountCodes.LITIGATION.getDescription());

        assertEquals("ERR21502", ComplexAccountCodes.FIRST_DD_PAYMENT.getCode());
        assertEquals("First DD payment not received", ComplexAccountCodes.FIRST_DD_PAYMENT.getDescription());

        assertEquals("ERR21507", ComplexAccountCodes.FURTHER_ADVANCE_PENDING.getCode());
        assertEquals("Pending Further Advance", ComplexAccountCodes.FURTHER_ADVANCE_PENDING.getDescription());

        assertEquals("ERR21511", ComplexAccountCodes.BANKRUPTCY.getCode());
        assertEquals("Bankruptcy", ComplexAccountCodes.BANKRUPTCY.getDescription());

        assertEquals("ERR21512", ComplexAccountCodes.SECURED_PERSONAL_LOAN.getCode());
        assertEquals("Secured Personal Loan", ComplexAccountCodes.SECURED_PERSONAL_LOAN.getDescription());

        assertEquals("ERR21513", ComplexAccountCodes.RIGHT_OF_CONSOLIDATION.getCode());
        assertEquals("Rights of Consolidation", ComplexAccountCodes.RIGHT_OF_CONSOLIDATION.getDescription());

        assertEquals("ERR21508", ComplexAccountCodes.DECEASED.getCode());
        assertEquals("Deceased", ComplexAccountCodes.DECEASED.getDescription());

        assertEquals("ERR21500", ComplexAccountCodes.CLOSED_REDEEMED_PENDING.getCode());
        assertEquals("Account status is Closed, Redeemed or Pending", ComplexAccountCodes.CLOSED_REDEEMED_PENDING.getDescription());
    }
}
