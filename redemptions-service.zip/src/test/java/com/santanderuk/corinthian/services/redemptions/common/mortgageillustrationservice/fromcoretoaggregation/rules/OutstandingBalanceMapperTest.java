package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.FromAggregationToCoreMapperTestData;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
class OutstandingBalanceMapperTest {

    OutstandingBalanceMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new OutstandingBalanceMapper();
    }

    @Test
    void happyPath() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponse();
        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertNotNull(mapperOutput.getOutstandingBalance());
        assertEquals(BigDecimal.valueOf(363), mapperOutput.getOutstandingBalance().getTotal());

        assertNotNull(mapperOutput.getOutstandingBalance().getCapitalBalanceDetails());
        assertEquals(BigDecimal.valueOf(100), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(0).getCapitalBalance());
        assertEquals(BigDecimal.valueOf(200), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(1).getCapitalBalance());
        assertEquals(BigDecimal.valueOf(1.25), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(0).getInterestRate());
        assertEquals(BigDecimal.valueOf(2.36), mapperOutput.getOutstandingBalance().getCapitalBalanceDetails().get(1).getInterestRate());
        assertEquals(BigDecimal.valueOf(3), mapperOutput.getOutstandingBalance().getOverdueAmounts());
        assertEquals(BigDecimal.valueOf(60), mapperOutput.getOutstandingBalance().getOtherCostsSundries());


    }
}
