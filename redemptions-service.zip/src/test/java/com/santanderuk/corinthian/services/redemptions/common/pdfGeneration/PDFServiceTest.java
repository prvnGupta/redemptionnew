package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.api.figures.RedemptionFiguresServiceInput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.EarlyRepaymentCharge;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.OutstandingBalance;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.UnclearAmounts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PDFServiceTest {

    PDFService pdfService;

    @Mock
    private PdfGenerator pdfGenerator;
    @Mock
    private PdfDataMapBuilder pdfDataMapBuilder;

    @Mock
    private CustomerDetailsService customerDetailsService;

    @Mock
    private MortgagePropertyAddressService mortgagePropertyAddressService;

    @BeforeEach
    void setUp() throws IOException {

        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        mockPdfGeneratorWithText("This is the content we are writing inside");

        pdfService = new PDFService(pdfGenerator, pdfDataMapBuilder, customerDetailsService, mortgagePropertyAddressService);
    }


    @Test
    void callDataMapBuilder() throws IOException {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();

        when(pdfGenerator.createPdf(any())).thenReturn(new ByteArrayOutputStream());

        when(customerDetailsService.getFormattedCustomerInformationBDP(any())).thenReturn("Mr John Smith, Mrs Jane Deo");

        when(mortgagePropertyAddressService.getFormattedPropertyAddress(123)).thenReturn("line 1, line 2, MK92BQ");
        pdfService.createFiguresPdf(TestDataCreator.getRedemptionFiguresServiceInput(), mortgageIllustrationServiceOutput);

        var mortgageIllustrationServiceOutputCaptor = ArgumentCaptor.forClass(MortgageIllustrationServiceOutput.class);

        var pdfAccountDetailsCaptor = ArgumentCaptor.forClass(PdfAccountDetails.class);

        var redemptionFiguresServiceInputCaptor = ArgumentCaptor.forClass(RedemptionFiguresServiceInput.class);
        verify(pdfDataMapBuilder).build(redemptionFiguresServiceInputCaptor.capture(), mortgageIllustrationServiceOutputCaptor.capture(), pdfAccountDetailsCaptor.capture());

        assertSame(mortgageIllustrationServiceOutput, mortgageIllustrationServiceOutputCaptor.getValue());
        assertEquals("line 1, line 2, MK92BQ", pdfAccountDetailsCaptor.getValue().getAddress());
        assertEquals("Mr John Smith, Mrs Jane Deo", pdfAccountDetailsCaptor.getValue().getNames());

    }


    @Test
    void createFiguresPdfExceptionReturnEmptyString() throws IOException {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();

        when(pdfGenerator.createPdf(any())).thenReturn(null);

        String figuresPdf = pdfService.createFiguresPdf(TestDataCreator.getRedemptionFiguresServiceInput(), mortgageIllustrationServiceOutput);

        assertEquals("", figuresPdf);

    }


    @Test
    void callPdfGenerator() throws IOException {

        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        when(customerDetailsService.getFormattedCustomerInformationBDP(any())).thenReturn("Mr John Smith, Mrs Jane Deo");

        when(mortgagePropertyAddressService.getFormattedPropertyAddress(123)).thenReturn("line 1, line 2, MK92BQ");

        pdfService.createFiguresPdf(TestDataCreator.getRedemptionFiguresServiceInput(), new MortgageIllustrationServiceOutput());

        var pdfGeneratorRequestArgumentCaptor = ArgumentCaptor.forClass(PdfGeneratorRequest.class);

        verify(pdfGenerator).createPdf(pdfGeneratorRequestArgumentCaptor.capture());
        verify(mortgagePropertyAddressService, times(1)).getFormattedPropertyAddress(123);

        verify(customerDetailsService, times(1)).getFormattedCustomerInformationBDP(any());

        assertEquals(Template.FIGURE_SUMMARY, pdfGeneratorRequestArgumentCaptor.getValue().getTemplateName());
        assertSame(dataMap, pdfGeneratorRequestArgumentCaptor.getValue().getTemplateElements());
    }


    @Test
    void checkWeAreReturningTheProperInputString() throws IOException {
        Map<String, Object> dataMap = new HashMap<>();
        mockDataMapBuilder(dataMap);

        mockPdfGeneratorWithText("This is the content we are writing inside");

        var resource = pdfService.createFiguresPdf(TestDataCreator.getRedemptionFiguresServiceInput(), new MortgageIllustrationServiceOutput());

        byte[] decodedBytes = Base64.getDecoder().decode(resource);
        String decodedString = new String(decodedBytes);

        assertTrue(decodedString.contains("This is the content we are writing inside"));
    }

    private void mockPdfGeneratorWithText(String string) throws IOException {
        var byteArrayOutputStream = new ByteArrayOutputStream();
        byteArrayOutputStream.write(string.getBytes());
        when(pdfGenerator.createPdf(any())).thenReturn(byteArrayOutputStream);
    }

    private void mockDataMapBuilder(Map<String, Object> dataMap) {
        when(pdfDataMapBuilder.build(any(), any(), any())).thenReturn(dataMap);
    }


    private MortgageIllustrationServiceOutput getMortgageIllustrationServiceOutput() {

        OutstandingBalance outstandingBalance = new OutstandingBalance();
        outstandingBalance.setTotal(BigDecimal.valueOf(1523.12));
        EarlyRepaymentCharge earlyRepaymentCharge = new EarlyRepaymentCharge();
        earlyRepaymentCharge.setTotal(BigDecimal.valueOf(88893.12));
        UnclearAmounts unclearAmounts = new UnclearAmounts();
        unclearAmounts.setTotal(BigDecimal.valueOf(78978.12));
        MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput = new MortgageIllustrationServiceOutput();
        mortgageIllustrationServiceOutput.setOutstandingBalance(outstandingBalance);
        mortgageIllustrationServiceOutput.setEarlyRepaymentCharge(earlyRepaymentCharge);
        mortgageIllustrationServiceOutput.setUnclearAmounts(unclearAmounts);

        mortgageIllustrationServiceOutput.setMortgageAccountFee(BigDecimal.valueOf(123.12));
        mortgageIllustrationServiceOutput.setInterestSinceLastPayment(BigDecimal.valueOf(756.12));

        return mortgageIllustrationServiceOutput;
    }

}
