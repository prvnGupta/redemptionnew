package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller;

import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RedemptionFiguresServiceInputMapperTest {

    private InputMapper mapper;

    @Mock
    private RedemptionsConfig config;

    @BeforeEach
    void setUp() {
        mapper = new InputMapper(config);
    }

    @Test
    void happyPath() {

        mockConfiguration();

        var account = 12345678;
        var formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        var redemptionDate = LocalDate.now().plusDays(1).format(formatter);
        var mapped = mapper.map(account, redemptionDate);

        assertNotNull(mapped);

        assertEquals("mortgage-redemption-illustration/v2/statements", mapped.getUrl());

        var request = mapped.getRequest();
        assertEquals("12345678", request.getAccountNumber());
        assertEquals(redemptionDate, request.getRedemptionDate());

        assertEquals("B", request.getRequestedBy());
        assertEquals("REDEMPTION", request.getCallingApplication());
        assertEquals("10", request.getChannelType());
        assertEquals("REDEMPTU", request.getUserId());
        assertEquals("E", request.getStatementEnq());


    }

    private void mockConfiguration() {
        when(config.getMortgageRedemptionIllustrationUrl()).thenReturn("mortgage-redemption-illustration/v2/statements");
        when(config.getMortgageRedemptionIllustrationRequestBy()).thenReturn("B");
        when(config.getMortgageRedemptionIllustrationCallingApplication()).thenReturn("REDEMPTION");
        when(config.getMortgageRedemptionIllustrationChannelType()).thenReturn("10");
        when(config.getMortgageRedemptionIllustrationUserId()).thenReturn("REDEMPTU");
        when(config.getMortgageRedemptionIllustrationStatementEnq()).thenReturn("E");
        when(config.getRedemptionDateRange()).thenReturn(30);
    }

}
