package com.santanderuk.corinthian.services.redemptions.api.figures;

import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.MortgageIllustrationService;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import com.santanderuk.corinthian.services.redemptions.common.pdfGeneration.PDFService;
import com.santanderuk.corinthian.services.redemptions.gass.GassService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class RedemptionFiguresServiceTest {

    public static final RedemptionFiguresFunctionalValidationException.Type REDEMPTION_DATE_NOT_IN_RANGE = RedemptionFiguresFunctionalValidationException.Type.REDEMPTION_DATE_NOT_IN_RANGE;
    RedemptionFiguresService redemptionFiguresService;

    @Mock
    MortgageIllustrationService mortgageIllustrationService;

    @Mock
    private GassService gassService;

    @Mock
    private HttpServletRequest servletRequest;

    @Mock
    private RedemptionFiguresFunctionalValidation functionalValidation;

    @Mock
    private PDFService pdfService;

    @BeforeEach
    void setUp() {
        redemptionFiguresService = new RedemptionFiguresService(mortgageIllustrationService, gassService, functionalValidation, pdfService);

    }

    @Test
    void happyPath() throws GeneralException, IOException {

        var mortgageIllustrationOutput = TestDataCreator.generateDefaultMortgageIllustrationServiceOutput();
        var anmfBelongsToCustomerWithBorrowerList = TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true);
        when(mortgageIllustrationService.getFiguresForDate(anyInt(), any())).thenReturn(mortgageIllustrationOutput);
        when(pdfService.createFiguresPdf(any(), any())).thenReturn("encryptedMsg");
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/9999");
        var serviceInput = new RedemptionFiguresServiceInput(123, anmfBelongsToCustomerWithBorrowerList, "jwtToken", servletRequest, request);
        var output = redemptionFiguresService.getRedemptionsFigures(serviceInput);

        assertNotNull(output);

        //Check the account we pass to mortgage illustration service is the same that pass as parameter
        var accountArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
        var redemptionDateCaptor = ArgumentCaptor.forClass(String.class);
        verify(mortgageIllustrationService).getFiguresForDate(accountArgumentCaptor.capture(), redemptionDateCaptor.capture());
        assertEquals(123, accountArgumentCaptor.getValue());
        assertEquals("01/02/9999", redemptionDateCaptor.getValue());


        //Check the object returned by mortgage illustration is the one we are return in
        assertEquals(mortgageIllustrationOutput, output);

        var gassAccount = ArgumentCaptor.forClass(Integer.class);
        var gassAnmfBelongsToCustomerWithCustomerListArgumentCaptor = ArgumentCaptor.forClass(AnmfBelongsToCustomerWithBorrowerList.class);
        var gassJwt = ArgumentCaptor.forClass(String.class);
        var gassMortgageIllustrationServiceOutputArgumentCaptor = ArgumentCaptor.forClass(MortgageIllustrationServiceOutput.class);
        verify(gassService, times(1)).auditViewRedemptionsFigure(gassAccount.capture(), gassAnmfBelongsToCustomerWithCustomerListArgumentCaptor.capture(), gassJwt.capture(), any(), gassMortgageIllustrationServiceOutputArgumentCaptor.capture());
        assertEquals(123, gassAccount.getValue());
        assertEquals(anmfBelongsToCustomerWithBorrowerList, gassAnmfBelongsToCustomerWithCustomerListArgumentCaptor.getValue());
        assertEquals("jwtToken", gassJwt.getValue());
        assertEquals(mortgageIllustrationOutput, gassMortgageIllustrationServiceOutputArgumentCaptor.getValue());


    }

    @Test
    void mortgageIllustrationThrowsConnectionException() throws ConnectionException, IOException {

        var connectionException = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE);
        when(mortgageIllustrationService.getFiguresForDate(anyInt(), any())).thenThrow(connectionException);

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/9999");

        var input = new RedemptionFiguresServiceInput(123, TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true), "jwtToken", servletRequest, request);

        var exceptionThrown = assertThrows(
                ConnectionException.class,
                () -> redemptionFiguresService.getRedemptionsFigures(input)

        );


        assertEquals("ANMF_UNAVAILABLE", exceptionThrown.getCode());
        assertEquals("ANMF did not respond correctly", exceptionThrown.getMessage());

    }

    @Test
    void functionValidationThrowsRedemptionFiguresFunctionalValidationException() throws IOException, RedemptionFiguresFunctionalValidationException {

        var exception = new RedemptionFiguresFunctionalValidationException(REDEMPTION_DATE_NOT_IN_RANGE);
        doThrow(exception).when(functionalValidation).validate(any());

        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("01/02/9999");

        var input = new RedemptionFiguresServiceInput(123, TestDataCreator.generateDefaultAnmfBelongToCustomerResponse(true), "jwtToken", servletRequest, request);

        var exceptionThrown = assertThrows(
                RedemptionFiguresFunctionalValidationException.class,
                () -> redemptionFiguresService.getRedemptionsFigures(input)

        );

        assertEquals("REDEMPTION_DATE_NOT_IN_RANGE", exceptionThrown.getCode());
        assertEquals("Selected redemption date has to be between today and configured date range", exceptionThrown.getMessage());

    }
}
