package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.mortgageillustrationcaller;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsInput;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MortgageIllustrationCallerTest {

    private MortgageIllustrationCaller mortgageIllustrationCaller;

    @Mock
    private InputMapper inputMapper;

    @Mock
    private AnmfCoreClient anmfCoreClient;

    @BeforeEach
    void setUp() {
        mortgageIllustrationCaller = new MortgageIllustrationCaller(inputMapper, anmfCoreClient);
    }

    @Test
    void happyPath() throws ConnectionException, IOException {

        var inputCreated = new RedemptionsInput();
        when(inputMapper.map(anyInt(), anyString())).thenReturn(inputCreated);

        var anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        when(anmfCoreClient.fetchRedemption(any())).thenReturn(anmfRedemptionsResponse);

        var account = 123;
        var redemptionsDate = "20/02/2023";
        var call = mortgageIllustrationCaller.getRedemptionsFigures(account, redemptionsDate);

        assertNotNull(call);

        // Verify we send the proper account to the aagregationToCoreMapper
        ArgumentCaptor<Integer> fromAggToCoreMapperCaptor = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<String> fromStringToCoreMapperCaptor = ArgumentCaptor.forClass(String.class);
        verify(inputMapper).map(fromAggToCoreMapperCaptor.capture(), fromStringToCoreMapperCaptor.capture());
        assertEquals(account, fromAggToCoreMapperCaptor.getValue());

        // when check that the Input created by fromAggregationToCore is being sent to the anmfCoreClient
        ArgumentCaptor<RedemptionsInput> anmfResponseArgumentCaptor = ArgumentCaptor.forClass(RedemptionsInput.class);
        verify(anmfCoreClient).fetchRedemption(anmfResponseArgumentCaptor.capture());
        assertEquals(inputCreated, anmfResponseArgumentCaptor.getValue());

        // Check the AnmfClient resonse is what we return in the object
        assertEquals(anmfRedemptionsResponse, call);
    }
}
