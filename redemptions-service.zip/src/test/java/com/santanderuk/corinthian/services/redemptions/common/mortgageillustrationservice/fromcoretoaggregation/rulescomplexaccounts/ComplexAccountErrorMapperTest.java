package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rulescomplexaccounts;

import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedeptionIllustrationError;
import com.santanderuk.corinthian.services.redemptions.common.accountcomplexity.AccountComplexity;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.FromAggregationToCoreMapperTestData;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(SpringExtension.class)
class ComplexAccountErrorMapperTest {

    ComplexAccountErrorMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new ComplexAccountErrorMapper(new AccountComplexity());
    }

    @Test
    void happyPath() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionEmpty();
        var errors = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionResponse.setErrors(errors);

        addError(anmfRedemptionResponse, "", "");

        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertNull(mapperOutput.getComplexAccountReasons());

    }

    @Test
    void thereIsAnError() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionEmpty();
        var errors = new ArrayList<RedeptionIllustrationError>();
        anmfRedemptionResponse.setErrors(errors);

        addError(anmfRedemptionResponse, "ERR21504", "Litigation");

        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertNotNull(mapperOutput.getComplexAccountReasons());

    }

    private void addError(ANMFRedemptionsResponse anmfRedemptionResponse, String code, String message) {
        var error = new RedeptionIllustrationError();
        error.setECode(code);
        error.setEMessage(message);
        anmfRedemptionResponse.getErrors().add(error);
    }


}
