package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.FromAggregationToCoreMapperTestData;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
class UnclearAmountsMapperTest {
    UnclearAmountsMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new UnclearAmountsMapper();
    }

    @Test
    void happyPath() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponse();
        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertNotNull(mapperOutput.getUnclearAmounts());

        assertEquals(BigDecimal.valueOf(51), mapperOutput.getUnclearAmounts().getUnclearAmountsPayments());
        assertEquals(BigDecimal.valueOf(56), mapperOutput.getUnclearAmounts().getUnclearAmountsOverPayments());
        assertEquals(BigDecimal.valueOf(57), mapperOutput.getUnclearAmounts().getUnclearAmountsSundries());
        assertEquals(BigDecimal.valueOf(164), mapperOutput.getUnclearAmounts().getTotal());
    }
}
