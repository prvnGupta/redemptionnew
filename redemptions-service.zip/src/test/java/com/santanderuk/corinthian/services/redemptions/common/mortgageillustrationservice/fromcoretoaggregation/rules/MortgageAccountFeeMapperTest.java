package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.FromAggregationToCoreMapperTestData;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
class MortgageAccountFeeMapperTest {
    MortgageAccountFeeMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new MortgageAccountFeeMapper();
    }

    @Test
    void happyPath() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponse();
        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertEquals(BigDecimal.valueOf(213.45), mapperOutput.getMortgageAccountFee());

    }
}
