package com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.rules;

import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.fromcoretoaggregation.FromAggregationToCoreMapperTestData;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.MortgageIllustrationServiceOutput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
class EarlyRepaymentChargeMapperTest {
    EarlyRepaymentChargeMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new EarlyRepaymentChargeMapper();
    }

    @Test
    void happyPath() {

        var anmfRedemptionResponse = FromAggregationToCoreMapperTestData.createAnmfRedemptionsResponse();
        var mapperOutput = new MortgageIllustrationServiceOutput();

        mapper.map(anmfRedemptionResponse, mapperOutput);

        assertNotNull(mapperOutput.getEarlyRepaymentCharge());

        assertEquals(BigDecimal.valueOf(30), mapperOutput.getEarlyRepaymentCharge().getTotal());

        var earlyRepaymentChargeDetails = mapperOutput.getEarlyRepaymentCharge().getEarlyRepaymentChargeDetails();
        assertNotNull(earlyRepaymentChargeDetails);
        assertEquals(BigDecimal.valueOf(100), earlyRepaymentChargeDetails.get(0).getBalance());
        assertEquals(BigDecimal.valueOf(10), earlyRepaymentChargeDetails.get(0).getEarlyRepaymentCharge());

        assertEquals(BigDecimal.valueOf(200), earlyRepaymentChargeDetails.get(1).getBalance());
        assertEquals(BigDecimal.valueOf(20), earlyRepaymentChargeDetails.get(1).getEarlyRepaymentCharge());


    }
}
