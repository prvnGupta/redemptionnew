package com.santanderuk.corinthian.services.redemptions.functional;


import io.restassured.http.Header;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static io.restassured.RestAssured.given;

@ActiveProfiles("test")
public class CorsFunctionalTests extends FunctionalTest {

    final String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    final Header header = new Header("authorization", jwtWithCustomer554);
    String healthUrl;
    int accountNumber;

    @BeforeEach
    public void setup() {
        accountNumber = 833090;
        healthUrl = String.format("http://localhost:%s/redemptions-service/health", serverPort);
        stubEventDispatcherHealthOK();
    }


    @Test
    public void corsAcceptedDomainTest() {

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "http://localhost:4200").
                when().
                get(healthUrl).
                then().
                statusCode(200);

    }


    @Test
    public void corsNotAcceptedDomainTest() {

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "taherah.hacker.com").
                when().
                get(healthUrl).
                then().
                statusCode(403);

    }
}
