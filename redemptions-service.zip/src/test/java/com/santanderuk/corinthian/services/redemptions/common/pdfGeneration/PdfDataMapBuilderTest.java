package com.santanderuk.corinthian.services.redemptions.common.pdfGeneration;

import com.santanderuk.corinthian.services.redemptions.TestDataCreator;
import com.santanderuk.corinthian.services.redemptions.api.figures.RedemptionFiguresServiceInput;
import com.santanderuk.corinthian.services.redemptions.api.figures.io.RedemptionFiguresInputWrapper;
import com.santanderuk.corinthian.services.redemptions.common.mortgageillustrationservice.output.*;
import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
class PdfDataMapBuilderTest {

    PdfDataMapBuilder pdfDataMapBuilder;

    @Mock
    RedemptionsConfig config;

    @Mock
    ErcPdfDetailsService ercPdfDetailsService;

    @BeforeEach
    void setUp() {
        pdfDataMapBuilder = new PdfDataMapBuilder(config, ercPdfDetailsService);
    }

    @Test
    void mapForPdfDataIsDoneCorrectly() {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();
        pdfAccountDetails.setNames("Mr John Smith, Mrs Jane Deo");
        pdfAccountDetails.setAddress("112 Kings Drive");

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");

        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("This charge will no longer apply from 20 April 2023");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var names = map.get("names");

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("Mr John Smith, Mrs Jane Deo", names);

        assertEquals("123456789", map.get("mortgageNumber"));

        assertEquals("£21,087.81", pdfContextData.getBreakDownDataList().get(0).getOutstandingBalance());

        assertEquals("£1,054.39", pdfContextData.getBreakDownDataList().get(0).getEarlyRepaymentCharge());

        assertEquals("This charge will no longer apply from 20 April 2023", map.get("ercPdfDetailsService"));

    }

    @Test
    void mapForPdfDataIsDoneCorrectlyButNoErc() {

        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();

        mortgageIllustrationServiceOutput.getEarlyRepaymentCharge().setEarlyRepaymentChargeDetails(new ArrayList<>());

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");

        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("0", pdfContextData.getBreakDownDataList().get(0).getEarlyRepaymentCharge());
    }

    @Test
    void mapForPdfDataIsDoneCorrectlyWhenDoNotHaveUnclearedAmountsAndMortgageAccountFee() {

        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();
        mortgageIllustrationServiceOutput.getUnclearAmounts().setTotal(BigDecimal.ZERO);
        mortgageIllustrationServiceOutput.getUnclearAmounts().setUnclearAmountsPayments(BigDecimal.ZERO);
        mortgageIllustrationServiceOutput.getUnclearAmounts().setUnclearAmountsSundries(BigDecimal.ZERO);
        mortgageIllustrationServiceOutput.getUnclearAmounts().setUnclearAmountsOverPayments(BigDecimal.ZERO);
        mortgageIllustrationServiceOutput.setMortgageAccountFee(BigDecimal.ZERO);

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");

        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("This charge will no longer apply from 20 April 2023");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("0", pdfContextData.getUnclearedAmounts());
        assertEquals("0", pdfContextData.getPayments());
        assertEquals("0", pdfContextData.getOverpayments());
        assertEquals("0", pdfContextData.getSundries());
        assertEquals("0", pdfContextData.getMortgageAccountFee());

    }

    @Test
    void namesReturnedAsEmpty() {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutput();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");

        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);
        var names = map.get("names");

        assertEquals(" ", names);

    }

    @Test
    void mapForMultiLoanPdfDataIsDoneCorrectly() {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutputForMultiloan();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();
        pdfAccountDetails.setNames("Mr John Smith, Mrs Jane Deo");
        pdfAccountDetails.setAddress("112 Kings Drive");

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");
        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var names = map.get("names");

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("Mr John Smith, Mrs Jane Deo", names);

        assertEquals("123456789", map.get("mortgageNumber"));

        assertEquals("£9,370.41", pdfContextData.getBreakDownDataList().get(0).getOutstandingBalance());
        assertEquals("2.99%", pdfContextData.getBreakDownDataList().get(0).getInterestRate());
        assertEquals("£281.11", pdfContextData.getBreakDownDataList().get(0).getEarlyRepaymentCharge());
        assertEquals("£21,087.81", pdfContextData.getBreakDownDataList().get(1).getOutstandingBalance());
        assertEquals("2.19%", pdfContextData.getBreakDownDataList().get(1).getInterestRate());
        assertEquals("£1,054.39", pdfContextData.getBreakDownDataList().get(1).getEarlyRepaymentCharge());
        assertEquals("£123.12", pdfContextData.getMortgageAccountFee());

    }

    @Test
    void mapOutstandingBalanceIsDoneCorrectlyButNoErcCharge() {
        var mortgageIllustrationServiceOutput = getMortgageIllustrationServiceOutputForMultiloan();
        mortgageIllustrationServiceOutput.getEarlyRepaymentCharge().setEarlyRepaymentChargeDetails(new ArrayList<>());

        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();
        pdfAccountDetails.setNames("Mr John Smith, Mrs Jane Deo");
        pdfAccountDetails.setAddress("112 Kings Drive");

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");
        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var names = map.get("names");

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("Mr John Smith, Mrs Jane Deo", names);

        assertEquals("123456789", map.get("mortgageNumber"));

        assertEquals("£9,370.41", pdfContextData.getBreakDownDataList().get(0).getOutstandingBalance());
        assertEquals("2.99%", pdfContextData.getBreakDownDataList().get(0).getInterestRate());
        assertEquals("0", pdfContextData.getBreakDownDataList().get(0).getEarlyRepaymentCharge());


    }

    @Test
    void mapForMultiLoanSameBalancePdfDataIsDoneCorrectly() throws IOException {
        var mortgageIllustrationServiceOutput = TestDataCreator.generateMortgageIllustrationServiceOutputForMultiLoanSameBalance();
        PdfAccountDetails pdfAccountDetails = new PdfAccountDetails();
        pdfAccountDetails.setNames("Mr John Smith, Mrs Jane Deo");
        pdfAccountDetails.setAddress("112 Kings Drive");

        Mockito.when(config.getDefaultSortCode()).thenReturn("09-15-86");
        Mockito.when(ercPdfDetailsService.getErcPdfDetails(123456789)).thenReturn("");

        var map = pdfDataMapBuilder.build(getFigureServiceInput(), mortgageIllustrationServiceOutput, pdfAccountDetails);

        var names = map.get("names");

        var pdfContextData = (PDFContextData) map.get("pdfContextData");

        assertEquals("Mr John Smith, Mrs Jane Deo", names);

        assertEquals("123456789", map.get("mortgageNumber"));

        assertEquals("£72,000.00", pdfContextData.getBreakDownDataList().get(0).getOutstandingBalance());
        assertEquals("4.65%", pdfContextData.getBreakDownDataList().get(0).getInterestRate());
        assertEquals("0", pdfContextData.getBreakDownDataList().get(0).getEarlyRepaymentCharge());
        assertEquals("£72,000.00", pdfContextData.getBreakDownDataList().get(1).getOutstandingBalance());
        assertEquals("5.39%", pdfContextData.getBreakDownDataList().get(1).getInterestRate());
        assertEquals("£1,440.00", pdfContextData.getBreakDownDataList().get(1).getEarlyRepaymentCharge());
        assertEquals("0", pdfContextData.getBreakDownDataList().get(2).getOutstandingBalance());
        assertEquals("6.25%", pdfContextData.getBreakDownDataList().get(2).getInterestRate());
        assertEquals("0", pdfContextData.getBreakDownDataList().get(2).getEarlyRepaymentCharge());
        assertEquals("£72,000.00", pdfContextData.getBreakDownDataList().get(3).getOutstandingBalance());
        assertEquals("2.69%", pdfContextData.getBreakDownDataList().get(3).getInterestRate());
        assertEquals("£2,160.00", pdfContextData.getBreakDownDataList().get(3).getEarlyRepaymentCharge());


    }

    private RedemptionFiguresServiceInput getFigureServiceInput() {
        var request = new RedemptionFiguresInputWrapper();
        request.setRedemptionDate("22/03/2023");

        var serviceInput = new RedemptionFiguresServiceInput();
        serviceInput.setAccount(123456789);
        serviceInput.setRequest(request);

        return serviceInput;
    }

    private MortgageIllustrationServiceOutput getMortgageIllustrationServiceOutput() {


        List<CapitalBalanceDetails> capitalBalanceDetailsList = new ArrayList<>();
        CapitalBalanceDetails capitalBalanceDetails = new CapitalBalanceDetails();
        capitalBalanceDetails.setCapitalBalance(BigDecimal.valueOf(21087.81));
        capitalBalanceDetails.setInterestRate(BigDecimal.valueOf(2.19));
        capitalBalanceDetailsList.add(capitalBalanceDetails);

        OutstandingBalance outstandingBalance = new OutstandingBalance();
        outstandingBalance.setCapitalBalanceDetails(capitalBalanceDetailsList);
        outstandingBalance.setOverdueAmounts(BigDecimal.valueOf(120));
        outstandingBalance.setOtherCostsSundries(BigDecimal.valueOf(90));
        EarlyRepaymentCharge earlyRepaymentCharge = new EarlyRepaymentCharge();
        List<EarlyRepaymentChargeDetails> earlyRepaymentChargeDetailsList = new ArrayList<>();
        EarlyRepaymentChargeDetails earlyRepaymentChargeDetails = new EarlyRepaymentChargeDetails();
        earlyRepaymentChargeDetails.setBalance(BigDecimal.valueOf(21087.81));
        earlyRepaymentChargeDetails.setInterestRate(BigDecimal.valueOf(2.19));
        earlyRepaymentChargeDetails.setEarlyRepaymentCharge(BigDecimal.valueOf(1054.39));
        earlyRepaymentChargeDetailsList.add(earlyRepaymentChargeDetails);

        earlyRepaymentCharge.setEarlyRepaymentChargeDetails(earlyRepaymentChargeDetailsList);

        UnclearAmounts unclearAmounts = new UnclearAmounts();
        unclearAmounts.setTotal(BigDecimal.valueOf(1000));
        unclearAmounts.setUnclearAmountsPayments(BigDecimal.valueOf(298.36));
        unclearAmounts.setUnclearAmountsOverPayments(BigDecimal.valueOf(520.36));
        unclearAmounts.setUnclearAmountsSundries(BigDecimal.valueOf(181.28));
        MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput = new MortgageIllustrationServiceOutput();
        mortgageIllustrationServiceOutput.setOutstandingBalance(outstandingBalance);
        mortgageIllustrationServiceOutput.setEarlyRepaymentCharge(earlyRepaymentCharge);
        mortgageIllustrationServiceOutput.setUnclearAmounts(unclearAmounts);
        mortgageIllustrationServiceOutput.setMortgageAccountFee(BigDecimal.valueOf(123.12));
        mortgageIllustrationServiceOutput.setInterestSinceLastPayment(BigDecimal.valueOf(756.12));
        mortgageIllustrationServiceOutput.setBenefitsReclaim(BigDecimal.valueOf(240));
        mortgageIllustrationServiceOutput.setCreditsToAccountOverpayments(BigDecimal.valueOf(0.11));
        mortgageIllustrationServiceOutput.setTotalToRepay(BigDecimal.valueOf(219250.95));

        return mortgageIllustrationServiceOutput;
    }

    private MortgageIllustrationServiceOutput getMortgageIllustrationServiceOutputForMultiloan() {
        List<CapitalBalanceDetails> capitalBalanceDetailsList = new ArrayList<>();
        CapitalBalanceDetails capitalBalanceDetails1 = new CapitalBalanceDetails();
        capitalBalanceDetails1.setCapitalBalance(BigDecimal.valueOf(9370.41));
        capitalBalanceDetails1.setInterestRate(BigDecimal.valueOf(2.99));
        capitalBalanceDetailsList.add(capitalBalanceDetails1);

        CapitalBalanceDetails capitalBalanceDetails2 = new CapitalBalanceDetails();
        capitalBalanceDetails2.setCapitalBalance(BigDecimal.valueOf(21087.81));
        capitalBalanceDetails2.setInterestRate(BigDecimal.valueOf(2.19));
        capitalBalanceDetailsList.add(capitalBalanceDetails2);

        OutstandingBalance outstandingBalance = new OutstandingBalance();
        outstandingBalance.setCapitalBalanceDetails(capitalBalanceDetailsList);
        outstandingBalance.setOverdueAmounts(BigDecimal.valueOf(120));
        outstandingBalance.setOtherCostsSundries(BigDecimal.valueOf(90));

        EarlyRepaymentCharge earlyRepaymentCharge = new EarlyRepaymentCharge();
        List<EarlyRepaymentChargeDetails> earlyRepaymentChargeDetailsList = new ArrayList<>();
        EarlyRepaymentChargeDetails earlyRepaymentChargeDetails1 = new EarlyRepaymentChargeDetails();
        earlyRepaymentChargeDetails1.setBalance(BigDecimal.valueOf(9370.41));
        earlyRepaymentChargeDetails1.setInterestRate(BigDecimal.valueOf(2.99));
        earlyRepaymentChargeDetails1.setEarlyRepaymentCharge(BigDecimal.valueOf(281.11));
        earlyRepaymentChargeDetailsList.add(earlyRepaymentChargeDetails1);

        EarlyRepaymentChargeDetails earlyRepaymentChargeDetails2 = new EarlyRepaymentChargeDetails();
        earlyRepaymentChargeDetails2.setBalance(BigDecimal.valueOf(21087.81));
        earlyRepaymentChargeDetails2.setInterestRate(BigDecimal.valueOf(2.19));
        earlyRepaymentChargeDetails2.setEarlyRepaymentCharge(BigDecimal.valueOf(1054.39));
        earlyRepaymentChargeDetailsList.add(earlyRepaymentChargeDetails2);

        earlyRepaymentCharge.setEarlyRepaymentChargeDetails(earlyRepaymentChargeDetailsList);

        UnclearAmounts unclearAmounts = new UnclearAmounts();
        unclearAmounts.setTotal(BigDecimal.valueOf(1000));
        unclearAmounts.setUnclearAmountsPayments(BigDecimal.valueOf(298.36));
        unclearAmounts.setUnclearAmountsOverPayments(BigDecimal.valueOf(520.36));
        unclearAmounts.setUnclearAmountsSundries(BigDecimal.valueOf(181.28));
        MortgageIllustrationServiceOutput mortgageIllustrationServiceOutput = new MortgageIllustrationServiceOutput();
        mortgageIllustrationServiceOutput.setOutstandingBalance(outstandingBalance);
        mortgageIllustrationServiceOutput.setEarlyRepaymentCharge(earlyRepaymentCharge);
        mortgageIllustrationServiceOutput.setUnclearAmounts(unclearAmounts);
        mortgageIllustrationServiceOutput.setMortgageAccountFee(BigDecimal.valueOf(123.12));
        mortgageIllustrationServiceOutput.setInterestSinceLastPayment(BigDecimal.valueOf(756.12));
        mortgageIllustrationServiceOutput.setBenefitsReclaim(BigDecimal.valueOf(240));
        mortgageIllustrationServiceOutput.setCreditsToAccountOverpayments(BigDecimal.valueOf(226));
        mortgageIllustrationServiceOutput.setTotalToRepay(BigDecimal.valueOf(219250.95));

        return mortgageIllustrationServiceOutput;
    }

}
