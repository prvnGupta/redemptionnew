package com.santanderuk.corinthian.services.redemptions;

import com.santanderuk.mortgage.redemption.utils.EncryptionUtil;

public class DecryptUtil {
    public static void main(String[] args) {
        String decrypted = EncryptionUtil.decrypt("O+IAp1YJ9vYv10ZhIh3HTuDezVhMC4K8KXACSzmGQt+Y52dfH3GB+z7TQN9ddbFo7OUVh14FO9stSMlQ24myiQ==", null);
        System.out.println(decrypted);
    }
}
