package com.santanderuk.corinthian.services.redemptions.healthcheck;

import com.santanderuk.corinthian.services.redemptions.config.RedemptionsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
class EventDispatcherHealthCheckTest {
    EventDispatcherHealthCheck eventDispatcherHealthCheck;

    @Mock
    RedemptionsConfig config;

    @Mock
    RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        eventDispatcherHealthCheck = new EventDispatcherHealthCheck(restTemplate, config);
    }

    @Test
    void testEventDispatcherOk() {
        Mockito.when(config.getEventDispatcherHealthEndpoint()).thenReturn("http://event-dispatcher-service-test:10081/health");
        ResponseEntity response = new ResponseEntity<>("{\"status\":\"UP\",\"groups\":[\"liveness\",\"readiness\"]}", HttpStatus.OK);
        Mockito.when(restTemplate.getForEntity(anyString(), any())).thenReturn(response);
        assertTrue(eventDispatcherHealthCheck.checkIfEventDispatcherIsAlive());

    }

    @Test
    void testEventDispatcherKo() {
        Mockito.when(config.getEventDispatcherHealthEndpoint()).thenReturn("http://event-dispatcher-service-test:10081/health");
        ResponseEntity response = new ResponseEntity<>("{\"status\":\"DOWN\",\"groups\":[\"liveness\",\"readiness\"]}", HttpStatus.OK);
        Mockito.when(restTemplate.getForEntity(anyString(), any())).thenReturn(response);
        assertFalse(eventDispatcherHealthCheck.checkIfEventDispatcherIsAlive());
    }

    @Test
    void testEventDispatcherExc() {
        Mockito.when(config.getEventDispatcherHealthEndpoint()).thenReturn("http://event-dispatcher-service-test:10081/health");
        Mockito.when(restTemplate.getForEntity(anyString(), any())).thenThrow(RestClientException.class);
        assertFalse(eventDispatcherHealthCheck.checkIfEventDispatcherIsAlive());
    }
}
