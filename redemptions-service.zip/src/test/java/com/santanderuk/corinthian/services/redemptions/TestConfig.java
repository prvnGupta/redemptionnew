package com.santanderuk.corinthian.services.redemptions;


import org.springframework.cache.CacheManager;
import org.springframework.cache.support.NoOpCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("test")
public class TestConfig {

    @Bean
    @Primary
    public CacheManager cacheManagerShortLife() {
        return new NoOpCacheManager();
    }

    @Bean
    public CacheManager cacheManagerLongLife() {
        return new NoOpCacheManager();
    }
}
